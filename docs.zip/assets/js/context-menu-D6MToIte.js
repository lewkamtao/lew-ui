import{r as i}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as e,Ci as s,H as r,Li as u,i as c,mi as p,pi as t,ui as d}from"./lew-ui-D0fj-lLn.js";import{fa as m}from"./vendor-DI90tgK9.js";import{t as v}from"./LewComponentInfo-DEhjborz.js";import{n as w,t as b}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as h}from"./DemoContextMenu1-Bw2SEUNZ.js";import{t as f}from"./DemoContextMenu2-B-YFDnIM.js";import{t as x}from"./DemoContextMenu3-BHjg2hzC.js";import{t as g}from"./DemoContextMenu4-B9yVP3wS.js";var C={title:"Props",columnsKey:"props",orderNum:1,data:c(r)},o=i({props:()=>C},1),L=`<script lang="ts" setup>
import type { LewContextMenusOption } from 'lew-ui/types'
import {
  CornerUpRight,
  DownloadCloud,
  Eye,
  File,
  Home,
  Navigation,
  RotateCw,
  Search,
} from 'lucide-vue-next'

const options1: LewContextMenusOption[] = [
  {
    label: 'Back',
    value: '1',
    icon: h(Home, { size: 14 }),
    onClick: () => {
      LewMessage.info('Back')
    },
  },
  {
    label: 'Forward',
    value: '2',
    icon: h(CornerUpRight, { size: 14 }),
    onClick: () => {
      LewMessage.info('Forward')
    },
  },
  {
    label: 'Reload',
    value: '3',
    icon: h(RotateCw, { size: 14 }),
    onClick: () => {
      LewMessage.info('Reload')
    },
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Save As',
    value: '4',
    icon: h(DownloadCloud, { size: 14 }),
    onClick: () => {
      LewMessage.info('Save As')
    },
  },
  {
    label: 'Print',
    value: '4',
    disabled: true,
    icon: h(File, { size: 14 }),
    onClick: () => {
      LewMessage.info('Print')
    },
  },
  {
    label: 'Cast',
    value: '4',
    icon: h(Navigation, { size: 14 }),
    onClick: () => {
      LewMessage.info('Cast')
    },
  },
  {
    label: 'Search image with Google',
    value: '4',
    icon: h(Search, { size: 14 }),
    onClick: () => {
      LewMessage.info('Search image with Google')
    },
  },
  {
    label: 'Open in Reader Mode',
    value: '4',
    icon: h(Eye, { size: 14 }),
    onClick: () => {
      LewMessage.info('Open in Reader Mode')
    },
  },
]

const options2 = [
  {
    label: 'Translate to English',
    value: '1',
  },
  {
    isDividerLine: true,
  },
  {
    label: 'View Source',
    value: '2',
  },
  {
    label: 'Inspect',
    value: '3',
  },
]
<\/script>

<template>
  <lew-flex>
    <div
      v-context-menu="{
        options: options1,
      }"
      class="box"
    >
      Right click here
    </div>
    <div v-context-menu="{ options: options2 }" class="box">
      Right click here
    </div>
  </lew-flex>
</template>

<style lang="scss" scoped>
.box {
  display: flex;
  align-items: center;
  justify-content: center;
  width: calc(100% / 2);
  height: 200px;
  background-color: var(--lew-bgcolor-2);
  border-radius: var(--lew-border-radius-small);
  font-size: 16px;
  color: var(--lew-text-color-5);
}
</style>
`,M=`<script lang="ts" setup>
import type { LewContextMenusOption } from 'lew-ui/types'

const options: LewContextMenusOption[] = [
  {
    label: 'New File',
    value: 'new-file',
  },
  {
    label: 'New Window',
    value: 'new-window',
    children: [
      {
        label: 'New Window',
        value: 'new-window1',
      },
      {
        label: 'New Window with Config',
        value: 'new-window2',
      },
    ],
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Save File',
    value: 'save-file',
  },
  {
    label: 'Save As',
    value: 'save-as',
    children: [
      {
        label: 'Save as Image',
        value: 'image',
      },
      {
        label: 'Save as Text',
        value: 'text',
      },
    ],
  },
  {
    label: 'Save',
    value: 'save',
  },
  {
    label: 'Save All',
    value: 'save-all',
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Preferences',
    value: 'preference',
    children: [
      {
        label: 'Settings',
        value: 'setting',
        children: [
          {
            label: 'Language',
            value: 'language',
            children: [
              {
                label: 'Chinese',
                value: 'chinese',
              },
              {
                label: 'English',
                value: 'english',
              },
            ],
          },
          {
            label: 'Theme',
            value: 'theme',
            children: [
              {
                label: 'Light',
                value: 'light',
              },
              {
                label: 'Dark',
                value: 'dark',
              },
            ],
          },
          {
            label: 'Font Style (Editor)',
            value: 'font',
          },
        ],
      },
      {
        label: 'About',
        value: 'about',
      },
      {
        isDividerLine: true,
      },
      {
        label: 'Help',
        value: 'help',
      },
      {
        label: 'Check for Updates',
        value: 'check-update',
      },
    ],
  },
  {
    label: 'Find in Files',
    value: 'find',
  },
  {
    label: 'Close Window',
    value: 'close-window',
  },
  {
    label: 'Exit',
    value: 'exit',
  },
]
<\/script>

<template>
  <lew-flex>
    <div
      v-context-menu="{
        options,
      }"
      class="box"
    >
      Right click here
    </div>
  </lew-flex>
</template>

<style lang="scss" scoped>
.box {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 200px;
  background-color: var(--lew-bgcolor-2);
  border-radius: var(--lew-border-radius-small);
  font-size: 16px;
  color: var(--lew-text-color-5);
}
</style>
`,k=`<script lang="ts" setup>
import type { LewContextMenusOption } from 'lew-ui/types'
import dayjs from 'dayjs'

const options = ref<LewContextMenusOption[]>([
  {
    label: 'New File',
    value: 'new-file',
  },
  {
    label: 'Save File',
    value: 'save-file',
  },
])

setInterval(() => {
  options.value[0] = {
    ...options.value[0],
    label: dayjs().format('YYYY-MM-DD HH:mm:ss'),
  }
}, 1000)
<\/script>

<template>
  <lew-flex>
    <div
      v-context-menu="{
        options,
      }"
      class="box"
    >
      Right click here
    </div>
  </lew-flex>
</template>

<style lang="scss" scoped>
.box {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 200px;
  background-color: var(--lew-bgcolor-2);
  border-radius: var(--lew-border-radius-small);
  font-size: 16px;
  color: var(--lew-text-color-5);
}
</style>
`,_=`<script lang="ts" setup>
import type { LewContextMenusOption } from 'lew-ui/types'

const options = ref<LewContextMenusOption[]>([
  {
    label: 'Language',
    value: 'language',
    children: [
      {
        label: 'Chinese',
        value: 'chinese',
      },
      {
        label: 'English',
        value: 'english',
      },
    ],
  },
  {
    label: 'Theme',
    value: 'theme',
    children: [
      {
        label: 'Light',
        value: 'light',
        type: 'radio',
        checked: true,
        checkable: true,
        onClick: (item: LewContextMenusOption, options: LewContextMenusOption[]) =>
          setTheme(item, options),
      },
      {
        label: 'Dark',
        type: 'radio',
        value: 'dark',
        checkable: true,
        onClick: (item: LewContextMenusOption, options: LewContextMenusOption[]) =>
          setTheme(item, options),
      },
    ],
  },
  {
    label: 'Font Style (Editor)',
    value: 'font',
  },
  {
    label: 'About',
    value: 'about',
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Help',
    value: 'help',
  },
  {
    label: 'Check for Updates',
    checkable: true,
    checked: true,
    value: 'check-update',
    onClick: (
      item: LewContextMenusOption,
      options: LewContextMenusOption[],
      instance: any,
    ) => setUpdate(item, options, instance),
  },
])

function setTheme(item: LewContextMenusOption, _options: LewContextMenusOption[] = []) {
  _options.forEach((_item: LewContextMenusOption) => {
    _item.checked = _item.label === item.label
  })
}

function setUpdate(
  item: LewContextMenusOption,
  _options: LewContextMenusOption[],
  instance: any,
) {
  item.checked = !item.checked
  instance?.hide()
}
<\/script>

<template>
  <lew-flex>
    <div
      v-context-menu="{
        options,
      }"
      class="box"
    >
      Right-click here
    </div>
  </lew-flex>
</template>

<style lang="scss" scoped>
.box {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 200px;
  background-color: var(--lew-bgcolor-2);
  border-radius: var(--lew-border-radius-small);
  font-size: 16px;
  color: var(--lew-text-color-5);
}
</style>
`;const y=[h,f,x,g],D=[L,M,k,_];var O={class:"demo-wrapper"},S=p({__name:"DemoContextMenu",setup(z){const l=m().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),a=u(Object.keys(o).map(n=>o[n]));return(n,F)=>(s(),d("div",O,[t(v),t(w,{"demo-group":e(y),"code-group":e(D),"component-name":e(l),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(b,{options:e(a)},null,8,["options"])]))}}),R=S,I=R;export{I as default};
