import"./lew-ui-BmI9Z0Xx.js";import"./vendor-B1EjpHgE.js";import{t as e}from"./DemoBadge2-BdTynn8Q.js";export{e as default};
