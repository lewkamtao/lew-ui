import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDialog4-DoHnnTTy.js";export{a as default};
