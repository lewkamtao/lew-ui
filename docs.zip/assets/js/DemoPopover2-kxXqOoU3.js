import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoPopover2-DV-C3rC8.js";export{e as default};
