import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as r}from"./DemoMenuTree5-BL3nrcSo.js";export{r as default};
