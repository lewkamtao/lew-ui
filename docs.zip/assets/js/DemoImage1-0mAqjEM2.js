import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoImage1-Dcp9xbzU.js";export{e as default};
