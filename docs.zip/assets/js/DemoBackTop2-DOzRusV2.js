import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoBackTop2-CEimvR3w.js";export{a as default};
