import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTag1-BJEG5n1Z.js";export{o as default};
