import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoCheckbox1-BPb80J9Z.js";export{e as default};
