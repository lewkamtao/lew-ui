import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoContextMenu3-BHjg2hzC.js";export{o as default};
