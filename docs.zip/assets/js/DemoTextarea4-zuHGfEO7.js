import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea4-BsLQJnbb.js";export{e as default};
