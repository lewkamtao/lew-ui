import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoInput2-PaWnRLrs.js";export{a as default};
