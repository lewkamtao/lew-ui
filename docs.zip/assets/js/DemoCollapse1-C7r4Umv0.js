import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoCollapse1-DMPMk9it.js";export{a as default};
