import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoButton1-BwWif5zP.js";export{a as default};
