import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea5-Bo-tr85Q.js";export{e as default};
