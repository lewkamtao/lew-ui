import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoDialog4-BFw7iy9Q.js";export{a as default};
