import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable8-DYNzwaRv.js";export{e as default};
