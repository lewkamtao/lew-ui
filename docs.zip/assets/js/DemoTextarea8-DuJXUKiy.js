import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea8-CKtuuEOt.js";export{e as default};
