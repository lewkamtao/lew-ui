import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoInput4-BE0Vferk.js";export{a as default};
