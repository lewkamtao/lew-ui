import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag8-C2UnNAzM.js";export{o as default};
