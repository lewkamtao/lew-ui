import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoFlex1-B4tCUBSR.js";export{o as default};
