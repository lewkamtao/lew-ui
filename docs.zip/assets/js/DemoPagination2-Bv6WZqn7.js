import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoPagination2-B-Rc5Qyy.js";export{o as default};
