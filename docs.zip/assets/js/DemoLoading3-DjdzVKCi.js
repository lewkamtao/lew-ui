import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoLoading3-FbkYZGIg.js";export{a as default};
