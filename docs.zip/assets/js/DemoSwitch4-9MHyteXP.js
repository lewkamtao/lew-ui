import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoSwitch4-gv6tq2rr.js";export{a as default};
