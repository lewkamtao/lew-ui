import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoInputNumber2-QOHn4R46.js";export{m as default};
