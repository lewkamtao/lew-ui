import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTag2-D8CYtSI9.js";export{o as default};
