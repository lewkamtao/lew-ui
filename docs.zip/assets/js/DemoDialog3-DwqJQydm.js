import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoDialog3-oXdfd0ab.js";export{a as default};
