import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoSwitch3-CVYUjyco.js";export{a as default};
