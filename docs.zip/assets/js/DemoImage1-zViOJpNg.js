import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoImage1-XctDSNMN.js";export{e as default};
