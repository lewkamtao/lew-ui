import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoCheckbox5-C2itZaHE.js";export{e as default};
