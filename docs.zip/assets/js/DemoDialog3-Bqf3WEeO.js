import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoDialog3-DQM5a7qh.js";export{a as default};
