import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoLoading1-v5emXvqP.js";export{a as default};
