import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTag8-sxHl79Co.js";export{o as default};
