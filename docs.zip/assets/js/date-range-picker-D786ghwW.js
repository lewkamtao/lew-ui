import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as a,Ci as i,Li as p,an as d,i as n,mi as m,on as c,pi as t,r as u,sn as g,ui as f}from"./lew-ui-D0fj-lLn.js";import{fa as _}from"./vendor-DI90tgK9.js";import{t as k}from"./LewComponentInfo-DEhjborz.js";import{n as v,t as R}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as w}from"./DemoDateRangePicker1-BksI85wP.js";import{t as D}from"./DemoDateRangePicker2-Bc7axloT.js";import{t as x}from"./DemoDateRangePicker3-DbZnAkpX.js";var P={title:"Emits",columnsKey:"emits",orderNum:99,data:u(c)},y={title:"Model",columnsKey:"model",orderNum:1,data:n(g)},V={title:"Props",columnsKey:"props",orderNum:2,data:n(d)},r=s({emits:()=>P,model:()=>y,props:()=>V},1),L=`<script setup lang="ts">
const dateRangeValue = ref<{ start?: string, end?: string }>({})
<\/script>

<template>
  <lew-flex style="width: 275px" direction="y" x="start">
    <lew-date-range-picker v-model="dateRangeValue" size="small" />
    <lew-date-range-picker v-model="dateRangeValue" size="medium" />
    <lew-date-range-picker v-model="dateRangeValue" size="large" />
  </lew-flex>
</template>
`,b=`<script setup lang="ts">
const dateRangeValue = ref<{ start?: string, end?: string }>({})
<\/script>

<template>
  <lew-flex style="width: 275px" direction="y" x="start">
    <lew-date-range-picker v-model="dateRangeValue" clearable />
  </lew-flex>
</template>
`,h=`<script setup lang="ts">
const dateRangeValue = ref({})
<\/script>

<template>
  <lew-flex style="width: 275px" direction="y" x="start">
    <lew-date-range-picker v-model="dateRangeValue" readonly clearable />
    <lew-date-range-picker v-model="dateRangeValue" disabled clearable />
  </lew-flex>
</template>
`;const N=[w,D,x],B=[L,b,h];var C={class:"demo-wrapper"},E=m({__name:"DemoDateRangePicker",setup(K){const o=_().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),l=p(Object.keys(r).map(e=>r[e]));return(e,$)=>(i(),f("div",C,[t(k),t(v,{"demo-group":a(N),"code-group":a(B),"component-name":a(o),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(R,{options:a(l)},null,8,["options"])]))}}),z=E,F=z;export{F as default};
