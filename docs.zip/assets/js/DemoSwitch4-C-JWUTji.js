import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoSwitch4-B5anCStK.js";export{a as default};
