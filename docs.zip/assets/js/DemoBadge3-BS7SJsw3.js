import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoBadge3-BFDnPuHj.js";export{e as default};
