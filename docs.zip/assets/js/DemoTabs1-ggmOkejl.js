import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTabs1-D7n6iJo7.js";export{o as default};
