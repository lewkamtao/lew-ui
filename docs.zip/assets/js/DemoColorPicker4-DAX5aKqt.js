import"./lew-ui-CDhnpYIO.js";import{t}from"./DemoColorPicker4-CDNY-8iI.js";export{t as default};
