import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSelect10-D_CgvUca.js";export{o as default};
