import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoInputTag5-D18uIvAy.js";export{o as default};
