import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoBackTop1-ChKkEaMt.js";export{a as default};
