import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoBreadcrumb2-wUgLu1VI.js";export{a as default};
