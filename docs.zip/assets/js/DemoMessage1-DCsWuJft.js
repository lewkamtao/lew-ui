import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoMessage1-Bd2L10Kw.js";export{a as default};
