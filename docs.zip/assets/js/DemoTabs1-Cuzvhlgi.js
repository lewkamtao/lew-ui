import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTabs1-CBPCb3Xw.js";export{o as default};
