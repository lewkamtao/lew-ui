import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoInputTag2-7wqqzBb9.js";export{o as default};
