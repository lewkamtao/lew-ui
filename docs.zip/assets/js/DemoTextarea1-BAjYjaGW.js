import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTextarea1-BglztCFA.js";export{e as default};
