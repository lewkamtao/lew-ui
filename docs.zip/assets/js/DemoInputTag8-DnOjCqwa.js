import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag8-CU8TZTSE.js";export{o as default};
