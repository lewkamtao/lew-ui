import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoInputNumber5-C_2QvAV9.js";export{m as default};
