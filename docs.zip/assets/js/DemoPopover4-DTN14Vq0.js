import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoPopover4-CBlX0PC6.js";export{e as default};
