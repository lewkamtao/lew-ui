import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoBadge1-B_mf8iF2.js";export{e as default};
