import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect8-Dqh2NEb-.js";export{o as default};
