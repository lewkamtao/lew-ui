import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag5-D4pqdpYG.js";export{o as default};
