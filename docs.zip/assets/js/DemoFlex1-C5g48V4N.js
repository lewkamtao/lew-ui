import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoFlex1-CQb-8Qt_.js";export{o as default};
