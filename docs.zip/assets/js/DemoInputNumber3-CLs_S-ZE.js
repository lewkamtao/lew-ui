import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoInputNumber3-DmLQo-Sy.js";export{m as default};
