import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoModal5-D9uImBKN.js";export{a as default};
