import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTextarea2-Cb5H2jQG.js";export{e as default};
