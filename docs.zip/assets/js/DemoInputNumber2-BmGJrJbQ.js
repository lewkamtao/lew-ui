import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoInputNumber2-CsnoCgIF.js";export{m as default};
