import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoCheckbox2-P7n0Vsaa.js";export{e as default};
