import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoMessage3-D7q1yTIQ.js";export{a as default};
