import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag2-CDC5DUfb.js";export{o as default};
