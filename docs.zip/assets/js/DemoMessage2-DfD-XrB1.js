import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoMessage2-BOjC1U_B.js";export{a as default};
