import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoNotification3-BWQS7lN-.js";export{a as default};
