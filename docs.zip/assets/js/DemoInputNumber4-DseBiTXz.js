import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoInputNumber4-Ce8QHClY.js";export{m as default};
