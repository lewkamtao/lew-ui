import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoPopok2-D1WG1kC-.js";export{a as default};
