import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as e}from"./DemoBadge2-D3Nj6C3B.js";export{e as default};
