import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoNotification5-De12mcUn.js";export{a as default};
