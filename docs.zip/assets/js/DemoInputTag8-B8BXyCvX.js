import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag8-BNkBeYWP.js";export{o as default};
