import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoModal1-AFNJFwSd.js";export{a as default};
