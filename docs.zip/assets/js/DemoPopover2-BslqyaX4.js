import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoPopover2-CZqDi1jy.js";export{e as default};
