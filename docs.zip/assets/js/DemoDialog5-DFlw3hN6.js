import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoDialog5-PXlrct5j.js";export{a as default};
