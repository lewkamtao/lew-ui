import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoFlex1-Cany2hH0.js";export{o as default};
