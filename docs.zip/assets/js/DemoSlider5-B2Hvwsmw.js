import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoSlider5-C4X1piOE.js";export{o as default};
