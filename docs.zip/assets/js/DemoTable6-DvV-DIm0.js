import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable6-AvTKDO0V.js";export{e as default};
