import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoSwitch2-DSBflAyw.js";export{a as default};
