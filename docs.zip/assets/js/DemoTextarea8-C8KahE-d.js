import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTextarea8-Bj5vFFH6.js";export{e as default};
