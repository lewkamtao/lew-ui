import"./lew-ui-BmI9Z0Xx.js";import"./vendor-B1EjpHgE.js";import{t as r}from"./DemoButton3-BVRiI5Dg.js";export{r as default};
