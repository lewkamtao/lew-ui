import"./lew-ui-D0fj-lLn.js";import{t}from"./DemoColorPicker3-Du9y0nna.js";export{t as default};
