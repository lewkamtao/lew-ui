import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTabs2-DAm9I86j.js";export{o as default};
