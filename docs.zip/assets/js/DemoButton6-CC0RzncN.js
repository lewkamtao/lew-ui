import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoButton6-CSEZpUVD.js";export{a as default};
