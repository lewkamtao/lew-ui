import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoDialog2-Bnvemzhh.js";export{a as default};
