import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoModal3-QcEHloo2.js";export{a as default};
