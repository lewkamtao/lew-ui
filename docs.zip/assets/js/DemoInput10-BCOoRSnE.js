import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoInput10-DCapwrNc.js";export{a as default};
