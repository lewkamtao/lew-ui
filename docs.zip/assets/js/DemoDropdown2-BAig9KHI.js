import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as m}from"./DemoDropdown2-DvYZQGhZ.js";export{m as default};
