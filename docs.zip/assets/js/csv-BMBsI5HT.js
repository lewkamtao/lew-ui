import{si as s}from"./vendor-DI90tgK9.js";export{s as default};
