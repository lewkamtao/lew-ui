import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect1-BbxU3xUD.js";export{o as default};
