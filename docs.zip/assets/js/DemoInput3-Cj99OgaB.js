import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoInput3-Dz4B2Xw-.js";export{a as default};
