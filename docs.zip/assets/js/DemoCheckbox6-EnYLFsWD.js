import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoCheckbox6-Dsg5NUmV.js";export{e as default};
