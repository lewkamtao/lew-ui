import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDrawer5-BBllpD3c.js";export{a as default};
