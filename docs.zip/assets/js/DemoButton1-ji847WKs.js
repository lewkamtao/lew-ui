import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoButton1-BFvWX7vW.js";export{a as default};
