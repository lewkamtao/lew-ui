import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoPagination3-FvX2QUl1.js";export{o as default};
