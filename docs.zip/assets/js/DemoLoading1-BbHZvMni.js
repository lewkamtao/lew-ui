import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoLoading1-k9y7IfkQ.js";export{a as default};
