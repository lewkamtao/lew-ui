import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoBackTop3-Da6wVj9r.js";export{a as default};
