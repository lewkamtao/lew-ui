import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoBreadcrumb3-CR72gez1.js";export{a as default};
