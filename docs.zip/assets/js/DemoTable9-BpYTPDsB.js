import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable9-DaryTYsY.js";export{e as default};
