import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoInput5-4CC_D5iJ.js";export{a as default};
