import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSlider1-BRV0UNHA.js";export{o as default};
