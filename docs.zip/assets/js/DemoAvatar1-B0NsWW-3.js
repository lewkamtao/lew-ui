import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAvatar1-D80UufZk.js";export{o as default};
