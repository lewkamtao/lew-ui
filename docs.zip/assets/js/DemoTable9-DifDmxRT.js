import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTable9-Bl7cwrSw.js";export{e as default};
