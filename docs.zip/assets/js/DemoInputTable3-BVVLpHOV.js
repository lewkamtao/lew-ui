import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoInputTable3-CG51-OrD.js";export{e as default};
