import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoNotification4-BPF04v9V.js";export{a as default};
