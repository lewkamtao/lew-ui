import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable10-NmO1PSE0.js";export{e as default};
