import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoPopover5-CXm44YEe.js";export{e as default};
