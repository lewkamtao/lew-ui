import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSlider5-nJjDO8Tc.js";export{o as default};
