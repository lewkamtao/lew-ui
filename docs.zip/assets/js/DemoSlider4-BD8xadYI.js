import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSlider4-D7kg_EN-.js";export{o as default};
