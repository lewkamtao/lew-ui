import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoContextMenu4-cwXXtvA2.js";export{o as default};
