import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as r}from"./DemoMenuTree3-CSHu4JHH.js";export{r as default};
