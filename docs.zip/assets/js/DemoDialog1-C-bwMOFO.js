import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoDialog1-D23x5Icy.js";export{a as default};
