import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable5-ZUSB2wuI.js";export{e as default};
