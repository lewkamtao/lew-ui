import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTabs3-B7tZmw6Z.js";export{o as default};
