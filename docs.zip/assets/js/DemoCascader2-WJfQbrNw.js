import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoCascader2-DzNKic7E.js";export{e as default};
