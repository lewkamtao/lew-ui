import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as e}from"./DemoBadge5-C6G2mVTf.js";export{e as default};
