import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea3-DLDzFCWR.js";export{e as default};
