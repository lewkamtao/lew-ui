import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoSwitch5-Bi6S6WMo.js";export{a as default};
