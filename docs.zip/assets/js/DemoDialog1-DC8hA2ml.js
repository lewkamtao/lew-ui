import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoDialog1-Bnd2fHXR.js";export{a as default};
