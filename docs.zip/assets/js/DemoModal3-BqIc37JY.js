import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoModal3-rgA4Yzbu.js";export{a as default};
