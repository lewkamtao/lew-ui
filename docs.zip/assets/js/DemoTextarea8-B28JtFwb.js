import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea8-BsoFALir.js";export{e as default};
