import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag3-BP9PU7J8.js";export{o as default};
