import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoMessage4-4kkx1wr4.js";export{a as default};
