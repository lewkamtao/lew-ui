import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect14-PsXd_XA1.js";export{o as default};
