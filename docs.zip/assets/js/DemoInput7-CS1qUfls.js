import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoInput7-Oqwi2Ndk.js";export{a as default};
