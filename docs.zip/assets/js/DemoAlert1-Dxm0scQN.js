import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAlert1-D5lPGPTn.js";export{o as default};
