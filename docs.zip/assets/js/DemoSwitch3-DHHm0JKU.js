import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoSwitch3-CYmCbzUm.js";export{a as default};
