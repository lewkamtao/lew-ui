import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAvatar2-IVYfezG2.js";export{o as default};
