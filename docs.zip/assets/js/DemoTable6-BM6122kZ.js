import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable6-__sGndfx.js";export{e as default};
