import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoSliderRange5-B8ii2Ch6.js";export{a as default};
