import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as r}from"./DemoMenuTree2-TkTR8X0g.js";export{r as default};
