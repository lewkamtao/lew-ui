import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoCheckbox2-DEIxaeYG.js";export{e as default};
