import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoBadge1-DQDFcuKw.js";export{e as default};
