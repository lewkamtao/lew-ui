import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoSlider2-B2x4UdSF.js";export{o as default};
