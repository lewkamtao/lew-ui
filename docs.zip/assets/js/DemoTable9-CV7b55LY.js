import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable9-D36jnt9t.js";export{e as default};
