import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoInputTag6-lmz4gkAw.js";export{o as default};
