import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoInputNumber5-CrbKxiF2.js";export{m as default};
