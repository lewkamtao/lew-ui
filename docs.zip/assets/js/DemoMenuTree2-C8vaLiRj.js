import"./lew-ui-D4rxVhOO.js";import"./vendor-DE_9brhS.js";import{t as r}from"./DemoMenuTree2-MsXODSF6.js";export{r as default};
