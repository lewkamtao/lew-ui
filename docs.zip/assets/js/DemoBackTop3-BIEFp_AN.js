import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoBackTop3-CTrQg3xM.js";export{a as default};
