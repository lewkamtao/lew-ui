import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoTable12-CZal2VNH.js";export{e as default};
