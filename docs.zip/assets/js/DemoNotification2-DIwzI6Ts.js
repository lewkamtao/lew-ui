import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoNotification2-4O__Atf1.js";export{a as default};
