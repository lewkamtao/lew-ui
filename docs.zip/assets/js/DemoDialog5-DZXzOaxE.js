import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoDialog5-B4h_bZXy.js";export{a as default};
