import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoBreadcrumb1-CrosDLpb.js";export{a as default};
