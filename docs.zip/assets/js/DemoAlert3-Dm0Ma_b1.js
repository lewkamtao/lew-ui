import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAlert3-Dh_6L5te.js";export{o as default};
