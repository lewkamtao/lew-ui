import"./lew-ui-Bz7GIUSM.js";import{t}from"./DemoColorPicker4-BvPhEmHJ.js";export{t as default};
