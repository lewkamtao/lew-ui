import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSlider1-CLz9rJhz.js";export{o as default};
