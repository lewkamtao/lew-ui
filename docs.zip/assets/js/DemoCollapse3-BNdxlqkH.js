import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoCollapse3-rlN58SUF.js";export{a as default};
