import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoForm4-0G36Hci3.js";export{m as default};
