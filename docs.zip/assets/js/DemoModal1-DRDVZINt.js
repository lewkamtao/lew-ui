import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoModal1-D4HnRclL.js";export{a as default};
