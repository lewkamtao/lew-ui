import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoButton4-jprtfcKI.js";export{a as default};
