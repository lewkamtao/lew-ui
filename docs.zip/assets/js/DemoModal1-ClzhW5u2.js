import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoModal1-B6SyPu4G.js";export{a as default};
