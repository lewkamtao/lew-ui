import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoInput2-jN7BAfrx.js";export{a as default};
