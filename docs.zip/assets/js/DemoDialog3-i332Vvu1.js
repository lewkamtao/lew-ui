import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoDialog3-BNLiPOUs.js";export{a as default};
