import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable12-CGg3I29q.js";export{e as default};
