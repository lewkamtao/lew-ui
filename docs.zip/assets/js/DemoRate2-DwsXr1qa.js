import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoRate2-DHrXNON-.js";export{e as default};
