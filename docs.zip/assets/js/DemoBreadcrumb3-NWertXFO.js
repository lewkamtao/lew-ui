import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoBreadcrumb3-D7rgCanP.js";export{a as default};
