import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag6-DBrxbq0A.js";export{o as default};
