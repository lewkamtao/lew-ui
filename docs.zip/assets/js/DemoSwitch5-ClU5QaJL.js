import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoSwitch5-DB3f9Y1M.js";export{a as default};
