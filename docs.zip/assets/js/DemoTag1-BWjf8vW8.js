import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag1-BrvcSPWW.js";export{o as default};
