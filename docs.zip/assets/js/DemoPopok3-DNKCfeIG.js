import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoPopok3-Dk9dElLu.js";export{a as default};
