import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoAlert2-C59ndp0y.js";export{o as default};
