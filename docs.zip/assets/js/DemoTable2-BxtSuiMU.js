import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable2-sCtXA2r1.js";export{e as default};
