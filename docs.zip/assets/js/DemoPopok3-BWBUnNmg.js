import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoPopok3-DZ6ZlbRq.js";export{a as default};
