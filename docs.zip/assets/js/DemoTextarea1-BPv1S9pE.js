import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea1-I_mBJsyM.js";export{e as default};
