import"./lew-ui-D0fj-lLn.js";import{t}from"./DemoColorPicker4-BIbBrqab.js";export{t as default};
