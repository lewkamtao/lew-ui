import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoInputNumber3-DalcH6yP.js";export{m as default};
