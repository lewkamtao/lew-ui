import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSlider4-DtrIRa-m.js";export{o as default};
