import{gi as f}from"./vendor-DI90tgK9.js";export{f as default};
