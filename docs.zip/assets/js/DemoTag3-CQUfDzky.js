import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTag3-Dr5U9z7T.js";export{o as default};
