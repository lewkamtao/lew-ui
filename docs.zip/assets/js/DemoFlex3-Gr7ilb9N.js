import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoFlex3-6_Q8tQUX.js";export{o as default};
