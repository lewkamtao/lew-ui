import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoSelect5-CU4CyUS4.js";export{o as default};
