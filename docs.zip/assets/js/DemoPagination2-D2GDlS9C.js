import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoPagination2-CPDN0NJm.js";export{o as default};
