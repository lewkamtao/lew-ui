import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAvatar4-BV35qIj8.js";export{o as default};
