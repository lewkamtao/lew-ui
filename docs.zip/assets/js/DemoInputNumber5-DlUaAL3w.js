import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoInputNumber5-_-VvMPLh.js";export{m as default};
