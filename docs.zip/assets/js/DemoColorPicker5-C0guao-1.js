import"./lew-ui-Bz7GIUSM.js";import{t}from"./DemoColorPicker5-MU5ltsM3.js";export{t as default};
