import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as r}from"./DemoMenuTree4-jQ7MTK8d.js";export{r as default};
