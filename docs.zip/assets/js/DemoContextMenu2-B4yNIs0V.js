import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoContextMenu2-D56BcrYJ.js";export{o as default};
