import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoButton1-hOTnPvRf.js";export{a as default};
