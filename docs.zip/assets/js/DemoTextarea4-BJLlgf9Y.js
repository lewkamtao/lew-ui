import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea4-y8dlNFoE.js";export{e as default};
