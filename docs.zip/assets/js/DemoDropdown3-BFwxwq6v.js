import"./lew-ui-CDhnpYIO.js";import{t as r}from"./DemoDropdown3-B1aWDAhi.js";export{r as default};
