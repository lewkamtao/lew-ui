import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSelect1-BBizXUZd.js";export{o as default};
