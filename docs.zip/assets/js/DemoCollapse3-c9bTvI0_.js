import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoCollapse3-1IRASDdO.js";export{a as default};
