import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoTooltip1-sxM8VOMO.js";export{a as default};
