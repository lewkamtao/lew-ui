import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoSwitch4-CNlhw0Kw.js";export{a as default};
