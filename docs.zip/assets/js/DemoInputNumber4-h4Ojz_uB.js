import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoInputNumber4-BBv-GnSp.js";export{m as default};
