import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoInputTable3-D2AsGAi4.js";export{e as default};
