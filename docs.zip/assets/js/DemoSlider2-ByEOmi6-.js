import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSlider2-mXF3t_o7.js";export{o as default};
