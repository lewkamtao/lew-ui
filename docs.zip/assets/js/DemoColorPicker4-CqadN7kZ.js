import"./lew-ui-D4rxVhOO.js";import{t}from"./DemoColorPicker4-D4yFNr0E.js";export{t as default};
