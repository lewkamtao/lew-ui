import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoDesc2-DAFiwixE.js";export{o as default};
