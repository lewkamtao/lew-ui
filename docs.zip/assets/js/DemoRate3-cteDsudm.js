import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoRate3-UT9NRBUt.js";export{e as default};
