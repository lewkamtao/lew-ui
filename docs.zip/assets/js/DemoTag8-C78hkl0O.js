import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTag8-ChJWTW1g.js";export{o as default};
