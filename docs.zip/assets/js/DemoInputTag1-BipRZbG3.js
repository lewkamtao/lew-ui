import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag1-D-DItGxh.js";export{o as default};
