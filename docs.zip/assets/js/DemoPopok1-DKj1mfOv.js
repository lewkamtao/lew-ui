import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoPopok1-BqI78RmQ.js";export{a as default};
