import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSlider1-C0br-g7k.js";export{o as default};
