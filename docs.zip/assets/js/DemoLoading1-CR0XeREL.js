import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoLoading1-Bvwu_pjr.js";export{a as default};
