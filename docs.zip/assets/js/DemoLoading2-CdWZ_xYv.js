import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoLoading2-CwnyHzH4.js";export{a as default};
