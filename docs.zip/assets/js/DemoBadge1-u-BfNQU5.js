import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoBadge1-KE14OWoU.js";export{e as default};
