import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoAvatar2-BFVMvqCT.js";export{o as default};
