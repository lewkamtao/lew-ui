import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTitle1-D8RIHZTV.js";export{o as default};
