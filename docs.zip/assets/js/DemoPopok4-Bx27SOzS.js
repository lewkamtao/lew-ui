import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoPopok4-Br2pnwa0.js";export{a as default};
