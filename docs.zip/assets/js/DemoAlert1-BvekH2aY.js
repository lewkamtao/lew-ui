import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoAlert1-BvpibHje.js";export{o as default};
