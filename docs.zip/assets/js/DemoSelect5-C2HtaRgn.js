import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect5-78oxm2bh.js";export{o as default};
