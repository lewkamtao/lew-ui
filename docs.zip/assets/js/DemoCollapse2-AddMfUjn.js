import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoCollapse2-Dsl1wHiU.js";export{a as default};
