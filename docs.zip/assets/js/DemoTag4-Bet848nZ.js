import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag4-CszBSP5e.js";export{o as default};
