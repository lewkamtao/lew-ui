import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoMessage3-Lgpaqd_p.js";export{a as default};
