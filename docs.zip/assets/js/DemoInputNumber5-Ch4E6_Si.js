import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoInputNumber5-CP3yG5iG.js";export{m as default};
