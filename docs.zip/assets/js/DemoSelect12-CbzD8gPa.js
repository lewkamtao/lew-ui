import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect12-Bk-g3cQE.js";export{o as default};
