import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoCascader1-B-0clWfA.js";export{e as default};
