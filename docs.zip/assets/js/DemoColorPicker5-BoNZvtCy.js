import"./lew-ui-BmI9Z0Xx.js";import{t}from"./DemoColorPicker5-B29_CdAp.js";export{t as default};
