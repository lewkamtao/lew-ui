import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoInputNumber5-EtUfFWS2.js";export{m as default};
