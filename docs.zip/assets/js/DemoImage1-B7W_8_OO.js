import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoImage1-H9GaGMhk.js";export{e as default};
