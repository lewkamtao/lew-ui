import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoSelect4-stLfh1W6.js";export{o as default};
