import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoCheckbox1-zcRSok85.js";export{e as default};
