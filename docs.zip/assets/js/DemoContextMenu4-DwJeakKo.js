import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoContextMenu4-B9yVP3wS.js";export{o as default};
