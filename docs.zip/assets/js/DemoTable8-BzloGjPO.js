import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable8-CEXBRbKA.js";export{e as default};
