import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoPopok2-DMcMscvH.js";export{a as default};
