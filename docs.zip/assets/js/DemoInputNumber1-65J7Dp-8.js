import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoInputNumber1-1gn-L-Np.js";export{m as default};
