import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoInputTable1-BlRWnzuL.js";export{e as default};
