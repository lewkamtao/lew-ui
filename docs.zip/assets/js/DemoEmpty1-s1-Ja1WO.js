import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoEmpty1-CPqCPMi-.js";export{o as default};
