import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoNotification1-D4CYfi1t.js";export{a as default};
