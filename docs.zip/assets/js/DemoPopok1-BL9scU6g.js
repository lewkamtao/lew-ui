import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoPopok1-D7Ie5uCH.js";export{a as default};
