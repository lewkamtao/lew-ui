import"./lew-ui-CDhnpYIO.js";import{t}from"./DemoColorPicker2-DxXci9vG.js";export{t as default};
