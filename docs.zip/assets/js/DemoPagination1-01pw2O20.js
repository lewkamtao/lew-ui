import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoPagination1-CwuTgvR-.js";export{o as default};
