import"./lew-ui-D0fj-lLn.js";import"./vendor-DI90tgK9.js";import{t as m}from"./DemoDropdown2-DHEgYLWV.js";export{m as default};
