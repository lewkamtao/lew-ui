import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTabs1-BsKJfoyC.js";export{o as default};
