import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoBadge1--B311id_.js";export{e as default};
