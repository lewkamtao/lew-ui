import{r as l}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as a,Ci as d,Li as p,ct as s,i as m,mi as u,pi as o,ui as g}from"./lew-ui-D0fj-lLn.js";import{fa as c}from"./vendor-DI90tgK9.js";import{t as w}from"./LewComponentInfo-DEhjborz.js";import{n as i,t as f}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as _}from"./DemoBadge1-C-HNzxvB.js";import{t as b}from"./DemoBadge2-BGxRgBuu.js";import{t as v}from"./DemoBadge3-eGbsxC7R.js";import{t as x}from"./DemoBadge4-C6vC4QVa.js";import{t as B}from"./DemoBadge5-DEsEixX1.js";var D={title:"Props",columnsKey:"props",data:m(s)},r=l({props:()=>D},1),h=`<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge value="6" round color="red">
      <lew-avatar
        shape="circle"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_1_ctd06i_.jpeg"
      />
    </lew-badge>

    <lew-badge value="New" type="light" color="green">
      <lew-avatar
        size="50"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_2_2s0nai_.jpeg"
      />
    </lew-badge>

    <lew-badge round color="red" value="142232" :max="99">
      <lew-avatar
        size="60"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_3_kntap6_.jpeg"
      />
    </lew-badge>
  </lew-flex>
</template>
`,y=`<script setup lang="ts">
import { Activity, Home, Search } from 'lucide-vue-next'
<\/script>

<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge round color="blue">
      <Activity :size="18" />
    </lew-badge>
    <lew-badge round>
      <Home :size="27" />
    </lew-badge>
    <lew-badge round color="green">
      <Search :size="36" />
    </lew-badge>
  </lew-flex>
</template>
`,L=`<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge value="5" />
    <lew-badge value="15" type="light" color="blue" />
    <lew-badge value="65" color="green" />
    <lew-badge value="9" color="warning" />
    <lew-badge value="99+" color="red" />
    <lew-badge round />
    <lew-badge round type="light" color="blue" />
    <lew-badge round color="green" />
    <lew-badge round color="warning" />
    <lew-badge round />
  </lew-flex>
</template>
`,j=`<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge round color="success" text="Success" />
    <lew-badge round color="warning" text="Warning" />
    <lew-badge round color="error" text="Error" />
    <lew-badge round color="info" text="Info" />
    <lew-badge round color="primary" text="Primary" />
  </lew-flex>
</template>
`,k=`<script setup lang="ts">
import { Home } from 'lucide-vue-next'
<\/script>

<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge round color="red" processing>
      <Home />
    </lew-badge>
    <lew-badge round color="blue" text="Processing" processing />
  </lew-flex>
</template>
`;const C=[_,b,v,x,B],z=[h,y,L,j,k];var P={class:"demo-wrapper"},$=u({__name:"DemoBadge",setup(A){const n=c().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),t=p(Object.keys(r).map(e=>r[e]));return(e,N)=>(d(),g("div",P,[o(w),o(i,{"demo-group":a(C),"code-group":a(z),"component-name":a(n),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),o(f,{options:a(t)},null,8,["options"])]))}}),H=$,q=H;export{q as default};
