import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoBreadcrumb2-GqqXIlr5.js";export{a as default};
