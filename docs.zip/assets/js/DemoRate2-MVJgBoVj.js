import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoRate2-9M7Y7h8d.js";export{e as default};
