import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoCheckbox4-CtE8-ieY.js";export{e as default};
