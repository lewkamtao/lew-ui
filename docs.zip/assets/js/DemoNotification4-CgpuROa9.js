import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoNotification4-BZNfEr-H.js";export{a as default};
