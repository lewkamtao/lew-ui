import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAlert2-BKE0ppGU.js";export{o as default};
