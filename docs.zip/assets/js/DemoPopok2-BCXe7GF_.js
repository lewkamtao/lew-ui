import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoPopok2-iRHBPSD7.js";export{a as default};
