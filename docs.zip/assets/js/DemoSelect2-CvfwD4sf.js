import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSelect2-DPQuhPhf.js";export{o as default};
