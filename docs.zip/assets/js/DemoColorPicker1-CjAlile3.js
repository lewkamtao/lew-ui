import"./lew-ui-Bz7GIUSM.js";import{t}from"./DemoColorPicker1-Btv4rMml.js";export{t as default};
