import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea6-1AvNghif.js";export{e as default};
