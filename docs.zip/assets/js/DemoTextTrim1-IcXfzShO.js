import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoTextTrim1-DIevX6Xk.js";export{m as default};
