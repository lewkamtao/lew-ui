import"./lew-ui-D0fj-lLn.js";import{t}from"./DemoColorPicker2-BougCgHH.js";export{t as default};
