import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoMessage2-D7N1bJ5d.js";export{a as default};
