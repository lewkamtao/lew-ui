import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as e}from"./DemoTable7-BWoZwiqM.js";export{e as default};
