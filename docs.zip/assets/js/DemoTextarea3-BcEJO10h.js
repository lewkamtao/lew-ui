import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea3-07Esw2vl.js";export{e as default};
