import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable4-DIn6L_PU.js";export{e as default};
