import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect2-Cy3jdJMq.js";export{o as default};
