import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable10-6tcDj0Dx.js";export{e as default};
