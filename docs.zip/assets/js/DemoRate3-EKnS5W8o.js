import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoRate3-3vEl6mSI.js";export{e as default};
