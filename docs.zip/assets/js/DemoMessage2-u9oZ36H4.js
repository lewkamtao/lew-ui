import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoMessage2-ClR_rbQw.js";export{a as default};
