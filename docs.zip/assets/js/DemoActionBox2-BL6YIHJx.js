import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as r}from"./DemoActionBox2-D3MLtUpY.js";export{r as default};
