import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoCheckbox4-DKnKoi7U.js";export{e as default};
