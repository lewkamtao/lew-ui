import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoTooltip4-B08VoQRe.js";export{a as default};
