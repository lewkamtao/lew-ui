import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoLoading2-yYcfcFDX.js";export{a as default};
