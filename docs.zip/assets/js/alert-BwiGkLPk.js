import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as t,Ci as s,Li as p,Ln as i,i as m,mi as u,pi as n,ui as c}from"./lew-ui-D0fj-lLn.js";import{fa as w}from"./vendor-DI90tgK9.js";import{t as f}from"./LewComponentInfo-DEhjborz.js";import{n as d,t as y}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as g}from"./DemoAlert1-D5lPGPTn.js";import{t as b}from"./DemoAlert2-uheYrZU4.js";import{t as v}from"./DemoAlert3-Dh_6L5te.js";var _={title:"Props",columnsKey:"props",data:m(i)},l=r({props:()=>_},1),x=`<template>
  <lew-flex direction="y">
    <lew-alert
      type="error"
      title="Payment Failed"
      content="Your Apple Pay payment failed. Please check your card information."
    />

    <lew-alert
      type="success"
      title="Subscription Successful"
      content="You have successfully subscribed to Apple Music."
    />

    <lew-alert
      type="warning"
      title="Storage Almost Full"
      content="Your iCloud storage is almost full. Please upgrade your storage plan."
    />

    <lew-alert
      type="info"
      title="New Service Available"
      content="Apple Fitness+ is now available. Get professional fitness guidance at home."
    />
  </lew-flex>
</template>
`,h=`<template>
  <lew-flex direction="y">
    <lew-alert type="error">
      <template #title>
        Sign In Failed
      </template>
      <template #content>
        Your sign-in attempt failed. Please check your username and password.
      </template>
    </lew-alert>

    <lew-alert type="success">
      <template #title>
        Registration Complete
      </template>
      <template #content>
        You have successfully registered for Google services.
      </template>
    </lew-alert>

    <lew-alert type="warning">
      <template #title>
        System Maintenance
      </template>
      <template #content>
        The system will be under maintenance tonight. Please complete your work
        in advance.
      </template>
    </lew-alert>

    <lew-alert type="info">
      <template #title>
        New Feature Available
      </template>
      <template #content>
        Google Photos is now available with enhanced photo management features.
      </template>
    </lew-alert>

    <lew-alert type="normal">
      <template #title>
        System Update Required
      </template>
      <template #content>
        Your system needs to be updated. Please update as soon as possible to
        ensure security.
      </template>
    </lew-alert>
  </lew-flex>
</template>
`,A=`<script setup lang="ts">
const visibleWarning = ref(true)
const visibleInfo = ref(true)
<\/script>

<template>
  <lew-flex style="width: 500px" direction="y">
    <lew-alert type="error">
      <template #title>
        Sign In Failed
      </template>
      <template #content>
        Your sign-in attempt failed. Please check your username and
        password.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button round type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button round type="light" color="red" size="small">
            Try Again
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>

    <lew-alert type="success">
      <template #title>
        Registration Complete
      </template>
      <template #content>
        You have successfully registered for Google services.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button round color="success" size="small">
            Continue
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>

    <lew-alert
      v-if="visibleWarning"
      type="warning"
      closeable
      @close="visibleWarning = false"
    >
      <template #title>
        System Maintenance
      </template>
      <template #content>
        The system will be under maintenance tonight. Please complete your work
        in advance.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button color="warning" size="small">
            Learn More
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>

    <lew-alert
      v-if="visibleInfo"
      type="info"
      closeable
      @close="visibleInfo = false"
    >
      <template #title>
        New Feature Available
      </template>
      <template #content>
        Google Photos is now available with enhanced photo management
        features.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button type="light" size="small">
            Explore
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>
  </lew-flex>
</template>
`;const D=[g,b,v],P=[x,h,A];var S={class:"demo-wrapper"},L=u({__name:"DemoAlert",setup(z){const a=w().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),o=p(Object.keys(l).map(e=>l[e]));return(e,C)=>(s(),c("div",S,[n(f),n(d,{"demo-group":t(D),"code-group":t(P),"component-name":t(a),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),n(y,{options:t(o)},null,8,["options"])]))}}),k=L,W=k;export{W as default};
