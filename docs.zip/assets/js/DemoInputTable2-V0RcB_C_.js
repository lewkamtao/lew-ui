import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoInputTable2-CJm-PNk0.js";export{e as default};
