import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoDesc3-CCZnkNjf.js";export{o as default};
