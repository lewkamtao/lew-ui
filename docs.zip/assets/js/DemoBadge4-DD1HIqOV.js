import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoBadge4-DBuRCTp4.js";export{e as default};
