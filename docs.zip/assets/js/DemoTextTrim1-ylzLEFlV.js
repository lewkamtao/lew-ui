import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoTextTrim1-CrwhnACa.js";export{m as default};
