import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoDialog3-DImh02iQ.js";export{a as default};
