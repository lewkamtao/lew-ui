import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoInputTag8-CL6qqrMZ.js";export{o as default};
