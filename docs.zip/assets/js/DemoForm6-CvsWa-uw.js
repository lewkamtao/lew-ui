import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoForm6--5n-fuEP.js";export{m as default};
