import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoTextTrim4-BhwaSqNL.js";export{m as default};
