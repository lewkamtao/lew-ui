import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoCheckbox4-BpWBHfNJ.js";export{e as default};
