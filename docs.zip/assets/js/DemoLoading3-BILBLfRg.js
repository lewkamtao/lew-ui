import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoLoading3-HmYgOOkF.js";export{a as default};
