import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoMessage1-Cl-lsiTI.js";export{a as default};
