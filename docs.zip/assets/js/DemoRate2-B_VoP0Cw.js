import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoRate2-CmzEMcAI.js";export{e as default};
