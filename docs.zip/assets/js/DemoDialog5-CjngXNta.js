import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDialog5-Bs5zwYTa.js";export{a as default};
