import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoCascader8-DWmEQ0Z7.js";export{e as default};
