import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoRate4-mXGxUvai.js";export{e as default};
