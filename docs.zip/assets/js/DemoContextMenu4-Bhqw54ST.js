import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoContextMenu4-Di5aAjre.js";export{o as default};
