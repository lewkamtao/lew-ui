import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoInputTag8-DRr4ZdpG.js";export{o as default};
