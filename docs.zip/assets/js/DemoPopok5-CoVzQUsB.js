import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoPopok5-Ca9pdoju.js";export{a as default};
