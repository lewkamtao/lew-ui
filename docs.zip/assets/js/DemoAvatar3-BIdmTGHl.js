import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoAvatar3-BB13CNXp.js";export{o as default};
