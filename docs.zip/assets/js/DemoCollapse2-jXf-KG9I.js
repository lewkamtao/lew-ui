import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoCollapse2-BIIhLhAv.js";export{a as default};
