import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoCheckbox2-B2l9CAo8.js";export{e as default};
