import"./lew-ui-CDhnpYIO.js";import{t}from"./DemoColorPicker3-BHK-r4d0.js";export{t as default};
