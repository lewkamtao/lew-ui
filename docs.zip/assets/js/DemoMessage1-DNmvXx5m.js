import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoMessage1-h6z1NJSJ.js";export{a as default};
