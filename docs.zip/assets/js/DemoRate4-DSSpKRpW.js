import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoRate4-qhEGbk4E.js";export{e as default};
