import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as e}from"./DemoTable7-NyNvlgvh.js";export{e as default};
