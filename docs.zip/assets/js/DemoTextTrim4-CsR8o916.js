import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoTextTrim4-D3uto68U.js";export{m as default};
