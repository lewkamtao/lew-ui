import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSlider6-BFL4mmeo.js";export{o as default};
