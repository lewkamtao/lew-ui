import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoButton5-vrToi9YH.js";export{a as default};
