import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput2-bHkKXkPa.js";export{a as default};
