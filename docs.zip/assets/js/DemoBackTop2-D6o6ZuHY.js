import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoBackTop2-DIbSKM3n.js";export{a as default};
