import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoModal2-DN9I9CUL.js";export{a as default};
