import{r as c}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as n,Ci as i,Li as u,_n as p,bn as d,gn as m,hn as b,i as o,mi as h,pi as t,r as l,ui as f,vn as v,yn as x}from"./lew-ui-D0fj-lLn.js";import{fa as k}from"./vendor-DI90tgK9.js";import{t as g}from"./LewComponentInfo-DEhjborz.js";import{n as _,t as C}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as F}from"./DemoCheckbox1-CBeLU-8P.js";import{t as w}from"./DemoCheckbox2-t8hY_HH2.js";import{t as y}from"./DemoCheckbox3-CqHuYS4N.js";import{t as D}from"./DemoCheckbox4-BpWBHfNJ.js";import{t as M}from"./DemoCheckbox5-Ck1VmnbN.js";import{t as P}from"./DemoCheckbox6-BQbO1Zbu.js";import{t as G}from"./DemoCheckbox7-C_WThosl.js";var V={title:"Emits",columnsKey:"emits",orderNum:99,data:l(x)},E={title:"Model(Checkbox)",columnsKey:"model",orderNum:2,data:o(m)},L={title:"Props(Checkbox)",columnsKey:"props",orderNum:4,data:o(v)},N={title:"Emits(CheckboxGroup)",columnsKey:"emits",orderNum:99,data:l(d)},B={title:"Model(CheckboxGroup)",columnsKey:"model",orderNum:1,data:o(b)},O={title:"Props(CheckboxGroup)",columnsKey:"props",orderNum:3,data:o(p)},a=c({checkboxEmits:()=>V,checkboxModel:()=>E,checkboxProps:()=>L,emits:()=>N,model:()=>B,props:()=>O},1),R=`<script setup lang="ts">
const socialMediaOptions = ref([
  { label: 'Google', value: 'google' },
  { label: 'Apple', value: 'apple' },
  { label: 'Microsoft', value: 'microsoft' },
  { label: 'Amazon', value: 'amazon' },
])

const selectedPlatforms = ref([])
<\/script>

<template>
  <lew-checkbox-group
    v-model="selectedPlatforms"
    :options="socialMediaOptions"
  />
</template>
`,$=`<script setup lang="ts">
const techOptions = ref([
  { label: 'Artificial Intelligence', value: 'ai' },
  { label: 'Blockchain', value: 'blockchain' },
  { label: 'Virtual Reality', value: 'vr' },
  { label: 'Quantum Computing', value: 'quantum' },
])

const selectedTech = ref([])
<\/script>

<template>
  <lew-checkbox-group
    v-model="selectedTech"
    direction="y"
    :options="techOptions"
  />
</template>
`,z=`<script setup lang="ts">
const socialMediaFeatures = ref([
  { label: 'Moments', value: 'moments' },
  { label: 'Live', value: 'live' },
  { label: 'Short Video', value: 'shortVideo', disabled: true },
  { label: 'Group Chat', value: 'groupChat' },
  { label: 'Video Call', value: 'videoCall' },
])

const selectedFeatures = ref(['moments', 'live'])

function handleFeatureChange(selectedValues: string[]) {
  console.log('Selected social media features:', selectedValues)
}
<\/script>

<template>
  <lew-checkbox-group
    v-model="selectedFeatures"
    block
    :options="socialMediaFeatures"
    @change="handleFeatureChange"
  />
</template>
`,A=`<script setup lang="ts">
const productFeatures = ref([
  { label: 'Dog', value: 'dog' },
  { label: 'Cat', value: 'cat' },
  { label: 'Rabbit', value: 'rabbit' },
  { label: 'Bird', value: 'bird' },
  { label: 'Fish', value: 'fish' },
  { label: 'Hamster', value: 'hamster' },
])

const selectedFeatures = ref([])
<\/script>

<template>
  <lew-flex direction="y" x="start">
    <lew-title :size="14">
      Without Icon Selection
    </lew-title>
    <lew-checkbox-group
      v-model="selectedFeatures"
      block
      round
      :iconable="false"
      direction="x"
      :options="productFeatures"
    />
    <lew-checkbox-group
      v-model="selectedFeatures"
      block
      :iconable="false"
      direction="x"
      :options="productFeatures"
    />
    <br>
    <br>
    <lew-title :size="14">
      With Icon Selection
    </lew-title>
    <lew-checkbox-group
      v-model="selectedFeatures"
      block
      size="small"
      round
      direction="x"
      :options="productFeatures"
    />

    <lew-checkbox-group
      v-model="selectedFeatures"
      block
      round
      direction="x"
      :options="productFeatures"
    />

    <lew-checkbox-group
      v-model="selectedFeatures"
      block
      round
      size="large"
      direction="x"
      :options="productFeatures"
    />
  </lew-flex>
</template>
`,K=`<script setup lang="ts">
const fruitOptions = ref([
  { label: 'Apple', value: 'apple' },
  { label: 'Banana', value: 'banana' },
  { label: 'Cherry', value: 'cherry' },
  { label: 'Date', value: 'date' },
  { label: 'Grape', value: 'grape' },
])

const selectedFruits = ref(['apple', 'banana'])

function handleFruitChange(selectedValues: string[]) {
  console.log('选中的水果:', selectedValues)
}
<\/script>

<template>
  <lew-checkbox-group
    v-model="selectedFruits"
    readonly
    :options="fruitOptions"
    @change="handleFruitChange"
  />
</template>
`,S=`<script setup lang="ts">
const applianceFeatures = ref([
  { label: 'Refrigerator', value: 'refrigerator' },
  { label: 'Washing Machine', value: 'washingMachine' },
  { label: 'Microwave', value: 'microwave' },
  { label: 'Air Conditioner', value: 'airConditioner' },
  { label: 'Television', value: 'television' },
])

const selectedFeatures = ref(['refrigerator', 'washingMachine'])

function handleFeatureChange(selectedValues: string[]) {
  console.log('Selected appliances:', selectedValues)
}
<\/script>

<template>
  <lew-checkbox-group
    v-model="selectedFeatures"
    disabled
    :options="applianceFeatures"
    @change="handleFeatureChange"
  />
</template>
`,I=`<script setup lang="ts">
const hasReadPrivacyPolicy = ref(false)
<\/script>

<template>
  <lew-checkbox
    v-model="hasReadPrivacyPolicy"
    label="Have you read the privacy policy?"
  />
</template>
`;const T=[F,w,y,D,M,P,G],W=[R,$,z,A,K,S,I];var H={class:"demo-wrapper"},j=h({__name:"DemoCheckbox",setup(Q){const r=k().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),s=u(Object.keys(a).map(e=>a[e]));return(e,Z)=>(i(),f("div",H,[t(g),t(_,{"demo-group":n(T),"code-group":n(W),"component-name":n(r),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(C,{options:n(s)},null,8,["options"])]))}}),q=j,ie=q;export{ie as default};
