import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoTextTrim1-SJx1_lPN.js";export{m as default};
