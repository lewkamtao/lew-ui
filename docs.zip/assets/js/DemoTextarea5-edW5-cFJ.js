import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea5-fQxQXT5L.js";export{e as default};
