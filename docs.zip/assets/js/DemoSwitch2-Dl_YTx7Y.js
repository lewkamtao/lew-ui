import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoSwitch2-9bZMoOSY.js";export{a as default};
