import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoPagination1-Cub8Jqlh.js";export{o as default};
