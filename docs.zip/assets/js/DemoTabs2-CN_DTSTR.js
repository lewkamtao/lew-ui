import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTabs2-D0zB2CiT.js";export{o as default};
