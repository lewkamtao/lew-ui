import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoRate1-D7n-Ad3E.js";export{e as default};
