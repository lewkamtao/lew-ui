import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoModal2-C84DJmQ0.js";export{a as default};
