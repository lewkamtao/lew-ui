import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoBadge3-upW0rgWd.js";export{e as default};
