import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoFlex2-DL8W3Nl1.js";export{o as default};
