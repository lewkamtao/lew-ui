import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as m}from"./DemoContextMenu1-Ba7iwL-F.js";export{m as default};
