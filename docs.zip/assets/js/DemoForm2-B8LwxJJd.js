import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoForm2-BZu1fm-2.js";export{m as default};
