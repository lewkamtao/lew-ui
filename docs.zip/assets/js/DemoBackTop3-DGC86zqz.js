import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoBackTop3-BthbR_ih.js";export{a as default};
