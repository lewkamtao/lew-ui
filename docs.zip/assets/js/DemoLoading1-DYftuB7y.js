import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoLoading1-BqoYXc3X.js";export{a as default};
