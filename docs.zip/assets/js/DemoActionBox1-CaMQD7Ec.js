import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoActionBox1-DyHspFpf.js";export{a as default};
