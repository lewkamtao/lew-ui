import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoButton6-D98rkaKx.js";export{a as default};
