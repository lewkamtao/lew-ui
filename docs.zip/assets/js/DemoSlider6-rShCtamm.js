import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSlider6-CACxe_Ys.js";export{o as default};
