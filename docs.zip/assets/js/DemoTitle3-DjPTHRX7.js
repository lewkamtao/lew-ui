import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTitle3-2QeWaaXa.js";export{o as default};
