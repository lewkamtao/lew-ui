import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoButton2-jojrI-AG.js";export{a as default};
