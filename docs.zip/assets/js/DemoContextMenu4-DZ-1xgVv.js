import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoContextMenu4-CpAuqhQE.js";export{o as default};
