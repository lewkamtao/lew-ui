import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea8-BIaOEwqH.js";export{e as default};
