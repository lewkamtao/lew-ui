import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoContextMenu3-DAeltJQ1.js";export{o as default};
