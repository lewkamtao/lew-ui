import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTabs6-DQ4my-V7.js";export{o as default};
