import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoDesc3-DmAybHV4.js";export{o as default};
