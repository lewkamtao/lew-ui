import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAlert1-yOEDeU1Z.js";export{o as default};
