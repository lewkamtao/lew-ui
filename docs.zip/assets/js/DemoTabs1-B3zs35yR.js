import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTabs1-LoUq2Rpf.js";export{o as default};
