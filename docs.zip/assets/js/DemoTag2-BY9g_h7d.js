import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTag2-BbGcnND2.js";export{o as default};
