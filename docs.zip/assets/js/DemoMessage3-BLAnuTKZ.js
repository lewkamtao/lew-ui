import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoMessage3-EA7INZV1.js";export{a as default};
