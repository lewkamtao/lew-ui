import"./lew-ui-D4rxVhOO.js";import"./vendor-DE_9brhS.js";import"./http-I7MJl4KM.js";import"./uploadHelper-EFZpM1EZ.js";import{t as i}from"./DemoForm1-Cjh4gZxl.js";export{i as default};
