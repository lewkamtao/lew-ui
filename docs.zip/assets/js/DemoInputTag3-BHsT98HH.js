import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoInputTag3-BQvCuqs9.js";export{o as default};
