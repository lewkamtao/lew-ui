import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTag4-irQprdkO.js";export{o as default};
