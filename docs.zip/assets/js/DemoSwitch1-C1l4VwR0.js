import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoSwitch1-Cd1oNfGZ.js";export{a as default};
