import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoButton4-B4cDXrNa.js";export{a as default};
