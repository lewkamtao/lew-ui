import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoCheckbox1-CBeLU-8P.js";export{e as default};
