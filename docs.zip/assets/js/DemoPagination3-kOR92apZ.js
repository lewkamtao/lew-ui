import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoPagination3-DeX5rPTN.js";export{o as default};
