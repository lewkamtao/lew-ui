import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag4-DryqxNaQ.js";export{o as default};
