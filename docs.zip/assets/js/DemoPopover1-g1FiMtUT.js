import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoPopover1-MyMee1f9.js";export{e as default};
