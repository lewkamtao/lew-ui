import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAlert1-pWl8hZpr.js";export{o as default};
