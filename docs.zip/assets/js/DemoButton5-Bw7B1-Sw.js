import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoButton5-J4Dnl_Bz.js";export{a as default};
