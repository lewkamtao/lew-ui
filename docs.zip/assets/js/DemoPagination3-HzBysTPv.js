import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoPagination3-I6Vsjtqh.js";export{o as default};
