import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTitle2-Dtnq7ILx.js";export{o as default};
