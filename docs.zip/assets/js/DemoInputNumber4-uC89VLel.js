import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoInputNumber4-Dl938VNx.js";export{m as default};
