import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoPagination1-DKyo_zVv.js";export{o as default};
