import"./lew-ui-Bz7GIUSM.js";import{t}from"./DemoColorPicker3-2ZHhqOHe.js";export{t as default};
