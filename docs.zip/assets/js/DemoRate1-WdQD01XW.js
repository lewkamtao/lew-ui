import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoRate1-BEM_vhkw.js";export{e as default};
