import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoForm2-CGtaf9Wi.js";export{m as default};
