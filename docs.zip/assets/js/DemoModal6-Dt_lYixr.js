import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoModal6-hr_8y72F.js";export{a as default};
