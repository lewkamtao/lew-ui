import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoInput10-WOLCGBc8.js";export{a as default};
