import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoMessage3-DJIb4pvj.js";export{a as default};
