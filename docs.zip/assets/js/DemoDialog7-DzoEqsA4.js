import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoDialog7-KxvK-is2.js";export{a as default};
