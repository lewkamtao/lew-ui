import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect10-R1PYVflO.js";export{o as default};
