import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoPopover5-A3mG4U-P.js";export{e as default};
