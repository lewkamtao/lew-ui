import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoNotification1-_6vM63WD.js";export{a as default};
