import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSelect12-DBobmOMJ.js";export{o as default};
