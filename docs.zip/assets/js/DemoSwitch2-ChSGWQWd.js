import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoSwitch2-DoZiqDK-.js";export{a as default};
