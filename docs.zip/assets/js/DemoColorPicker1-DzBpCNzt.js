import"./lew-ui-D4rxVhOO.js";import{t}from"./DemoColorPicker1-Cd5Q19XW.js";export{t as default};
