import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea7-DrTm3byq.js";export{e as default};
