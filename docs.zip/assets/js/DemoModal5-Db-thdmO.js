import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoModal5-B6bLVMu2.js";export{a as default};
