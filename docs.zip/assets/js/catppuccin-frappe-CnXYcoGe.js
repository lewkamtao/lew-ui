import{et as p}from"./vendor-DI90tgK9.js";export{p as default};
