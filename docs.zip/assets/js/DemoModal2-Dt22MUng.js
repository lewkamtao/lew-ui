import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoModal2-hL1CMkHH.js";export{a as default};
