import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoPopover3-CzFcl6wh.js";export{e as default};
