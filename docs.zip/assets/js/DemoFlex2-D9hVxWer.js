import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoFlex2-HhnFQzWD.js";export{o as default};
