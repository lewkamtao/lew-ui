import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoInputNumber1-VQJBXCVe.js";export{m as default};
