import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as o,Ci as m,K as l,Li as c,i as s,mi as u,pi as t,ui as i}from"./lew-ui-D0fj-lLn.js";import{fa as f}from"./vendor-DI90tgK9.js";import{t as _}from"./LewComponentInfo-DEhjborz.js";import{n as d,t as k}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as x}from"./DemoBackTop1-ZF1BA6co.js";import{t as v}from"./DemoBackTop2-DIbSKM3n.js";import{t as w}from"./DemoBackTop3-BthbR_ih.js";var g={title:"Props",columnsKey:"props",orderNum:1,data:s(l)},a=r({props:()=>g},1),B=`<template>
  <lew-flex style="height: 50vh" x="center" y="center" gap="20px">
    请往下滚动，留意右下角
    <lew-back-top target="component-main" :right="100" />
  </lew-flex>
</template>
`,b=`<template>
  <lew-flex style="height: 50vh" x="center" y="center" gap="20px">
    请往下滚动，留意右下角
    <lew-back-top target="component-main" />
    <lew-back-top :bottom="100" target="component-main">
      <div>UP</div>
    </lew-back-top>
  </lew-flex>
</template>
`,D=`<template>
  <lew-flex gap="20px" x="center" y="center">
    <lew-button
      v-backtop="{
        target: 'component-main',
      }"
      text="指令方式触发"
    />
  </lew-flex>
</template>
`;const T=[x,v,w],h=[B,b,D];var y={class:"demo-wrapper"},L=u({__name:"DemoBackTop",setup(P){const p=f().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),n=c(Object.keys(a).map(e=>a[e]));return(e,N)=>(m(),i("div",y,[t(_),t(d,{"demo-group":o(T),"code-group":o(h),"component-name":o(p),columns:1,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(k,{options:o(n)},null,8,["options"])]))}}),C=L,U=C;export{U as default};
