import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTitle1-Bo4O93Es.js";export{o as default};
