import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoInputTable1-B2utXL-K.js";export{e as default};
