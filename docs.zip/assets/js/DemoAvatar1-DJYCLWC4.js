import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAvatar1-CbWSsjDL.js";export{o as default};
