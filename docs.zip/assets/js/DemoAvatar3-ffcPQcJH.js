import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAvatar3-D7Xg8bC5.js";export{o as default};
