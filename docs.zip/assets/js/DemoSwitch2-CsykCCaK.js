import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoSwitch2-CQVAeJjB.js";export{a as default};
