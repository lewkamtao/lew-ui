import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable5-BIkIxmuf.js";export{e as default};
