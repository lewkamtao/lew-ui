import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoSwitch1-C1xRDoTQ.js";export{a as default};
