import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable1-C8-OqFjS.js";export{e as default};
