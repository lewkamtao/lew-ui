import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoSwitch1-lwWmSQKo.js";export{a as default};
