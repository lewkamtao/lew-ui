import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable2-DJ4llfk8.js";export{e as default};
