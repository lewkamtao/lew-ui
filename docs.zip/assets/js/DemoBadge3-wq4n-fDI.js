import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoBadge3-eGbsxC7R.js";export{e as default};
