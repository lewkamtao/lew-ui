import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTabs5-DwrCqBfZ.js";export{o as default};
