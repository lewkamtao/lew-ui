import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoContextMenu3-Xj_TQzJa.js";export{o as default};
