import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoTooltip3-CdcBcPkI.js";export{a as default};
