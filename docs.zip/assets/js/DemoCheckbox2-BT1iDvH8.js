import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoCheckbox2-t8hY_HH2.js";export{e as default};
