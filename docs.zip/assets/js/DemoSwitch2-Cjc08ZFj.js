import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoSwitch2-KqMy8ten.js";export{a as default};
