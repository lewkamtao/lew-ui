import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoBackTop3-Cx3b1VAW.js";export{a as default};
