import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoRate1-Bc3__9FY.js";export{e as default};
