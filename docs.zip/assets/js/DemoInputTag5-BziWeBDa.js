import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoInputTag5-B-GPgeVU.js";export{o as default};
