import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoFlex1-B0gzFE9h.js";export{o as default};
