import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAvatar4-Rg29U-Nr.js";export{o as default};
