import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable6-BPtKyGoK.js";export{e as default};
