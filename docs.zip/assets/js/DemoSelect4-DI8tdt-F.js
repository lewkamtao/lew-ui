import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSelect4-D_P4pS4V.js";export{o as default};
