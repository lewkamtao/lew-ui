import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoDialog7-DErzcaJ5.js";export{a as default};
