import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoCheckbox3-qYYOFbEX.js";export{e as default};
