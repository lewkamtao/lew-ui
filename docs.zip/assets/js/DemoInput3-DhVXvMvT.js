import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput3-BVsISm1z.js";export{a as default};
