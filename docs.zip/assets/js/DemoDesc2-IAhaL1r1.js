import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoDesc2-CmCPU6Qo.js";export{o as default};
