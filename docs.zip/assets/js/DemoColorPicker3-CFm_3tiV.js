import"./lew-ui-BmI9Z0Xx.js";import{t}from"./DemoColorPicker3-DXaOupxi.js";export{t as default};
