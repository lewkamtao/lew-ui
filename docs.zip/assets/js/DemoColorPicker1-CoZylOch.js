import"./lew-ui-CDhnpYIO.js";import{t}from"./DemoColorPicker1-CGzusLgQ.js";export{t as default};
