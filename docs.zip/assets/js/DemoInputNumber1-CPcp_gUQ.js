import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoInputNumber1-BYcX-6AZ.js";export{m as default};
