import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoPopover5-Bh5-lqCG.js";export{e as default};
