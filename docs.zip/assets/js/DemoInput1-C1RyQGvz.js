import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoInput1-DLrz0rtm.js";export{a as default};
