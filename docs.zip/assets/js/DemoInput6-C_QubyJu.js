import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput6-3P2Tr9Ck.js";export{a as default};
