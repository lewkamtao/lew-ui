import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as m}from"./DemoMenu1-BvqwBkPe.js";export{m as default};
