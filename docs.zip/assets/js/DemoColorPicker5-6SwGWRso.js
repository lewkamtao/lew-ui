import"./lew-ui-D0fj-lLn.js";import{t}from"./DemoColorPicker5-DsyHz_oD.js";export{t as default};
