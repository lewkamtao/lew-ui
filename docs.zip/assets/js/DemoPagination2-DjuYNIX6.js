import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoPagination2-CPzuXHsB.js";export{o as default};
