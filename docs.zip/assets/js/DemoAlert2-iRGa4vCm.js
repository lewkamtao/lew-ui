import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAlert2-DQrg_WSl.js";export{o as default};
