import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoAvatar1-Bztvlj38.js";export{o as default};
