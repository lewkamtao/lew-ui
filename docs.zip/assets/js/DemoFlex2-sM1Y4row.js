import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoFlex2-vKfmtZ1r.js";export{o as default};
