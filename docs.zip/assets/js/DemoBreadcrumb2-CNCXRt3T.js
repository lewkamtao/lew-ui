import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoBreadcrumb2-CkVJMbkK.js";export{a as default};
