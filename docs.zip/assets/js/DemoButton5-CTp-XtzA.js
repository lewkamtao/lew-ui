import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoButton5-Cqhe4d6F.js";export{a as default};
