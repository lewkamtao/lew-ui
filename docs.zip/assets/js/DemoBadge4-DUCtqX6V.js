import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoBadge4-T5j-bb0I.js";export{e as default};
