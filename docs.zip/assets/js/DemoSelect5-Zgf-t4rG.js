import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSelect5-D8Q_cHJ_.js";export{o as default};
