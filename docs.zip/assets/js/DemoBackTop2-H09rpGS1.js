import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoBackTop2-CHqu1fsP.js";export{a as default};
