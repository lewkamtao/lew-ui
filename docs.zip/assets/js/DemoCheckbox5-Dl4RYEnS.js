import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoCheckbox5-DfN6z-Yv.js";export{e as default};
