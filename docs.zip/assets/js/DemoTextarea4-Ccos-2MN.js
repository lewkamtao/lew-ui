import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea4-De5InVJ0.js";export{e as default};
