import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoInputNumber4-CHuT-f1l.js";export{m as default};
