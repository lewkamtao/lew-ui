import"./lew-ui-D4rxVhOO.js";import{t}from"./DemoColorPicker2-DMPXJNwb.js";export{t as default};
