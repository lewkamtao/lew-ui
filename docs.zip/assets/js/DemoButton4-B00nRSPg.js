import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoButton4-BwjeZBWz.js";export{a as default};
