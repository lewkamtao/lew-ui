import"./lew-ui-D0fj-lLn.js";import"./vendor-DI90tgK9.js";import{t as e}from"./DemoBadge5-DEsEixX1.js";export{e as default};
