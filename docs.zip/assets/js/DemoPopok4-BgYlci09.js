import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoPopok4-B1stDI7i.js";export{a as default};
