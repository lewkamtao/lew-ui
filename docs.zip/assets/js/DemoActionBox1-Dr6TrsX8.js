import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoActionBox1-DYMto5ae.js";export{a as default};
