import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoDesc3-BTvcQy6-.js";export{o as default};
