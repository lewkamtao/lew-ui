import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoPagination2-CSaKfjTs.js";export{o as default};
