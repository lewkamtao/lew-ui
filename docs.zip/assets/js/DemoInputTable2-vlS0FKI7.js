import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoInputTable2-dosJn8rP.js";export{e as default};
