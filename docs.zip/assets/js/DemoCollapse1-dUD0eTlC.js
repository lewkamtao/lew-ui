import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoCollapse1-HXmDcDAW.js";export{a as default};
