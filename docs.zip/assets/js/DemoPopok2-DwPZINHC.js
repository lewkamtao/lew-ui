import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoPopok2-BKrkiDv9.js";export{a as default};
