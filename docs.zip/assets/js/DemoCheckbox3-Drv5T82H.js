import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoCheckbox3-CqHuYS4N.js";export{e as default};
