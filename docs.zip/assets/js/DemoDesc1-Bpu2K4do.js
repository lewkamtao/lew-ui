import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoDesc1-Ccfln_pi.js";export{o as default};
