import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea2-CxSPL1m6.js";export{e as default};
