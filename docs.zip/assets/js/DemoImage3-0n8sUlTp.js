import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoImage3-Qgd04Xxa.js";export{e as default};
