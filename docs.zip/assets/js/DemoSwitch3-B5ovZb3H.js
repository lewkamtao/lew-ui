import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoSwitch3-CHOOsxlC.js";export{a as default};
