import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoCollapse1-BsI9DEeR.js";export{a as default};
