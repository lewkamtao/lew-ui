import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoPopover4-2-jBncVQ.js";export{e as default};
