import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput4-fDaOozmr.js";export{a as default};
