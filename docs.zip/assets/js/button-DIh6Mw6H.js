import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as e,Ci as p,Li as w,at as a,i as b,mi as i,ot as s,pi as n,r as c,ui as y}from"./lew-ui-D0fj-lLn.js";import{fa as m}from"./vendor-DI90tgK9.js";import{t as g}from"./LewComponentInfo-DEhjborz.js";import{n as d,t as f}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as x}from"./DemoButton1-BwWif5zP.js";import{t as h}from"./DemoButton2-I2evh8Uk.js";import{t as _}from"./DemoButton3-C2q-VKj3.js";import{t as v}from"./DemoButton4-GtWmkrXm.js";import{t as D}from"./DemoButton5-J4Dnl_Bz.js";import{t as k}from"./DemoButton6-D98rkaKx.js";var B={title:"Emits",columnsKey:"emits",orderNum:99,data:c(s)},z={title:"Props",columnsKey:"props",data:b(a)},o=r({emits:()=>B,props:()=>z},1),S=`<template>
  <lew-flex direction="y" gap="20px">
    <lew-flex wrap x="start" gap="10">
      <lew-button size="mini" text="FILL" type="fill" />
      <lew-button size="small" text="TEXT" type="text" />
      <lew-button size="medium" text="LIGHT" type="light" />
      <lew-button size="large" text="GHOST" type="ghost" />
      <lew-button size="large" text="GHOST + DASHED" dashed type="ghost" />
    </lew-flex>
  </lew-flex>
</template>
`,L=`<template>
  <lew-flex x="start">
    <div>
      <lew-flex direction="y" x="start" gap="10px">
        <lew-flex y="end" x="start">
          <lew-button type="fill" color="red">
            red
          </lew-button>
          <lew-button type="fill" color="orange">
            orange
          </lew-button>
          <lew-button type="fill" color="yellow">
            yellow
          </lew-button>
          <lew-button type="fill" color="green">
            green
          </lew-button>
          <lew-button type="fill" color="mint">
            mint
          </lew-button>
          <lew-button type="fill" color="teal">
            teal
          </lew-button>
          <lew-button type="fill" color="cyan">
            cyan
          </lew-button>
          <lew-button type="fill" color="blue">
            blue
          </lew-button>
          <lew-button type="fill" color="indigo">
            indigo
          </lew-button>
          <lew-button type="fill" color="purple">
            purple
          </lew-button>
          <lew-button type="fill" color="pink">
            pink
          </lew-button>
          <lew-button type="fill" color="brown">
            brown
          </lew-button>
          <lew-button type="fill" color="gray">
            gray
          </lew-button>
          <lew-button type="fill" color="black">
            black
          </lew-button>
        </lew-flex>
        <lew-flex y="end" x="start">
          <lew-button type="light" color="red">
            red
          </lew-button>
          <lew-button type="light" color="orange">
            orange
          </lew-button>
          <lew-button type="light" color="yellow">
            yellow
          </lew-button>
          <lew-button type="light" color="green">
            green
          </lew-button>
          <lew-button type="light" color="mint">
            mint
          </lew-button>
          <lew-button type="light" color="teal">
            teal
          </lew-button>
          <lew-button type="light" color="cyan">
            cyan
          </lew-button>
          <lew-button type="light" color="blue">
            blue
          </lew-button>
          <lew-button type="light" color="indigo">
            indigo
          </lew-button>
          <lew-button type="light" color="purple">
            purple
          </lew-button>
          <lew-button type="light" color="pink">
            pink
          </lew-button>
          <lew-button type="light" color="brown">
            brown
          </lew-button>
          <lew-button type="light" color="gray">
            gray
          </lew-button>
          <lew-button type="light" color="black">
            black
          </lew-button>
        </lew-flex>
        <lew-flex y="end" x="start">
          <lew-button type="ghost" color="red">
            red
          </lew-button>
          <lew-button type="ghost" color="orange">
            orange
          </lew-button>
          <lew-button type="ghost" color="yellow">
            yellow
          </lew-button>
          <lew-button type="ghost" color="green">
            green
          </lew-button>
          <lew-button type="ghost" color="mint">
            mint
          </lew-button>
          <lew-button type="ghost" color="teal">
            teal
          </lew-button>
          <lew-button type="ghost" color="cyan">
            cyan
          </lew-button>
          <lew-button type="ghost" color="blue">
            blue
          </lew-button>
          <lew-button type="ghost" color="indigo">
            indigo
          </lew-button>
          <lew-button type="ghost" color="purple">
            purple
          </lew-button>
          <lew-button type="ghost" color="pink">
            pink
          </lew-button>
          <lew-button type="ghost" color="brown">
            brown
          </lew-button>
          <lew-button type="ghost" color="gray">
            gray
          </lew-button>
          <lew-button type="ghost" color="black">
            black
          </lew-button>
        </lew-flex>
        <lew-flex y="end" x="start">
          <lew-button type="text" color="red">
            red
          </lew-button>
          <lew-button type="text" color="orange">
            orange
          </lew-button>
          <lew-button type="text" color="yellow">
            yellow
          </lew-button>
          <lew-button type="text" color="green">
            green
          </lew-button>
          <lew-button type="text" color="mint">
            mint
          </lew-button>
          <lew-button type="text" color="teal">
            teal
          </lew-button>
          <lew-button type="text" color="cyan">
            cyan
          </lew-button>
          <lew-button type="text" color="blue">
            blue
          </lew-button>
          <lew-button type="text" color="indigo">
            indigo
          </lew-button>
          <lew-button type="text" color="purple">
            purple
          </lew-button>
          <lew-button type="text" color="pink">
            pink
          </lew-button>
          <lew-button type="text" color="brown">
            brown
          </lew-button>
          <lew-button type="text" color="gray">
            gray
          </lew-button>
          <lew-button type="text" color="black">
            black
          </lew-button>
        </lew-flex>
      </lew-flex>
    </div>
  </lew-flex>
</template>
`,T=`<script setup lang="ts">
import { Activity, Search, Send } from 'lucide-vue-next'
<\/script>

<template>
  <lew-flex x="start" y="end">
    <lew-button type="fill" single-icon size="small" round>
      <Activity :size="16" />
    </lew-button>
    <lew-button type="light" round single-icon>
      <Send :size="16" />
    </lew-button>
    <lew-button type="ghost" round single-icon>
      <Search :size="16" />
    </lew-button>
  </lew-flex>
</template>
`,E=`<template>
  <lew-flex wrap x="start" y="end" gap="20px">
    <lew-button size="mini" round loading text="Submit" type="fill" />
    <lew-button size="small" round loading text="Submit" type="light" />
    <lew-button size="medium" round loading text="Submit" type="light" />
    <lew-button size="large" round loading text="Submit" type="ghost" />
  </lew-flex>
</template>
`,$=`<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-button text="Disabled" disabled />
    <lew-button text="Disabled" type="light" disabled />
  </lew-flex>
</template>
`,G=`<script setup lang="ts">
function handleRequest() {
  return new Promise<void>((resolve) => {
    setTimeout(() => {
      resolve()
      LewMessage.success('Submit success')
    }, 1000)
  })
}
<\/script>

<template>
  <lew-flex wrap x="start" y="end" gap="20px">
    <lew-button :request="handleRequest" text="Submit" type="light" />
  </lew-flex>
</template>
`;const A=[x,h,_,v,D,k],C=[S,L,T,E,$,G];var H={class:"demo-wrapper"},P=i({__name:"DemoButton",setup(q){const l=m().name.replace("R-Lew","").replace(/^[A-Z]/,t=>t.toLowerCase()),u=w(Object.keys(o).map(t=>o[t]));return(t,I)=>(p(),y("div",H,[n(g),n(d,{"demo-group":e(A),"code-group":e(C),"component-name":e(l),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),n(f,{options:e(u)},null,8,["options"])]))}}),R=P,W=R;export{W as default};
