import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTable5-BMpkcBd6.js";export{e as default};
