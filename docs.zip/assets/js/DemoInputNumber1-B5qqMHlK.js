import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoInputNumber1-DkEY3_L7.js";export{m as default};
