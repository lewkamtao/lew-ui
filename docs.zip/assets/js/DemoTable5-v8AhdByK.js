import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable5-CD4svmDa.js";export{e as default};
