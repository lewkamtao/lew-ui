import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoCollapse3-Cbj-Y0jC.js";export{a as default};
