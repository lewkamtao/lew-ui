import"./lew-ui-BmI9Z0Xx.js";import{t}from"./DemoColorPicker1-jraqnzm6.js";export{t as default};
