import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoDialog2-9WKZtd2y.js";export{a as default};
