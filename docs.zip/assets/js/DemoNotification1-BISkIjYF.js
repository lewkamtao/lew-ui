import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoNotification1-DAwCzmm7.js";export{a as default};
