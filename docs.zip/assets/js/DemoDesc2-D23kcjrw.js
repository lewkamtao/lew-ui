import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoDesc2-ynND3pWn.js";export{o as default};
