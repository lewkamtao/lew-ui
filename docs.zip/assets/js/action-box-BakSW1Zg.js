import{r as a}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as e,Ci as l,J as r,Li as c,i as p,mi as d,pi as o,q as w,r as m,ui as f}from"./lew-ui-D0fj-lLn.js";import{fa as h}from"./vendor-DI90tgK9.js";import{t as u}from"./DemoActionBox1-CYT43lip.js";import{t as g}from"./DemoActionBox2-DKFbBTUg.js";import{t as C}from"./DemoActionBox3-DTXuNRZp.js";import{t as b}from"./DemoActionBox4-BadYv_Hm.js";import{t as D}from"./LewComponentInfo-DEhjborz.js";import{n as L,t as _}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";var M={title:"Emits",columnsKey:"emits",orderNum:99,data:m(r)},z={title:"Props",columnsKey:"props",data:p(w)},i=a({emits:()=>M,props:()=>z},1),k=`<script setup lang="ts">
const options = ref([
  {
    label: 'Edit',
    onClick: () => {
      LewMessage.info('Edit')
    },
  },
  {
    label: 'Delete',
    onClick: () => {
      LewMessage.info('Delete')
    },
  },
  {
    label: 'Copy',
    onClick: () => {
      LewMessage.info('Copy')
    },
  },
  {
    label: 'Download',
    onClick: () => {
      LewMessage.info('Download')
    },
  },
])
<\/script>

<template>
  <lew-action-box :options="options" />
</template>
`,v=`<script setup lang="ts">
import {
  Archive,
  Copy,
  Download,
  Edit,
  MoreHorizontal,
  Settings,
  Share,
  Trash,
  View,
} from 'lucide-vue-next'

const options = ref([
  {
    label: 'Edit',
    icon: h(Edit, { size: 14 }),
    onClick: () => {
      LewMessage.info('Edit')
    },
  },
  {
    label: 'Delete',
    icon: () => h(Trash, { size: 14 }),
    onClick: () => {
      LewMessage.info('Delete')
    },
  },
  {
    label: 'Copy',
    icon: () => h(Copy, { size: 14 }),
    onClick: () => {
      LewMessage.info('Copy')
    },
  },
  {
    label: 'Download',
    icon: () => h(Download, { size: 14 }),
    onClick: () => {
      LewMessage.info('Download')
    },
  },
  {
    label: 'Share',
    icon: () => h(Share, { size: 14 }),
    onClick: () => {
      LewMessage.info('Share')
    },
  },
  {
    label: 'View',
    icon: () => h(View, { size: 14 }),
    onClick: () => {
      LewMessage.info('View')
    },
  },
  {
    label: 'Archive',
    icon: () => h(Archive, { size: 14 }),
    onClick: () => {
      LewMessage.info('Archive')
    },
  },
  {
    label: 'Settings',
    icon: () => h(Settings, { size: 14 }),
    onClick: () => {
      LewMessage.info('Settings')
    },
  },
])

const dropdownIcon = h(MoreHorizontal, { size: 14 })
<\/script>

<template>
  <lew-action-box
    :options="options"
    :dropdown-threshold="2"
    :dropdown-icon="dropdownIcon"
  />
</template>
`,x=`<script setup lang="ts">
import {
  Archive,
  Copy,
  Download,
  Edit,
  MoreHorizontal,
  Settings,
  Share,
  Trash,
  View,
} from 'lucide-vue-next'

const options = ref([
  {
    label: 'Edit',
    icon: () => h(Edit, { size: 14 }),
    onClick: () => {
      LewMessage.info('Edit')
    },
  },
  {
    label: 'Delete',
    icon: () => h(Trash, { size: 14 }),
    onClick: () => {
      LewMessage.info('Delete')
    },
  },
  {
    label: 'Copy',
    icon: () => h(Copy, { size: 14 }),
    onClick: () => {
      LewMessage.info('Copy')
    },
  },
  {
    label: 'Download',
    icon: () => h(Download, { size: 14 }),
    onClick: () => {
      LewMessage.info('Download')
    },
  },
  {
    label: 'Share',
    icon: () => h(Share, { size: 14 }),
    onClick: () => {
      LewMessage.info('Share')
    },
  },
  {
    label: 'View',
    icon: () => h(View, { size: 14 }),
    onClick: () => {
      LewMessage.info('View')
    },
  },
  {
    label: 'Archive',
    icon: () => h(Archive, { size: 14 }),
    onClick: () => {
      LewMessage.info('Archive')
    },
  },
  {
    label: 'Settings',
    icon: () => h(Settings, { size: 14 }),
    onClick: () => {
      LewMessage.info('Settings')
    },
  },
])

const dropdownIcon = h(MoreHorizontal, { size: 14 })
<\/script>

<template>
  <lew-action-box
    :options="options"
    :dropdown-threshold="2"
    dropdown-label=""
    :dropdown-icon="dropdownIcon"
    icon-only
  />
</template>
`,A=`<script setup lang="ts">
import {
  Archive,
  Copy,
  Download,
  Edit,
  MoreHorizontal,
  Settings,
  Share,
  Trash,
  View,
} from 'lucide-vue-next'

const options = ref([
  {
    label: 'Edit',
    icon: () => h(Edit, { size: 14 }),
    onClick: () => {
      LewMessage.info('Edit')
    },
  },
  {
    label: 'Delete',
    icon: () => h(Trash, { size: 14 }),
    onClick: () => {
      LewMessage.info('Delete')
    },
  },
  {
    label: 'Copy',
    icon: () => h(Copy, { size: 14 }),
    onClick: () => {
      LewMessage.info('Copy')
    },
  },
  {
    label: 'Download',
    icon: () => h(Download, { size: 14 }),
    onClick: () => {
      LewMessage.info('Download')
    },
  },
  {
    label: 'Share',
    icon: () => h(Share, { size: 14 }),
    onClick: () => {
      LewMessage.info('Share')
    },
  },
  {
    label: 'View',
    icon: () => h(View, { size: 14 }),
    onClick: () => {
      LewMessage.info('View')
    },
  },
  {
    label: 'Archive',
    icon: () => h(Archive, { size: 14 }),
    onClick: () => {
      LewMessage.info('Archive')
    },
  },
  {
    label: 'Settings',
    icon: () => h(Settings, { size: 14 }),
    onClick: () => {
      LewMessage.info('Settings')
    },
  },
])

const dropdownIcon = h(MoreHorizontal, { size: 14 })
<\/script>

<template>
  <lew-action-box
    :options="options"
    :dropdown-threshold="4"
    :dropdown-icon="dropdownIcon"
  />
</template>
`;const S=[u,g,C,b],y=[k,v,x,A];var E={class:"demo-wrapper"},B=d({__name:"DemoActionBox",setup(I){const t=h().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),s=c(Object.keys(i).map(n=>i[n]));return(n,T)=>(l(),f("div",E,[o(D),o(L,{"demo-group":e(S),"code-group":e(y),"component-name":e(t),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),o(_,{options:e(s)},null,8,["options"])]))}}),V=B,O=V;export{O as default};
