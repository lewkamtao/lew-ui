import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoForm3-CiioVVwF.js";export{m as default};
