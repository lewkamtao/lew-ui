import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSlider1-6sAfW0HI.js";export{o as default};
