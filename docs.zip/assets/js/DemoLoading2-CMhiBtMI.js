import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoLoading2-CgC5l_Nf.js";export{a as default};
