import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoNotification5-CR9GNWfB.js";export{a as default};
