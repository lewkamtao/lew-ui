import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoContextMenu4-BNPeedjC.js";export{o as default};
