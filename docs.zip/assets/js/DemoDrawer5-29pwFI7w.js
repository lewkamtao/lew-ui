import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoDrawer5-CqkkHaq4.js";export{a as default};
