import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoPopok3-Cd-F7hXt.js";export{a as default};
