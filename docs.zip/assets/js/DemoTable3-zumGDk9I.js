import"./lew-ui-D4rxVhOO.js";import"./vendor-DE_9brhS.js";import{t as e}from"./DemoTable3-CiEa3nlu.js";export{e as default};
