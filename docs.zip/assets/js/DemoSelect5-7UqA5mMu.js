import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSelect5-BaIVjWwA.js";export{o as default};
