import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoTable4-CIMtQ5Fd.js";export{e as default};
