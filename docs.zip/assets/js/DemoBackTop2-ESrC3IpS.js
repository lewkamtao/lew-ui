import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoBackTop2-BOUad5Wb.js";export{a as default};
