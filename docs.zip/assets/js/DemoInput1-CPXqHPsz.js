import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoInput1-BiHL4tdL.js";export{a as default};
