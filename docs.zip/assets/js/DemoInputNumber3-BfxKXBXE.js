import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoInputNumber3-DACfazpC.js";export{m as default};
