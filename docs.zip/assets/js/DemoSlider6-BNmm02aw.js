import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSlider6-CGT7_5m4.js";export{o as default};
