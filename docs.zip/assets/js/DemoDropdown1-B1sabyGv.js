import"./lew-ui-D0fj-lLn.js";import{t as r}from"./DemoDropdown1-CPTYKfXS.js";export{r as default};
