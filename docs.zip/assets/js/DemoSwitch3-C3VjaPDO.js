import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoSwitch3-BF6Gyy6J.js";export{a as default};
