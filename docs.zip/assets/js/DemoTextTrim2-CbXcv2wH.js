import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoTextTrim2-C8uzUHLQ.js";export{m as default};
