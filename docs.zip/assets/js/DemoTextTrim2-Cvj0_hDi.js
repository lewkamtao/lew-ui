import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoTextTrim2-WOFawWOD.js";export{m as default};
