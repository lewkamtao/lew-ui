import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoButton4-GtWmkrXm.js";export{a as default};
