import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoImage1-BOe4kWS4.js";export{e as default};
