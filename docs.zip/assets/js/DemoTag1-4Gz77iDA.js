import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTag1-dOCQz86A.js";export{o as default};
