import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoTooltip2-B7vj6EK2.js";export{a as default};
