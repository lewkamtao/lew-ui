import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoNotification2-CsxeUGMx.js";export{a as default};
