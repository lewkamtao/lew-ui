import"./lew-ui-D4rxVhOO.js";import{t}from"./DemoColorPicker3-Cd3IpirL.js";export{t as default};
