import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTitle3-Gri2QUUn.js";export{o as default};
