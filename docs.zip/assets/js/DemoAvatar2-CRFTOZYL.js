import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAvatar2-CpvHY8_b.js";export{o as default};
