import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea2-AqPpCUEv.js";export{e as default};
