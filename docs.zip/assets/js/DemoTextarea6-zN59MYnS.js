import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea6-CQrxyc7L.js";export{e as default};
