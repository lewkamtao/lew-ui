import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDialog3-zx3ZreE7.js";export{a as default};
