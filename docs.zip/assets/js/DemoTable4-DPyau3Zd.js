import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTable4-C0z8JhZu.js";export{e as default};
