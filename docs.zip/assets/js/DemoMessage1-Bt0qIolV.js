import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoMessage1-BNYBUp_x.js";export{a as default};
