import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoTextTrim4-Cau9TeHB.js";export{m as default};
