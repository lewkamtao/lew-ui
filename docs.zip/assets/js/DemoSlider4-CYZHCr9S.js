import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSlider4-CnvRGzSy.js";export{o as default};
