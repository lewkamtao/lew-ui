import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoInputNumber2-z_9qa-Hf.js";export{m as default};
