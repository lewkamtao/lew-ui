import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoCollapse3-Bai5kUP-.js";export{a as default};
