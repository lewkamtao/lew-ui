import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoMessage2-DXojatr5.js";export{a as default};
