import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTabs6-BP_hgjF9.js";export{o as default};
