import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoInputTag5-CiTOMlIj.js";export{o as default};
