import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoSwitch5-Gv__1wrd.js";export{a as default};
