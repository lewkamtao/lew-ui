import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSlider2-sCstiXwI.js";export{o as default};
