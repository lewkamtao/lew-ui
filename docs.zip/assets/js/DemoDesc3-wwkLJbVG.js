import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoDesc3-CLPfc-mR.js";export{o as default};
