import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea1-jnpXSH5n.js";export{e as default};
