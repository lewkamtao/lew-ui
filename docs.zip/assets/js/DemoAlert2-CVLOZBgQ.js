import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoAlert2-CScGI5qR.js";export{o as default};
