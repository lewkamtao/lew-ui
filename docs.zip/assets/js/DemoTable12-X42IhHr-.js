import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable12-BRQLxVFN.js";export{e as default};
