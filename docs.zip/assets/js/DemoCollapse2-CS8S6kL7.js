import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoCollapse2-HfUpMLoT.js";export{a as default};
