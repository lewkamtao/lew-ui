import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDialog2-DUJwTNct.js";export{a as default};
