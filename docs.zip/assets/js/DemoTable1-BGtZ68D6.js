import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoTable1-ChH73V9t.js";export{e as default};
