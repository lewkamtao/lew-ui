import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoDesc2-DzvBfvIr.js";export{o as default};
