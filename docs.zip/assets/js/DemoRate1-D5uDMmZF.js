import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoRate1-TK-jBo9x.js";export{e as default};
