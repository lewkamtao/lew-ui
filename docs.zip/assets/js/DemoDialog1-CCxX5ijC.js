import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDialog1-Bka2w8QC.js";export{a as default};
