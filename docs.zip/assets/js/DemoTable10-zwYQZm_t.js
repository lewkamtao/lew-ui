import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable10-BR04dPbW.js";export{e as default};
