import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoLoading3-C301_aJS.js";export{a as default};
