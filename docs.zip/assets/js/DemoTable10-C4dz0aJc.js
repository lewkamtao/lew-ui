import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoTable10-jJtjyyyk.js";export{e as default};
