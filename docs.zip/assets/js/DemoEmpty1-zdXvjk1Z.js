import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoEmpty1-DgkHJuNn.js";export{o as default};
