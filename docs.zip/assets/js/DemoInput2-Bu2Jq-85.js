import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoInput2-DCkGnm_j.js";export{a as default};
