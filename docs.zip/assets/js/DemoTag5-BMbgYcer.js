import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTag5-exUUrMyu.js";export{o as default};
