import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as r}from"./DemoMenuTree1-Cw6HO5XK.js";export{r as default};
