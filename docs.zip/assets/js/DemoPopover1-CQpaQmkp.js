import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoPopover1-9I-VJM-b.js";export{e as default};
