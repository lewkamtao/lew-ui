import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoInputNumber3-pq5JuNGu.js";export{m as default};
