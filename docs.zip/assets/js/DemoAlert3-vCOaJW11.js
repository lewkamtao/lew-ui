import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAlert3-CXMeIHTZ.js";export{o as default};
