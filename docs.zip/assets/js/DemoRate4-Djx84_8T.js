import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoRate4-kQNkHGLU.js";export{e as default};
