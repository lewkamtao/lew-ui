import"./lew-ui-D0fj-lLn.js";import"./vendor-DI90tgK9.js";import{t as e}from"./DemoBadge2-BGxRgBuu.js";export{e as default};
