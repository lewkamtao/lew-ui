import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoPopover1-mIVZntV3.js";export{e as default};
