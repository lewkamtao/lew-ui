import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoForm5-BA8uRlC3.js";export{m as default};
