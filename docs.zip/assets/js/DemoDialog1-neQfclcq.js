import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoDialog1-DaWLspgm.js";export{a as default};
