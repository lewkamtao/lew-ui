import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag7-DnMJ4vsS.js";export{o as default};
