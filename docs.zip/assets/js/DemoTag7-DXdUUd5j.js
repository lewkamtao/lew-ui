import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTag7-DtBZ7CpF.js";export{o as default};
