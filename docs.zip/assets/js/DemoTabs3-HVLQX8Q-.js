import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTabs3-DDSHDX2v.js";export{o as default};
