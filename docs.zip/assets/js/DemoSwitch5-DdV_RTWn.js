import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoSwitch5-BI0vAFLO.js";export{a as default};
