import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoInputTag4-CRw3X_NH.js";export{o as default};
