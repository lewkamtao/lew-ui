import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSlider2-C8EnaMyK.js";export{o as default};
