import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoSwitch3-CsPHrONi.js";export{a as default};
