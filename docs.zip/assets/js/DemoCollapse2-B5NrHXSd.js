import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoCollapse2-D7CRYDxH.js";export{a as default};
