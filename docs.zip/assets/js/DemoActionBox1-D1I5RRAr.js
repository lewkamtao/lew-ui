import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoActionBox1-CYT43lip.js";export{a as default};
