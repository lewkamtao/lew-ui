import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoSwitch1-Bv1bibIC.js";export{a as default};
