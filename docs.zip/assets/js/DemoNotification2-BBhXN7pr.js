import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoNotification2-x60TsfxG.js";export{a as default};
