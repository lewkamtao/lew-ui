import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoPagination1-BJcPHYFQ.js";export{o as default};
