import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoMessage1-CkDYUOs6.js";export{a as default};
