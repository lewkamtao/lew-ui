import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable2-CLCVBNv8.js";export{e as default};
