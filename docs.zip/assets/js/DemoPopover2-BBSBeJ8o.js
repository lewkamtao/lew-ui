import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoPopover2-BsdI-EGM.js";export{e as default};
