import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea3-CeMZW2CT.js";export{e as default};
