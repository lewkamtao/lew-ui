import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoEmpty1-BWZZK7hN.js";export{o as default};
