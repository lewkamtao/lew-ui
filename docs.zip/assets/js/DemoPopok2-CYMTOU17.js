import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoPopok2-BBm4c9-o.js";export{a as default};
