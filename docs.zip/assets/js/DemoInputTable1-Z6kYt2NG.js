import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoInputTable1-DjLOoHOT.js";export{e as default};
