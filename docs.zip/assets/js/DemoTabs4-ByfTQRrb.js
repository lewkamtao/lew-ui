import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTabs4-DYWz8Lrv.js";export{o as default};
