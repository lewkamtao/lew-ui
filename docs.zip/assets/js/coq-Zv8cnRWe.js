import{mi as o}from"./vendor-DI90tgK9.js";export{o as default};
