import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable4-Dn8QEjpz.js";export{e as default};
