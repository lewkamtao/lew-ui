import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoRate4-RsW6RcLx.js";export{e as default};
