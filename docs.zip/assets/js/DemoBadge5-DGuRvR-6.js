import"./lew-ui-BmI9Z0Xx.js";import"./vendor-B1EjpHgE.js";import{t as e}from"./DemoBadge5-DQx-UOQ5.js";export{e as default};
