import"./lew-ui-BmI9Z0Xx.js";import{t}from"./DemoColorPicker2-DVPcW2lv.js";export{t as default};
