import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoPopover5-CdVhPpgZ.js";export{e as default};
