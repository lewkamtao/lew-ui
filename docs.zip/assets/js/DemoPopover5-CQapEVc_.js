import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoPopover5-DMlzfly_.js";export{e as default};
