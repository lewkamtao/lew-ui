import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoNotification3-DSatPuFE.js";export{a as default};
