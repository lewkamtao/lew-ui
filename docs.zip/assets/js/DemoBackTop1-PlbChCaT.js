import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoBackTop1-ZF1BA6co.js";export{a as default};
