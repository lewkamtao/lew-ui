import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoInputTag2-B9c79mEa.js";export{o as default};
