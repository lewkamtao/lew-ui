import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoModal1-C8HctHJP.js";export{a as default};
