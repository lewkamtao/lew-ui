import{r as p}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as o,Ci as s,Li as c,fn as i,i as l,mi as m,mn as d,pi as r,pn as u,r as f,ui as _}from"./lew-ui-D0fj-lLn.js";import{fa as v}from"./vendor-DI90tgK9.js";import{t as w}from"./LewComponentInfo-DEhjborz.js";import{n as k,t as x}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as C}from"./DemoColorPicker1-BZE8TvZE.js";import{t as P}from"./DemoColorPicker2-BougCgHH.js";import{t as D}from"./DemoColorPicker3-Du9y0nna.js";import{t as y}from"./DemoColorPicker4-BIbBrqab.js";import{t as g}from"./DemoColorPicker5-DsyHz_oD.js";var h={title:"Emits",columnsKey:"emits",orderNum:99,data:f(d)},E={title:"Model",columnsKey:"model",orderNum:1,data:l(i)},F={title:"Props",columnsKey:"props",orderNum:3,data:l(u)},t=p({emits:()=>h,model:()=>E,props:()=>F},1),L=`<script lang="ts" setup>
const color = ref('')
<\/script>

<template>
  <div style="width: 300px">
    <lew-color-picker v-model="color" />
  </div>
</template>
`,N=`<script lang="ts" setup>
const color = ref('#409EFF')
<\/script>

<template>
  <lew-flex direction="y" x="start" style="width: 300px">
    <lew-color-picker v-model="color" size="small" />
    <lew-color-picker v-model="color" size="medium" />
    <lew-color-picker v-model="color" size="large" />
  </lew-flex>
</template>
`,$=`<script lang="ts" setup>
const color = ref('#409EFF')
<\/script>

<template>
  <lew-flex direction="y" x="start" style="width: 300px">
    <lew-color-picker v-model="color" width="150px" />
    <lew-color-picker v-model="color" width="200px" />
    <lew-color-picker v-model="color" width="300px" />
  </lew-flex>
</template>
`,B=`<script lang="ts" setup>
const color = ref('#409EFF')
<\/script>

<template>
  <div style="width: 300px">
    <lew-color-picker v-model="color" disabled />
  </div>
</template>
`,b=`<script lang="ts" setup>
const color = ref('#409EFF')
<\/script>

<template>
  <div style="width: 300px">
    <lew-color-picker v-model="color" readonly />
  </div>
</template>
`;const z=[C,P,D,y,g],K=[L,N,$,B,b];var G={class:"demo-wrapper"},M=m({__name:"DemoCollapse",setup(j){const a=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),n=c(Object.keys(t).map(e=>t[e]));return(e,A)=>(s(),_("div",G,[r(w),r(k,{"demo-group":o(z),"code-group":o(K),"component-name":o(a),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),r(x,{options:o(n)},null,8,["options"])]))}}),R=M,W=R;export{W as default};
