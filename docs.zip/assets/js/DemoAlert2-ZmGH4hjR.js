import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAlert2-uheYrZU4.js";export{o as default};
