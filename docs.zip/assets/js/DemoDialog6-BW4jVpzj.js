import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as m}from"./DemoDialog6-CnK1ToPU.js";export{m as default};
