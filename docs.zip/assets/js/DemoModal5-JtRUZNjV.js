import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoModal5-Dy8QZ_nn.js";export{a as default};
