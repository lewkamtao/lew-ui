import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAvatar1-C1X0nlI4.js";export{o as default};
