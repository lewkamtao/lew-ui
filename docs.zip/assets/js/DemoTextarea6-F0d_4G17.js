import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea6-5ln4GAW2.js";export{e as default};
