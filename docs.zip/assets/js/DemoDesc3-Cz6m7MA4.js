import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoDesc3-J5I2VDLa.js";export{o as default};
