import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoContextMenu2-B-YFDnIM.js";export{o as default};
