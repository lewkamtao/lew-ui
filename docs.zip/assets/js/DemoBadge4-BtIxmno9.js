import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoBadge4-Cuiv-kkJ.js";export{e as default};
