import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoImage2-BxovYzs0.js";export{e as default};
