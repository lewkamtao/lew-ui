import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoRate2-C5ozjgrf.js";export{e as default};
