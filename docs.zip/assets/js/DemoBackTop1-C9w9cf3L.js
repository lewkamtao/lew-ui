import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoBackTop1-DsffTKaX.js";export{a as default};
