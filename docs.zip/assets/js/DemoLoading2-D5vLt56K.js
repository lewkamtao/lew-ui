import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoLoading2-sraNjwhw.js";export{a as default};
