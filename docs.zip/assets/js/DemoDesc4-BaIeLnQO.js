import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoDesc4-Cm5cDMug.js";export{o as default};
