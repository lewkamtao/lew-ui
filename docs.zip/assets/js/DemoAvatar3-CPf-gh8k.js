import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoAvatar3-DwxDNZ-H.js";export{o as default};
