import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoMark1-BNMF1XJp.js";export{o as default};
