import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect7-VBMAFcsJ.js";export{o as default};
