import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoPopok5-DmWxQjGQ.js";export{a as default};
