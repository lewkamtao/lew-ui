import"./lew-ui-D0fj-lLn.js";import"./vendor-DI90tgK9.js";import{t as e}from"./DemoTable3-BkL9Ax_k.js";export{e as default};
