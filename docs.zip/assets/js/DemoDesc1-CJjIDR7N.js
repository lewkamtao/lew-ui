import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoDesc1-DJymkXbq.js";export{o as default};
