import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoEmpty1-DG1RUlGi.js";export{o as default};
