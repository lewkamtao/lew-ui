import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTextarea7-DSSfByAv.js";export{e as default};
