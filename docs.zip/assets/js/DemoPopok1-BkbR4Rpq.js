import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoPopok1-Cf3KYQRG.js";export{a as default};
