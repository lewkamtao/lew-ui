import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoDialog5-J62UuyZi.js";export{a as default};
