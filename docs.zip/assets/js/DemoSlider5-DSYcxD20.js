import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSlider5-Cy7Zs-4_.js";export{o as default};
