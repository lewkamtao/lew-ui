import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect12-KyFBcvvf.js";export{o as default};
