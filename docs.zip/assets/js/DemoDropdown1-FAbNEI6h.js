import"./lew-ui-CDhnpYIO.js";import{t as r}from"./DemoDropdown1-DYcJPYQC.js";export{r as default};
