import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoBreadcrumb3-DR-BcI6N.js";export{a as default};
