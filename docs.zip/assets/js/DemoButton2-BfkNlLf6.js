import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoButton2-J0QlYtpZ.js";export{a as default};
