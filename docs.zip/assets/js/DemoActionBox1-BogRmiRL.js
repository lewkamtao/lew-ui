import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoActionBox1-CPKfp8oj.js";export{a as default};
