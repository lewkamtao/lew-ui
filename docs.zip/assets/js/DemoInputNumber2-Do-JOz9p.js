import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoInputNumber2-C08li1u9.js";export{m as default};
