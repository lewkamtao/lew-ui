import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTable12-CvVBkbs8.js";export{e as default};
