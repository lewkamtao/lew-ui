import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTag7-ZtjC4-LF.js";export{o as default};
