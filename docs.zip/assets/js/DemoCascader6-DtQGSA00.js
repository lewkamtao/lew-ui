import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoCascader6-WLrxXY-K.js";export{e as default};
