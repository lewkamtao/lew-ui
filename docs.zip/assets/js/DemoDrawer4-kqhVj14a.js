import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDrawer4-CnlSVT12.js";export{a as default};
