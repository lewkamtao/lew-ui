import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoCollapse2-DFE3LfeS.js";export{a as default};
