import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable8-DmogEpys.js";export{e as default};
