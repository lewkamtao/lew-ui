import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoBreadcrumb1-Cf7Rh8xU.js";export{a as default};
