import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoSlider4-DVxyKjUz.js";export{o as default};
