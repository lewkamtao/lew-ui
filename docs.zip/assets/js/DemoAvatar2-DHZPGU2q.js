import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAvatar2-C86JqM0N.js";export{o as default};
