import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoTextTrim4-DLGZ9-rH.js";export{m as default};
