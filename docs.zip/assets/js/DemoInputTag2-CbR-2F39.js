import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoInputTag2-D1bYuG82.js";export{o as default};
