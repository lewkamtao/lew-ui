import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoNotification2-o5yIkTbh.js";export{a as default};
