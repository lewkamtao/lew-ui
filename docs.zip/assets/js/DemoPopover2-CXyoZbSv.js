import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoPopover2-B5h_-yo6.js";export{e as default};
