import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoCheckbox3-Otra32Ec.js";export{e as default};
