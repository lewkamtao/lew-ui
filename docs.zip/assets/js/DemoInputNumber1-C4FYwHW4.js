import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoInputNumber1-D6Digrqo.js";export{m as default};
