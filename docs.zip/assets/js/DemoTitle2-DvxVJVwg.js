import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTitle2-BYWPpSLK.js";export{o as default};
