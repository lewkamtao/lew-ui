import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDrawer2-DM8HoTXH.js";export{a as default};
