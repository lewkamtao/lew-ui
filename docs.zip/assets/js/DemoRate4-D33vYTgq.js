import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoRate4-CnpYRWr0.js";export{e as default};
