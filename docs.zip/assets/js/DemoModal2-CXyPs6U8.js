import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoModal2-Dgxb4wFQ.js";export{a as default};
