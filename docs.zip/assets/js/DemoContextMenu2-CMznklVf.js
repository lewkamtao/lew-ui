import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoContextMenu2-lJ6fI2Ux.js";export{o as default};
