import"./lew-ui-D0fj-lLn.js";import{t as m}from"./DemoInputNumber2-DCQihriV.js";export{m as default};
