import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoContextMenu3-DIs05DP7.js";export{o as default};
