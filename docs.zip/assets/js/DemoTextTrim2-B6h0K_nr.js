import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoTextTrim2-CaQ-oqOM.js";export{m as default};
