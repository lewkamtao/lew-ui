import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea2-CppD0Ebs.js";export{e as default};
