import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTabs5-CsHQhqup.js";export{o as default};
