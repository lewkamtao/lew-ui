import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput10-C5aqETqG.js";export{a as default};
