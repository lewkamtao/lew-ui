import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag2-CJVQMe4S.js";export{o as default};
