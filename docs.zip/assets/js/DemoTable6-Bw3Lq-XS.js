import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTable6-D3_9uRZX.js";export{e as default};
