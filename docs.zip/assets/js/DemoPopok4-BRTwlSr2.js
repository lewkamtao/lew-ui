import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoPopok4-OKf08G2Q.js";export{a as default};
