import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoLoading1-m6mzVN32.js";export{a as default};
