import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTag5-CQ7RtVnU.js";export{o as default};
