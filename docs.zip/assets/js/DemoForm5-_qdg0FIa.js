import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoForm5-D0qvLwxM.js";export{m as default};
