import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoBreadcrumb1-H77C4CLI.js";export{a as default};
