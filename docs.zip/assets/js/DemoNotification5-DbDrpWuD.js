import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoNotification5-BTq05Db5.js";export{a as default};
