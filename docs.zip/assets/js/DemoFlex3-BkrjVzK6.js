import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoFlex3-COh9zWTd.js";export{o as default};
