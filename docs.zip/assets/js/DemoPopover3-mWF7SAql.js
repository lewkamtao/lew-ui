import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoPopover3-BS-9p7FY.js";export{e as default};
