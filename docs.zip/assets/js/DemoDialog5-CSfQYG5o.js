import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoDialog5-B8vC3DX9.js";export{a as default};
