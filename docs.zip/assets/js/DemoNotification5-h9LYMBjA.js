import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoNotification5-BS3sAN6g.js";export{a as default};
