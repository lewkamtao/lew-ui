import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as n,Ci as c,Jr as d,Li as m,er as p,i as o,mi as u,nr as f,pi as t,qr as g,r as i,rr as y,tr as v,ui as h}from"./lew-ui-D0fj-lLn.js";import{fa as w}from"./vendor-DI90tgK9.js";import{t as b}from"./LewComponentInfo-DEhjborz.js";import{n as A,t as k}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as _}from"./DemoCollapse1-DMPMk9it.js";import{t as I}from"./DemoCollapse2-HfUpMLoT.js";import{t as P}from"./DemoCollapse3-1IRASDdO.js";var z={title:"Emits(CollapseItem)",columnsKey:"emits",orderNum:11,data:i(d)},M={title:"Model(CollapseItem)",columnsKey:"model",orderNum:2,data:o(p)},S={title:"Props(CollapseItem)",columnsKey:"props",orderNum:4,data:o(f)},C={title:"Emits",columnsKey:"emits",orderNum:99,data:i(g)},W={title:"Model",columnsKey:"model",orderNum:1,data:o(v)},T={title:"Props",columnsKey:"props",orderNum:3,data:o(y)},a=r({collapseItemEmits:()=>z,collapseItemModel:()=>M,collapseItemProps:()=>S,emits:()=>C,model:()=>W,props:()=>T},1),B=`<script lang="ts" setup>
const value = ref(['1'])
const companies = [
  {
    id: '1',
    name: 'Apple',
    description:
      'Apple Inc. is an American multinational technology company that designs, manufactures, and markets consumer electronics, computer software, and online services. Founded by Steve Jobs, Steve Wozniak, and Ronald Wayne in 1976, Apple is known for its innovative products such as the iPhone, iPad, Mac computers, and Apple Watch.',
  },
  {
    id: '2',
    name: 'Google',
    description:
      'Google is a technology company that specializes in Internet-related services and products. Founded in 1998 by Larry Page and Sergey Brin while they were Ph.D. students at Stanford University, Google is now one of the most valuable companies in the world, known for its search engine, online advertising, and cloud computing services.',
  },
  {
    id: '3',
    name: 'Microsoft',
    description:
      'Microsoft Corporation is an American technology company that develops, manufactures, licenses, supports, and sells computer software, consumer electronics, and personal computers. Founded by Bill Gates and Paul Allen in 1975, Microsoft is best known for its Windows operating system and Office productivity suite.',
  },
  {
    id: '4',
    name: 'Tencent',
    description:
      'Tencent Holdings Limited is a Chinese multinational conglomerate holding company founded in 1998. Tencent is one of the largest technology companies in the world, offering a wide range of internet services and products, including social media, entertainment, and online payment systems.',
  },
  {
    id: '5',
    name: 'Amazon',
    description:
      'Amazon.com, Inc. is an American multinational technology company founded by Jeff Bezos in 1994. Amazon is the world\\'s largest online retailer and cloud computing company, known for its e-commerce platform, Amazon Prime subscription service, and Amazon Web Services (AWS) cloud computing platform.',
  },
  {
    id: '6',
    name: 'Tesla',
    description:
      'Tesla, Inc. is an American electric vehicle and clean energy company founded by Elon Musk, Martin Eberhard, Marc Tarpenning, JB Straubel, and Ian Wright in 2003. Tesla is known for its electric vehicles, energy storage solutions, and solar products, aiming to accelerate the world\\'s transition to sustainable energy.',
  },
]

const companies1 = [
  {
    id: '1123',
    name: 'iPhone',
    description:
      'Apple Inc. is an American multinational technology company that designs, manufactures, and markets consumer electronics, computer software, and online services. Founded by Steve Jobs, Steve Wozniak, and Ronald Wayne in 1976, Apple is known for its innovative products such as the iPhone, iPad, Mac computers, and Apple Watch.',
  },
  {
    id: '2123a',
    name: 'iPad',
    description:
      'Google is a technology company that specializes in Internet-related services and products. Founded in 1998 by Larry Page and Sergey Brin while they were Ph.D. students at Stanford University, Google is now one of the most valuable companies in the world, known for its search engine, online advertising, and cloud computing services.',
  },
]
<\/script>

<template>
  <lew-collapse v-model="value" width="400px">
    <lew-collapse-item
      v-for="item in companies"
      :key="item.id"
      :title="item.name"
      :collapse-key="item.id"
    >
      <template v-if="item.name === 'Apple'">
        <lew-collapse v-model="value" width="100%" style="padding-left: 20px">
          <lew-collapse-item
            v-for="subItem in companies1"
            :key="subItem.id"
            :title="subItem.name"
            :collapse-key="subItem.id"
          >
            <div>
              {{ subItem.description }}
            </div>
          </lew-collapse-item>
        </lew-collapse>
      </template>
      <template v-else>
        <div>
          {{ item.description }}
        </div>
      </template>
    </lew-collapse-item>
  </lew-collapse>
</template>
`,G=`<script lang="ts" setup>
import { ChevronLeft } from 'lucide-vue-next'

const value = ref<string[]>(['1'])
const companies = [
  {
    id: '1',
    name: 'Apple',
    description:
      'Apple Inc. is an American multinational technology company that designs, manufactures, and markets consumer electronics, computer software, and online services. Founded by Steve Jobs, Steve Wozniak, and Ronald Wayne in 1976, Apple is known for its innovative products such as the iPhone, iPad, Mac computers, and Apple Watch.',
  },
  {
    id: '2',
    name: 'Google',
    description:
      'Google is a technology company that specializes in Internet-related services and products. Founded in 1998 by Larry Page and Sergey Brin while they were Ph.D. students at Stanford University, Google is now one of the most valuable companies in the world, known for its search engine, online advertising, and cloud computing services.',
  },
  {
    id: '3',
    name: 'Microsoft',
    description:
      'Microsoft Corporation is an American technology company that develops, manufactures, licenses, supports, and sells computer software, consumer electronics, and personal computers. Founded by Bill Gates and Paul Allen in 1975, Microsoft is best known for its Windows operating system and Office productivity suite.',
  },
  {
    id: '4',
    name: 'Tencent',
    description:
      'Tencent Holdings Limited is a Chinese multinational conglomerate holding company founded in 1998. Tencent is one of the largest technology companies in the world, offering a wide range of internet services and products, including social media, entertainment, and online payment systems.',
  },
  {
    id: '5',
    name: 'Amazon',
    description:
      'Amazon.com, Inc. is an American multinational technology company founded by Jeff Bezos in 1994. Amazon is the world\\'s largest online retailer and cloud computing company, known for its e-commerce platform, Amazon Prime subscription service, and Amazon Web Services (AWS) cloud computing platform.',
  },
  {
    id: '6',
    name: 'Tesla',
    description:
      'Tesla, Inc. is an American electric vehicle and clean energy company founded by Elon Musk, Martin Eberhard, Marc Tarpenning, JB Straubel, and Ian Wright in 2003. Tesla is known for its electric vehicles, energy storage solutions, and solar products, aiming to accelerate the world\\'s transition to sustainable energy.',
  },
]
<\/script>

<template>
  <lew-collapse v-model="value" width="400">
    <lew-collapse-item
      v-for="item in companies"
      :key="item.id"
      :title="item.name"
      :collapse-key="item.id"
    >
      <template #title>
        <lew-flex
          x="start"
          :class="{ active: value.includes(item.id) }"
          mode="between"
        >
          <div class="title">
            {{ item.name }}
            <lew-tag v-if="item.id === '1'" color="red" size="small" round>
              HOT
            </lew-tag>
          </div>
          <ChevronLeft class="icon" :size="16" />
        </lew-flex>
      </template>
      <div>
        {{ item.description }}
      </div>
    </lew-collapse-item>
  </lew-collapse>
</template>

<style scoped lang="scss">
.icon {
  transition: all 0.3s;
}
.active {
  .icon {
    transform: rotate(-90deg);
  }
}
</style>
`,L=`<script lang="ts" setup>
const value = ref('')
const companies = [
  {
    id: '1',
    name: 'Apple',
    description:
      'Apple Inc. is an American multinational technology company that designs, manufactures, and markets consumer electronics, computer software, and online services. Founded by Steve Jobs, Steve Wozniak, and Ronald Wayne in 1976, Apple is known for its innovative products such as the iPhone, iPad, Mac computers, and Apple Watch.',
  },
  {
    id: '2',
    name: 'Google',
    description:
      'Google is a technology company that specializes in Internet-related services and products. Founded in 1998 by Larry Page and Sergey Brin while they were Ph.D. students at Stanford University, Google is now one of the most valuable companies in the world, known for its search engine, online advertising, and cloud computing services.',
  },
  {
    id: '3',
    name: 'Microsoft',
    description:
      'Microsoft Corporation is an American technology company that develops, manufactures, licenses, supports, and sells computer software, consumer electronics, and personal computers. Founded by Bill Gates and Paul Allen in 1975, Microsoft is best known for its Windows operating system and Office productivity suite.',
  },
  {
    id: '4',
    name: 'Tencent',
    description:
      'Tencent Holdings Limited is a Chinese multinational conglomerate holding company founded in 1998. Tencent is one of the largest technology companies in the world, offering a wide range of internet services and products, including social media, entertainment, and online payment systems.',
  },
  {
    id: '5',
    name: 'Amazon',
    description:
      'Amazon.com, Inc. is an American multinational technology company founded by Jeff Bezos in 1994. Amazon is the world\\'s largest online retailer and cloud computing company, known for its e-commerce platform, Amazon Prime subscription service, and Amazon Web Services (AWS) cloud computing platform.',
  },
  {
    id: '6',
    name: 'Tesla',
    description:
      'Tesla, Inc. is an American electric vehicle and clean energy company founded by Elon Musk, Martin Eberhard, Marc Tarpenning, JB Straubel, and Ian Wright in 2003. Tesla is known for its electric vehicles, energy storage solutions, and solar products, aiming to accelerate the world\\'s transition to sustainable energy.',
  },
]
<\/script>

<template>
  <lew-collapse v-model="value" width="400">
    <lew-collapse-item
      v-for="item in companies"
      :key="item.id"
      padding="10px"
      radius="5px"
      :title="item.name"
      :collapse-key="item.id"
    >
      <div>
        {{ item.description }}
      </div>
    </lew-collapse-item>
  </lew-collapse>
</template>
`;const D=[_,I,P],x=[B,G,L];var E={class:"demo-wrapper"},F=u({__name:"DemoCollapse",setup(N){const s=w().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),l=m(Object.keys(a).map(e=>a[e]));return(e,K)=>(c(),h("div",E,[t(b),t(A,{"demo-group":n(D),"code-group":n(x),"component-name":n(s),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(k,{options:n(l)},null,8,["options"])]))}}),J=F,Q=J;export{Q as default};
