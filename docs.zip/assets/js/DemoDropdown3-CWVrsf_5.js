import"./lew-ui-D0fj-lLn.js";import{t as r}from"./DemoDropdown3-CDEKIzB4.js";export{r as default};
