import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoDesc4-C_LlZCQu.js";export{o as default};
