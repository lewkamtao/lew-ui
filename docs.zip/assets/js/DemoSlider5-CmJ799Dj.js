import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSlider5-ChoYMIYp.js";export{o as default};
