import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoDesc1-DNszWpdA.js";export{o as default};
