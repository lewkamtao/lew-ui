import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoMessage2-DYQvuIXm.js";export{a as default};
