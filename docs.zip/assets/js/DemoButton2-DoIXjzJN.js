import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoButton2-CxlGfPyi.js";export{a as default};
