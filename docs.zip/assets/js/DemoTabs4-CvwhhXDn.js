import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTabs4-C7FIX7Vp.js";export{o as default};
