import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTabs4-YsLH4UFL.js";export{o as default};
