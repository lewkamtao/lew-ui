import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoBreadcrumb2-Bi_r0_71.js";export{a as default};
