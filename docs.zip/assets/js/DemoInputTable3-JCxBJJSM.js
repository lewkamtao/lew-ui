import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoInputTable3-DDC_mwyi.js";export{e as default};
