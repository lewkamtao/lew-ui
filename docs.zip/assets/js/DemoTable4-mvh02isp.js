import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTable4-iwLzuI2E.js";export{e as default};
