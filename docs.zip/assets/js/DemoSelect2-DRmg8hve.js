import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect2-CK0XLoPR.js";export{o as default};
