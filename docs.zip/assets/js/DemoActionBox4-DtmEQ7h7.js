import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as r}from"./DemoActionBox4-DbnYCawn.js";export{r as default};
