import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoCheckbox1-CVuY25o3.js";export{e as default};
