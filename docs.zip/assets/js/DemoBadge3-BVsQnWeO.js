import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoBadge3-BlW_MmXU.js";export{e as default};
