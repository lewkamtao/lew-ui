import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoContextMenu2-CIeF3bKy.js";export{o as default};
