import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoRate3-aezlutfp.js";export{e as default};
