import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoAvatar4-CCXXMBRE.js";export{o as default};
