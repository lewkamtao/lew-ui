import{ni as t}from"./vendor-DI90tgK9.js";export{t as default};
