import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoContextMenu2-YN_h6ZXM.js";export{o as default};
