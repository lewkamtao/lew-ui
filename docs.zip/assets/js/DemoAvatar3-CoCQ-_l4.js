import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoAvatar3-UZ1u-hw4.js";export{o as default};
