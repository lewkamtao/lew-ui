import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag6-Ca6LQxER.js";export{o as default};
