import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput5-d6YJ62Jx.js";export{a as default};
