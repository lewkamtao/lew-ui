import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoCascader2-BeDODk_V.js";export{e as default};
