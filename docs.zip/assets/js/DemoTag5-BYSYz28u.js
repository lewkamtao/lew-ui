import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoTag5-drjATVzr.js";export{o as default};
