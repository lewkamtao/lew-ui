import"./lew-ui-D0fj-lLn.js";import{t}from"./DemoColorPicker1-BZE8TvZE.js";export{t as default};
