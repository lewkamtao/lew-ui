import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoTextarea6-D5Eevyem.js";export{e as default};
