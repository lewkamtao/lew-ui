import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoCheckbox3-BuG91c-m.js";export{e as default};
