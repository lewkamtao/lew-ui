import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag4-D-VbB_yZ.js";export{o as default};
