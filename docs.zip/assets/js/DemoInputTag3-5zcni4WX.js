import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag3-MEoDNrTg.js";export{o as default};
