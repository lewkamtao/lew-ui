import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoCollapse3-CCqmyzSe.js";export{a as default};
