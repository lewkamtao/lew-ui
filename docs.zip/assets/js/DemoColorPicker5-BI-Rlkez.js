import"./lew-ui-D4rxVhOO.js";import{t}from"./DemoColorPicker5-QDCss65S.js";export{t as default};
