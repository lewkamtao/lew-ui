import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoInputTable2-CTiZgY7H.js";export{e as default};
