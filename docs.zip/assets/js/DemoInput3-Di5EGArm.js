import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoInput3-C0BcdWgC.js";export{a as default};
