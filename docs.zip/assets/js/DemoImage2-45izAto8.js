import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoImage2-C5hj9Ov2.js";export{e as default};
