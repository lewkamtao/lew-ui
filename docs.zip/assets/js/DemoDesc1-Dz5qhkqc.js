import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoDesc1-CrYqH2ap.js";export{o as default};
