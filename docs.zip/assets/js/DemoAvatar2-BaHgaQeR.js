import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoAvatar2-D6m_eCwG.js";export{o as default};
