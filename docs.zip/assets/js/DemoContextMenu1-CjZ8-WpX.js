import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as m}from"./DemoContextMenu1-Cm4veq6K.js";export{m as default};
