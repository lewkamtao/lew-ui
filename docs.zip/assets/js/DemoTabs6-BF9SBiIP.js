import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTabs6-Drv5pB39.js";export{o as default};
