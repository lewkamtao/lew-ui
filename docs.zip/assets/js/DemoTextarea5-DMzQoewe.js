import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoTextarea5-D_WIleBk.js";export{e as default};
