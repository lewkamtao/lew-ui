import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoLoading3-JBsXBfTL.js";export{a as default};
