import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoDialog4-CqA6abTh.js";export{a as default};
