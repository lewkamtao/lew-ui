import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect13-3J2egGct.js";export{o as default};
