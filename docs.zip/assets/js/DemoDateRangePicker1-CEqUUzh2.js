import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoDateRangePicker1-2lGmFRoH.js";export{a as default};
