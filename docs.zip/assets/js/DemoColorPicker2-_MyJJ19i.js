import"./lew-ui-Bz7GIUSM.js";import{t}from"./DemoColorPicker2-DpI1oidw.js";export{t as default};
