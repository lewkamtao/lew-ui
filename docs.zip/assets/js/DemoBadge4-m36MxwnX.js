import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoBadge4-C6vC4QVa.js";export{e as default};
