import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoCheckbox5-Ck1VmnbN.js";export{e as default};
