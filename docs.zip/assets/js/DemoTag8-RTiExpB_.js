import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTag8-lDx0oG6b.js";export{o as default};
