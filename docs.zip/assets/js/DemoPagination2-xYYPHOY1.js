import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoPagination2-BE6Xyudz.js";export{o as default};
