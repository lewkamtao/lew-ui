import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoInput2-Dq6Tc1Nr.js";export{a as default};
