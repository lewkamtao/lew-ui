import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoPagination3-DFYCqOgv.js";export{o as default};
