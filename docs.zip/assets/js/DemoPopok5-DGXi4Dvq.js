import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoPopok5-CodSRAUD.js";export{a as default};
