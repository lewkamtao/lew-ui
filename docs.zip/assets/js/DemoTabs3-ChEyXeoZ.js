import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoTabs3-BtoQr19X.js";export{o as default};
