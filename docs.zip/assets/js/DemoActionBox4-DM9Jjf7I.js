import"./lew-ui-D0fj-lLn.js";import"./vendor-DI90tgK9.js";import{t as r}from"./DemoActionBox4-BadYv_Hm.js";export{r as default};
