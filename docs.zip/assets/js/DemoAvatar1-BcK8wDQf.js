import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoAvatar1-0t2J1cm8.js";export{o as default};
