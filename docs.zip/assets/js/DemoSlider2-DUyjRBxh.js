import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSlider2-BL-1hf03.js";export{o as default};
