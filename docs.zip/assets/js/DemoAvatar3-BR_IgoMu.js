import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAvatar3-BK4DH5rC.js";export{o as default};
