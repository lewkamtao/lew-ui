import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable12-CqzQNj4c.js";export{e as default};
