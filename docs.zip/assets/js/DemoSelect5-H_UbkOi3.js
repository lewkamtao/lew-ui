import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect5-ld45NqyJ.js";export{o as default};
