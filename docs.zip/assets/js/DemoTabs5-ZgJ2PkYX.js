import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTabs5-AKM7iAxB.js";export{o as default};
