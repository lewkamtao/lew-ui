import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect11-Dt_1wzfD.js";export{o as default};
