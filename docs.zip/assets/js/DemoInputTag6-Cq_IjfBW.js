import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag6-LU3UPSbX.js";export{o as default};
