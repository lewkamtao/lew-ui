import"./lew-ui-D4rxVhOO.js";import"./vendor-DE_9brhS.js";import{t as e}from"./DemoBadge5-Dda90WAt.js";export{e as default};
