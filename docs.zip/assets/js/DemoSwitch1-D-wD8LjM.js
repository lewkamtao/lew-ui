import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoSwitch1-j3nh_B7i.js";export{a as default};
