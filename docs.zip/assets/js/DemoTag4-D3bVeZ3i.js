import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoTag4-CX4rd7rl.js";export{o as default};
