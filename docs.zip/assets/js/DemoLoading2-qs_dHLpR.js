import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoLoading2-BRvfzBLu.js";export{a as default};
