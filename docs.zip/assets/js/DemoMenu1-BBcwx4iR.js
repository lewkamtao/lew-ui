import"./lew-ui-Bz7GIUSM.js";import"./vendor-Lw2Mkmbe.js";import{t as m}from"./DemoMenu1-C4Oqo1SZ.js";export{m as default};
