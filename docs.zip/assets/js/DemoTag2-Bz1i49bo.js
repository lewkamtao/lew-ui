import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoTag2-DXK31Cjr.js";export{o as default};
