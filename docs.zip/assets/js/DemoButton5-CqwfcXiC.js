import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoButton5-CMLHZ5wY.js";export{a as default};
