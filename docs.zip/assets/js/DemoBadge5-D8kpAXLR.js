import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as e}from"./DemoBadge5-20eRr3uC.js";export{e as default};
