import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as n,Ci as l,G as c,Li as m,W as u,i,mi as p,pi as a,r as d,ui as b}from"./lew-ui-D0fj-lLn.js";import{fa as v}from"./vendor-DI90tgK9.js";import{t as f}from"./LewComponentInfo-DEhjborz.js";import{n as _,t as h}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as g}from"./DemoBreadcrumb1-Cf7Rh8xU.js";import{t as B}from"./DemoBreadcrumb2-wUgLu1VI.js";import{t as k}from"./DemoBreadcrumb3-CR72gez1.js";var C={title:"Emits",columnsKey:"emits",orderNum:99,data:d(c)},D={title:"Props",columnsKey:"props",orderNum:1,data:i(u)},r=s({emits:()=>C,props:()=>D},1),w=`<script lang="ts" setup>
// Define breadcrumb navigation options
const options = ref([
  {
    label: 'Product Mgmt',
    value: '/products',
  },
  {
    label: 'Electronics',
    value: '/products/electronics',
  },
  {
    label: 'Phones',
    value: '/products/electronics/phones',
  },
  {
    label: 'iPhone 13',
    value: '',
    active: true,
  },
])

// Simulate breadcrumb click event
function handleBreadcrumbClick(item: any) {
  LewMessage.success(\`Clicked breadcrumb item: \${item.label}\`)
}
<\/script>

<template>
  <div class="product-detail-page">
    <lew-breadcrumb :options="options" @change="handleBreadcrumbClick" />
  </div>
</template>
`,L=`<script lang="ts" setup>
const options = ref([
  {
    label: 'User Management',
    value: '/users',
  },
  {
    label: 'User List',
    value: '/users/list',
  },
  {
    label: 'User Details',
    value: '/users/details',
    active: true,
  },
  {
    label: 'Edit User',
    value: '/users/edit',
  },
])
// Simulate breadcrumb click event
function handleBreadcrumbClick(item: any) {
  LewMessage.success(\`Clicked breadcrumb item: \${item.label}\`)
}
<\/script>

<template>
  <lew-breadcrumb :options="options" @change="handleBreadcrumbClick" />
</template>
`,P=`<script lang="ts" setup>
const options = ref([
  {
    label: 'Home',
    value: '/',
  },
  {
    label: 'Electronics',
    value: '/electronics',
  },
  {
    label: 'Phones',
    value: '/electronics/phones',
  },
  {
    label: 'Smartphones',
    value: '/electronics/phones/smartphones',
  },
  {
    label: 'iPhone 13 Pro',
    value: '/electronics/phones/smartphones/iphone-13-pro',
    active: true,
  },
])
// Simulate breadcrumb click event
function handleBreadcrumbClick(item: any) {
  LewMessage.success(\`Clicked breadcrumb item: \${item.label}\`)
}
<\/script>

<template>
  <lew-breadcrumb
    :options="options"
    separator="shoulder"
    @change="handleBreadcrumbClick"
  />
</template>
`;const y=[g,B,k],E=[w,L,P];var x={class:"demo-wrapper"},$=p({__name:"DemoBreadcrumb",setup(N){const t=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),o=m(Object.keys(r).map(e=>r[e]));return(e,S)=>(l(),b("div",x,[a(f),a(_,{"demo-group":n(y),"code-group":n(E),"component-name":n(t),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),a(h,{options:n(o)},null,8,["options"])]))}}),M=$,T=M;export{T as default};
