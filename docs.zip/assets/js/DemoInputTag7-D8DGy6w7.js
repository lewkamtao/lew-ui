import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag7-BFFAZZJH.js";export{o as default};
