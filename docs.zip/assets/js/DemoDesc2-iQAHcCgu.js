import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoDesc2-BTsAzWNQ.js";export{o as default};
