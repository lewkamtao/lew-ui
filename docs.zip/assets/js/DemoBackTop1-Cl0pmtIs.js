import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoBackTop1-Pucn_ZoV.js";export{a as default};
