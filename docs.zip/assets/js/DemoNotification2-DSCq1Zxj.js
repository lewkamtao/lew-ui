import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoNotification2-31dJyM5C.js";export{a as default};
