import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoSlider3-DjGOXABU.js";export{o as default};
