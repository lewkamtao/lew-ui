import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag3-fhUp9IKR.js";export{o as default};
