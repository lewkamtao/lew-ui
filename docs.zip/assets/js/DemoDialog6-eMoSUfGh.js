import"./lew-ui-CDhnpYIO.js";import"./vendor-V4DJB7Z0.js";import{t as m}from"./DemoDialog6-Beb_RE3S.js";export{m as default};
