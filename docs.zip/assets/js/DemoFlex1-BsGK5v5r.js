import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoFlex1-CEESLi4-.js";export{o as default};
