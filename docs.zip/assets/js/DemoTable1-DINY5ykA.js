import"./lew-ui-D4rxVhOO.js";import{t as e}from"./DemoTable1-DrA7le86.js";export{e as default};
