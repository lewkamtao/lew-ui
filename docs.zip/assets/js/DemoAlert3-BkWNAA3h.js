import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoAlert3-BzTSKvi-.js";export{o as default};
