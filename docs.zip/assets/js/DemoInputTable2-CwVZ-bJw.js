import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoInputTable2-CViKWlyL.js";export{e as default};
