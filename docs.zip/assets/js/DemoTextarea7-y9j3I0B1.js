import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTextarea7-ceh2iVMe.js";export{e as default};
