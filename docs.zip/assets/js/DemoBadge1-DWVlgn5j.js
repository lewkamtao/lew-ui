import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoBadge1-C-HNzxvB.js";export{e as default};
