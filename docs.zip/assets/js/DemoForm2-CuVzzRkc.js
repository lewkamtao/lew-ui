import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoForm2-BLL2D50O.js";export{m as default};
