import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoButton5-Cxr9gFyO.js";export{a as default};
