import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoImage2-CMK-4NFf.js";export{e as default};
