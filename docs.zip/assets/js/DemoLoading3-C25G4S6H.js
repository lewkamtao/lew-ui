import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoLoading3-Cjv9PlXp.js";export{a as default};
