import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoInputTag1-CKyYy6iy.js";export{o as default};
