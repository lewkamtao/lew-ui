import"./lew-ui-BmI9Z0Xx.js";import{t}from"./DemoColorPicker4-BXqEpeQX.js";export{t as default};
