import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoCheckbox7-BSdcp-C-.js";export{e as default};
