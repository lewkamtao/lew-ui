import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoPagination3-wgcgoX5h.js";export{o as default};
