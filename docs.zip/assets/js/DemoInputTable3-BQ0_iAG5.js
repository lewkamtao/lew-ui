import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoInputTable3-DBJg883P.js";export{e as default};
