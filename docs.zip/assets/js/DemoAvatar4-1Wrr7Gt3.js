import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoAvatar4-gm5c13p1.js";export{o as default};
