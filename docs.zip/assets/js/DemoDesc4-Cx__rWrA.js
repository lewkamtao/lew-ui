import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoDesc4-DcxOb3OJ.js";export{o as default};
