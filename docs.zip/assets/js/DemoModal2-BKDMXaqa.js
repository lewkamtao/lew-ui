import"./lew-ui-BmI9Z0Xx.js";import{t as a}from"./DemoModal2-ok8s6Swr.js";export{a as default};
