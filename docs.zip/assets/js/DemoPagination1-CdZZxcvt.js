import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoPagination1-DIekLHQp.js";export{o as default};
