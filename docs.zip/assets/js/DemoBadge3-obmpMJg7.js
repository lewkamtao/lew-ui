import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoBadge3-B36qm4jG.js";export{e as default};
