import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSlider3-D64YBVJN.js";export{o as default};
