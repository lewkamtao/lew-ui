import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoInput3-BUqSXe98.js";export{a as default};
