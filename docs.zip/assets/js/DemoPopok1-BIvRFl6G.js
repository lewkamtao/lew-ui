import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoPopok1-CufWVDM-.js";export{a as default};
