import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoTextTrim3-D77ef2zF.js";export{m as default};
