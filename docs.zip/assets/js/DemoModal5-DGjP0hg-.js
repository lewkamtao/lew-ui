import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoModal5-BEDEpHPQ.js";export{a as default};
