import"./lew-ui-BmI9Z0Xx.js";import{t as e}from"./DemoImage2-r2lK9Qcz.js";export{e as default};
