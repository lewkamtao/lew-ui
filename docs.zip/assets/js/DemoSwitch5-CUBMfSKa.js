import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoSwitch5-k1bgklVH.js";export{a as default};
