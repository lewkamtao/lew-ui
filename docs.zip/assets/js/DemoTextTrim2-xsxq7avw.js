import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoTextTrim2-Dph987Ud.js";export{m as default};
