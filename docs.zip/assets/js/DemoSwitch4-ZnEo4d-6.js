import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoSwitch4-BRisdm8X.js";export{a as default};
