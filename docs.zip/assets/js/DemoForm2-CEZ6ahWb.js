import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoForm2-D3GnB6Xh.js";export{m as default};
