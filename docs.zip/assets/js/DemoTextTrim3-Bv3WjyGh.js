import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoTextTrim3-BBs8Fs5s.js";export{m as default};
