import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoSwitch4-tSWbKRW1.js";export{a as default};
