import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoDialog2-DrQ-byEG.js";export{a as default};
