import"./lew-ui-D4rxVhOO.js";import{t as m}from"./DemoForm4-CsrRFmPJ.js";export{m as default};
