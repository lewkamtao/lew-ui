import"./lew-ui-D0fj-lLn.js";import"./vendor-DI90tgK9.js";import{t as e}from"./DemoTable11-BQ55Vg9P.js";export{e as default};
