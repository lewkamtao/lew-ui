import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoInputTag2-D-MM9C0v.js";export{o as default};
