import"./lew-ui-D4rxVhOO.js";import{t as o}from"./DemoFlex2-CIleYt0K.js";export{o as default};
