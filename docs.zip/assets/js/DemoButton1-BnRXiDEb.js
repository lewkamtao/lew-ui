import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoButton1-m0cFeIQx.js";export{a as default};
