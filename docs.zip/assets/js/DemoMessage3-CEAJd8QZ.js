import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoMessage3-CvWAT0pX.js";export{a as default};
