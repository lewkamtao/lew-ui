import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoFlex2-BtcZInBp.js";export{o as default};
