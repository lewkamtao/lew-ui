import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoRate3-BJcJOkiY.js";export{e as default};
