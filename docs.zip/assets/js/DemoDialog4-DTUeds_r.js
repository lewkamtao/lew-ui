import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoDialog4-ZbUWxQ_D.js";export{a as default};
