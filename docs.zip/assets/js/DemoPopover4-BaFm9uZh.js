import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoPopover4-I1vO00DO.js";export{e as default};
