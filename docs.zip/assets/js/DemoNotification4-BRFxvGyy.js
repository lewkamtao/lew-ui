import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoNotification4-jeNtND37.js";export{a as default};
