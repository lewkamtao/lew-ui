import"./lew-ui-Bz7GIUSM.js";import{t as o}from"./DemoMark1-CXGlNdSd.js";export{o as default};
