import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoInputTag5-0YAI-2Iu.js";export{o as default};
