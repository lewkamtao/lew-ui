import"./lew-ui-D0fj-lLn.js";import{t as a}from"./DemoButton2-I2evh8Uk.js";export{a as default};
