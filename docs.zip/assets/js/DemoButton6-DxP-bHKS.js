import"./lew-ui-Bz7GIUSM.js";import{t as a}from"./DemoButton6-DDW-0rzO.js";export{a as default};
