import"./lew-ui-Bz7GIUSM.js";import{t as m}from"./DemoTextTrim3-DwPRPV6H.js";export{m as default};
