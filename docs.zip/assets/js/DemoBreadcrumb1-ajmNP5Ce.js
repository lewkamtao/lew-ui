import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoBreadcrumb1-Dh6dCKN0.js";export{a as default};
