import"./lew-ui-CDhnpYIO.js";import{t as o}from"./DemoSelect1-CImVNDYf.js";export{o as default};
