import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoCollapse1-CgxO5O7x.js";export{a as default};
