import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoCollapse1-C3pU6VoP.js";export{a as default};
