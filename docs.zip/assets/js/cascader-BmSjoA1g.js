import{r as i}from"./rolldown-runtime-DYC1jRjs.js";import{Bi as n,Ci as s,Cn as c,Li as u,i as t,mi as d,pi as a,r as p,ui as m,wn as v,xn as h}from"./lew-ui-D0fj-lLn.js";import{fa as b}from"./vendor-DI90tgK9.js";import{t as g}from"./LewComponentInfo-DEhjborz.js";import{n as f,t as y}from"./LewDocsTables-sFcijSoZ.js";import"./LewCodeHighlighter-JKeKsb2W.js";import{t as w}from"./DemoCascader1-CmmCrzp0.js";import{t as _}from"./DemoCascader10-CR095VfC.js";import{t as C}from"./DemoCascader11-TGqvdZbQ.js";import{t as k}from"./DemoCascader12-Cf7lpvds.js";import{t as D}from"./DemoCascader2-BeDODk_V.js";import{t as P}from"./DemoCascader3-BKwMGSAG.js";import"./http-BLLpOuis.js";import{t as x}from"./DemoCascader4-DKza0XxO.js";import{t as M}from"./DemoCascader5-C9qlpmfi.js";import{t as S}from"./DemoCascader6-u_Quqte1.js";import{t as L}from"./DemoCascader7-CmtMIEJh.js";import{t as T}from"./DemoCascader8-D4mszUml.js";import{t as j}from"./DemoCascader9-DXMx3kMz.js";var B={title:"Emits",columnsKey:"emits",orderNum:99,data:p(v)},E={title:"Model",columnsKey:"model",orderNum:10,data:t(h)},$={title:"Props",columnsKey:"props",data:t(c)},l=i({emits:()=>B,model:()=>E,props:()=>$},1),A=`<script setup lang="ts">
const v = ref()
const options = [
  {
    value: 'electronics',
    label: 'Electronics',
    children: [
      {
        value: 'smartphone',
        label: 'Smartphone',
        children: [
          {
            value: 'ios',
            label: 'iOS Devices',
            children: [
              { value: 'iphone', label: 'iPhone' },
              { value: 'ipad', label: 'iPad', disabled: true },
            ],
          },
          {
            value: 'android',
            label: 'Android Devices',
            children: [
              { value: 'samsung', label: 'Samsung' },
              { value: 'huawei', label: 'Huawei' },
              { value: 'xiaomi', label: 'Xiaomi' },
              { value: 'oppo', label: 'OPPO', disabled: true },
            ],
          },
        ],
      },
      {
        value: 'computer',
        label: 'Computers',
        children: [
          {
            value: 'laptop',
            label: 'Laptops',
            children: [
              { value: 'macbook', label: 'MacBook' },
              { value: 'surface', label: 'Surface' },
              { value: 'thinkpad', label: 'ThinkPad' },
              { value: 'dell', label: 'Dell', disabled: true },
            ],
          },
          { value: 'desktop', label: 'Desktops', disabled: true },
        ],
      },
      {
        value: 'wearables',
        label: 'Wearable Devices',
        children: [
          { value: 'smartwatch', label: 'Smartwatch' },
          {
            value: 'fitnesstracker',
            label: 'Fitness Tracker',
            disabled: true,
          },
        ],
      },
    ],
  },
  {
    value: 'appliances',
    label: 'Home Appliances',
    children: [
      {
        value: 'kitchen',
        label: 'Kitchen Appliances',
        children: [
          { value: 'refrigerator', label: 'Refrigerator' },
          { value: 'microwave', label: 'Microwave' },
          {
            value: 'dishwasher',
            label: 'Dishwasher',
            disabled: true,
          },
        ],
      },
      {
        value: 'laundry',
        label: 'Laundry Appliances',
        children: [
          { value: 'washingmachine', label: 'Washing Machine' },
          { value: 'dryer', label: 'Dryer', disabled: true },
        ],
      },
    ],
  },
  {
    value: 'entertainment',
    label: 'Entertainment Devices',
    children: [
      {
        value: 'gaming',
        label: 'Gaming Devices',
        children: [
          { value: 'console', label: 'Game Console' },
          { value: 'vr', label: 'VR Devices', disabled: true },
        ],
      },
      {
        value: 'audio',
        label: 'Audio Devices',
        children: [
          { value: 'speakers', label: 'Speakers' },
          { value: 'headphones', label: 'Headphones' },
        ],
      },
    ],
  },
]

function change(e: any, item: any) {
  console.log(e, item)
}
<\/script>

<template>
  <lew-cascader
    v-model="v"
    clearable
    width="300px"
    :options="options"
    placeholder="Explore high-end tech products"
    @change="change"
  />
</template>
`,K=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

function change(_e: any) {
  // console.log(_e)
}
const v = ref()
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader
      v-model="v"
      :only-leaf-selectable="false"
      :options="cityTree"
      @change="change"
    />
  </div>
</template>
`,O=`<script setup lang="ts">
const v = ref()

const techProductOptions = [
  {
    value: 'smartphones',
    label: 'Smartphones',
    children: [
      {
        value: 'apple',
        label: 'Apple',
        children: [
          { value: 'iphone13', label: 'iPhone 13' },
          { value: 'iphone12', label: 'iPhone 12' },
          { value: 'iphoneSE', label: 'iPhone SE', disabled: true },
        ],
      },
      {
        value: 'android',
        label: 'Android',
        children: [
          { value: 'samsung', label: 'Samsung Galaxy' },
          { value: 'huawei', label: 'Huawei Mate' },
          { value: 'xiaomi', label: 'Xiaomi', disabled: true },
        ],
      },
    ],
  },
  {
    value: 'laptops',
    label: 'Laptops',
    children: [
      {
        value: 'macbook',
        label: 'MacBook',
        children: [
          { value: 'macbookAir', label: 'MacBook Air' },
          { value: 'macbookPro', label: 'MacBook Pro' },
        ],
      },
      {
        value: 'windows',
        label: 'Windows Laptops',
        children: [
          { value: 'dell', label: 'Dell XPS' },
          { value: 'lenovo', label: 'Lenovo ThinkPad' },
          { value: 'hp', label: 'HP Spectre', disabled: true },
        ],
      },
    ],
  },
  {
    value: 'wearables',
    label: 'Wearables',
    children: [
      { value: 'smartwatch', label: 'Smartwatch' },
      { value: 'fitnesstracker', label: 'Fitness Tracker' },
      { value: 'vr', label: 'VR Headset', disabled: true },
    ],
  },
]
<\/script>

<template>
  <lew-cascader
    v-model="v"
    free
    width="300px"
    :show-all-levels="false"
    :options="techProductOptions"
    placeholder="Select Tech Products"
  />
</template>
`,z=`<script setup lang="ts">
import axios from 'docs/axios/http'

function loadMethod(item?: any) {
  const levelMap: any = {
    0: 'province',
    1: 'city',
    2: 'area',
    3: 'street',
  }
  // item 无值时，初始化第一层数据
  const _typeKey = item ? item.level + 1 : 0

  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: \`/common/region/\${levelMap[_typeKey] || 'province'}/\${
          item ? item.value : 0
        }\`,
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}
function change(item: any) {
  console.log(item)
}
const v = ref('')
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader v-model="v" :load-method="loadMethod" @change="change" />
  </div>
</template>
`,H=`<script setup lang="ts">
const selectedProduct = ref()
const productCategories = [
  {
    value: 'skincare',
    label: 'Skincare',
    children: [
      {
        value: 'cleanser',
        label: 'Cleansers',
        children: [
          { value: 'foam', label: 'Foam Cleanser' },
          { value: 'gel', label: 'Gel Cleanser' },
          { value: 'oil', label: 'Cleansing Oil' },
        ],
      },
      {
        value: 'moisturizer',
        label: 'Moisturizers',
        children: [
          { value: 'cream', label: 'Cream' },
          { value: 'lotion', label: 'Lotion' },
          { value: 'essence', label: 'Essence' },
        ],
      },
    ],
  },
  {
    value: 'makeup',
    label: 'Makeup',
    children: [
      {
        value: 'face',
        label: 'Face Makeup',
        children: [
          { value: 'foundation', label: 'Foundation' },
          { value: 'concealer', label: 'Concealer' },
          { value: 'powder', label: 'Powder' },
        ],
      },
      {
        value: 'eye',
        label: 'Eye Makeup',
        children: [
          { value: 'eyeshadow', label: 'Eyeshadow' },
          { value: 'eyeliner', label: 'Eyeliner' },
          { value: 'mascara', label: 'Mascara' },
        ],
      },
    ],
  },
]

function handleChange(value: string[]) {
  console.log('Selected product categories:', value)
}
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader
      v-model="selectedProduct"
      clearable
      :options="productCategories"
      placeholder="Select Beauty Products"
      @change="handleChange"
    />
  </div>
</template>
`,N=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref(26)
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader v-model="v" readonly :options="cityTree" />
  </div>
</template>
`,G=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref(26)
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader v-model="v" disabled :options="cityTree" />
  </div>
</template>
`,F=`<script setup lang="ts">
const options = [
  {
    value: 1,
    label: 'Asia',
    children: [
      {
        value: 2,
        label: 'China',
        children: [
          {
            value: 3,
            label: 'Beijing',
          },
          {
            value: 4,
            label: 'Shanghai',
          },
          { value: 5, label: 'Hangzhou' },
        ],
      },
      {
        value: 6,
        label: 'Japan',
        children: [
          {
            value: 7,
            label: 'Tokyo',
          },
          {
            value: 8,
            label: 'Osaka',
          },
          {
            value: 9,
            label: 'Kyoto',
          },
        ],
      },
      {
        value: 10,
        label: 'South Korea',
        children: [
          { value: 11, label: 'Seoul' },
          {
            value: 12,
            label: 'Busan',
          },
          { value: 13, label: 'Daegu' },
        ],
      },
    ],
  },
  {
    value: 14,
    label: 'Europe',
    disabled: true,
    children: [
      {
        value: 15,
        label: 'France',
        children: [
          {
            value: 16,
            label: 'Paris',
          },
          {
            value: 17,
            label: 'Marseille',
          },
          {
            value: 18,
            label: 'Lyon',
          },
        ],
      },
      {
        value: 19,
        label: 'United Kingdom',
        children: [
          { value: 20, label: 'London' },
          {
            value: 21,
            label: 'Birmingham',
          },
          {
            value: 22,
            label: 'Manchester',
          },
        ],
      },
    ],
  },
  {
    value: 23,
    label: 'North America',
    children: [
      {
        value: 24,
        label: 'United States',
        children: [
          {
            value: 25,
            label: 'New York',
          },
          {
            value: 26,
            label: 'Los Angeles',
          },
          {
            value: 27,
            label: 'Washington, D.C.',
          },
        ],
      },
      {
        value: 28,
        label: 'Canada',
        children: [
          {
            value: 29,
            label: 'Toronto',
          },
          {
            value: 30,
            label: 'Montreal',
          },
          {
            value: 31,
            label: 'Ottawa',
          },
        ],
      },
    ],
  },
]
const v = ref()
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader
      v-model="v"
      :options="options"
      placeholder="Please select your travel destination"
    />
  </div>
</template>
`,R=`<script setup lang="ts">
import type { LewCascaderOption } from 'lew-ui/types'
import { LewCascader } from 'lew-ui'

const cascaderValue = ref()
async function initMethod(): Promise<LewCascaderOption[]> {
  await new Promise(resolve => setTimeout(resolve, 2000))
  return Promise.resolve([
    {
      label: 'Beijing',
      value: 'beijing',
      key: 'beijing',
      children: [
        {
          label: 'Chaoyang District',
          value: 'chaoyang',
          key: 'chaoyang',
          children: [
            { label: 'Sanlitun', value: 'sanlitun', key: 'sanlitun' },
            { label: 'Guomao', value: 'guomao', key: 'guomao' },
          ],
        },
        {
          label: 'Haidian District',
          value: 'haidian',
          key: 'haidian',
          children: [
            { label: 'Zhongguancun', value: 'zhongguancun', key: 'zhongguancun' },
            { label: 'Wudaokou', value: 'wudaokou', key: 'wudaokou' },
          ],
        },
      ],
    },
    {
      label: 'Shanghai',
      value: 'shanghai',
      key: 'shanghai',
      children: [
        {
          label: 'Pudong New District',
          value: 'pudong',
          key: 'pudong',
          children: [
            { label: 'Lujiazui', value: 'lujiazui', key: 'lujiazui' },
            { label: 'Zhangjiang', value: 'zhangjiang', key: 'zhangjiang' },
          ],
        },
        {
          label: 'Huangpu District',
          value: 'huangpu',
          key: 'huangpu',
          children: [
            { label: 'The Bund', value: 'waitan', key: 'waitan' },
            { label: 'Nanjing Road', value: 'nanjinglu', key: 'nanjinglu' },
          ],
        },
      ],
    },
  ])
}

const updateKey = ref(0)

function load() {
  updateKey.value++
}
<\/script>

<template>
  <LewCascader
    :key="updateKey"
    v-model="cascaderValue"
    :init-method="initMethod"
    placeholder="Please select region"
    width="300px"
  />
  <lew-button type="ghost" style="margin-top: 20px" @click="load">
    load again {{ updateKey }}
  </lew-button>
</template>
`,W=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

function change(e: any, items: any) {
  console.log(e, items)
}
const v = ref([])
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader v-model="v" multiple :options="cityTree" @change="change" />
  </div>
</template>
`,V=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

function change(_e: any) {
  // console.log(_e)
}
const v = ref()
<\/script>

<template>
  <div style="width: 300px">
    <lew-cascader v-model="v" free multiple :options="cityTree" @change="change" />
  </div>
</template>
`,X=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

function change(_e: any) {
  // console.log(_e)
}
const v = ref()
<\/script>

<template>
  <lew-cascader
    v-model="v"
    width="300px"
    :only-leaf-selectable="false"
    multiple
    :options="cityTree"
    @change="change"
  />
</template>
`;const Z=[w,D,P,x,M,S,L,T,j,_,C,k],U=[A,K,O,z,H,N,G,F,R,W,V,X];var I={class:"demo-wrapper"},J=d({__name:"DemoCascader",setup(q){const o=b().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),r=u(Object.keys(l).map(e=>l[e]));return(e,Q)=>(s(),m("div",I,[a(g),a(f,{"demo-group":n(Z),"code-group":n(U),"component-name":n(o),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),a(y,{options:n(r)},null,8,["options"])]))}}),Y=J,ye=Y;export{ye as default};
