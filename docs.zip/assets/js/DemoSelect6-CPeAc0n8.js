import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect6-Dbxj2gZw.js";export{o as default};
