import"./lew-ui-D4rxVhOO.js";import{t as a}from"./DemoNotification5-BteShPrs.js";export{a as default};
