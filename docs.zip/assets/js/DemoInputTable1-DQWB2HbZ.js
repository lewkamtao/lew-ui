import"./lew-ui-Bz7GIUSM.js";import{t as e}from"./DemoInputTable1-M9jiryH3.js";export{e as default};
