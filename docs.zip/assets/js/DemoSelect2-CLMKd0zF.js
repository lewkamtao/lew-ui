import"./lew-ui-BmI9Z0Xx.js";import{t as o}from"./DemoSelect2-RiHLz-oq.js";export{o as default};
