import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoInputNumber4-C_iLdOf9.js";export{m as default};
