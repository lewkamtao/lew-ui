import"./lew-ui-CDhnpYIO.js";import{t}from"./DemoColorPicker5-D7-xag8-.js";export{t as default};
