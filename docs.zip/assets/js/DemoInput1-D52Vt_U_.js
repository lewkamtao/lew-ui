import"./lew-ui-CDhnpYIO.js";import{t as a}from"./DemoInput1-C6U9ltX-.js";export{a as default};
