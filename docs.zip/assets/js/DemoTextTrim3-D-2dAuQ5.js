import"./lew-ui-CDhnpYIO.js";import{t as m}from"./DemoTextTrim3-B60FJW7h.js";export{m as default};
