import"./lew-ui-D0fj-lLn.js";import{t as o}from"./DemoSelect14-CYO3w8BC.js";export{o as default};
