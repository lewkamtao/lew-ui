import"./lew-ui-BmI9Z0Xx.js";import{t as m}from"./DemoInputNumber3-Byyx_q0O.js";export{m as default};
