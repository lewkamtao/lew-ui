import"./lew-ui-D0fj-lLn.js";import{t as e}from"./DemoRate2-BoUZl8Pz.js";export{e as default};
