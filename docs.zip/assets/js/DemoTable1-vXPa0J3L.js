import"./lew-ui-CDhnpYIO.js";import{t as e}from"./DemoTable1-Cz29VTZP.js";export{e as default};
