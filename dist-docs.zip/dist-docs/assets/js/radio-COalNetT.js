import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{At as i,Di as a,Mt as d,Zr as p,ei as n,i as o,jt as u,r as m,ti as c,ui as v,wi as f}from"./lew-ui-D4rxVhOO.js";import{da as b}from"./vendor-DE_9brhS.js";import{n as _,r as g,t as D}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as R}from"./DemoRadio1-DLRCHLkx.js";import{t as h}from"./DemoRadio2-CxBzhxYO.js";import{t as B}from"./DemoRadio3-CAajdVsX.js";import{t as w}from"./DemoRadio4-Q1F46jn8.js";import{t as y}from"./DemoRadio5-iHlXIH7V.js";import{t as O}from"./DemoRadio6-CoqQff9G.js";var k={title:"Emits",columnsKey:"emits",orderNum:99,data:m(d)},L={title:"Model",columnsKey:"model",orderNum:1,data:o(i)},C={title:"Props(RadioGroup)",columnsKey:"props",orderNum:2,data:o(u)},A={title:"Options",columnsKey:"props",orderNum:5,data:[{name:"label",description:"标题",type:"string",default:"-"},{name:"value",description:"值",type:"string",default:"-"},{name:"disabled",description:"禁用",type:"boolean",default:"false"}]},l=s({emits:()=>k,model:()=>L,props:()=>C,radioOptions:()=>A},1),M=`<script setup lang="ts">
const iceCreamFlavors = ref([
  { label: 'Vanilla', value: 'vanilla' },
  { label: 'Chocolate', value: 'chocolate' },
  { label: 'Strawberry', value: 'strawberry' },
  { label: 'Matcha', value: 'matcha' },
  { label: 'Mango', value: 'mango' },
])

const selectedFlavor = ref('')
<\/script>

<template>
  <lew-radio-group v-model="selectedFlavor" :options="iceCreamFlavors" />
</template>
`,N=`<script setup lang="ts">
const animalOptions = ref([
  { label: 'Lion', value: 'lion' },
  { label: 'Tiger', value: 'tiger' },
  { label: 'Elephant', value: 'elephant' },
  { label: 'Giraffe', value: 'giraffe', disabled: true },
  { label: 'Zebra', value: 'zebra' },
])

const selectedAnimal = ref('tiger')
<\/script>

<template>
  <lew-radio-group v-model="selectedAnimal" direction="y" :options="animalOptions" />
</template>
`,x=`<script setup lang="ts">
const clothingBrandOptions = ref([
  { label: 'Nike', value: 'nike' },
  { label: 'Adidas', value: 'adidas' },
  { label: 'Puma', value: 'puma' },
  { label: 'Under Armour', value: 'under_armour' },
  { label: 'Reebok', value: 'reebok' },
])

const selectedBrand = ref('')
<\/script>

<template>
  <lew-radio-group
    v-model="selectedBrand"
    block
    :iconable="false"
    :options="clothingBrandOptions"
  />
</template>
`,E=`<script setup lang="ts">
const sportsOptions = ref([
  { label: 'Basketball', value: 'basketball' },
  { label: 'Soccer', value: 'soccer' },
  { label: 'Tennis', value: 'tennis' },
  { label: 'Baseball', value: 'baseball' },
  { label: 'Swimming', value: 'swimming' },
])

const selectedSport = ref('')
<\/script>

<template>
  <lew-radio-group
    v-model="selectedSport"
    block
    :round="false"
    :options="sportsOptions"
  />
</template>
`,G=`<script setup lang="ts">
const carBrandOptions = ref([
  { label: 'Ferrari', value: 'ferrari' },
  { label: 'Lamborghini', value: 'lamborghini' },
  { label: 'Porsche', value: 'porsche' },
  { label: 'McLaren', value: 'mclaren' },
  { label: 'Bugatti', value: 'bugatti' },
])

const selectedBrand = ref('porsche')
<\/script>

<template>
  <lew-radio-group
    v-model="selectedBrand"
    block
    readonly
    :options="carBrandOptions"
  />
</template>
`,$=`<script setup lang="ts">
const beautyBrandOptions = ref([
  { label: 'Chanel', value: 'chanel' },
  { label: 'Dior', value: 'dior' },
  { label: 'MAC', value: 'mac' },
  { label: 'Estée Lauder', value: 'estee_lauder' },
  { label: 'Lancôme', value: 'lancome' },
])

const selectedBrand = ref('chanel')
<\/script>

<template>
  <lew-radio-group
    v-model="selectedBrand"
    block
    disabled
    :options="beautyBrandOptions"
  />
</template>
`;const F=[R,h,B,w,y,O],P=[M,N,x,E,G,$];var S={class:"demo-wrapper"},K=c({__name:"DemoRadio",setup(Z){const t=b().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),r=f(Object.keys(l).map(e=>l[e]));return(e,j)=>(v(),p("div",S,[n(g),n(_,{"demo-group":a(F),"code-group":a(P),"component-name":a(t),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),n(D,{options:a(r)},null,8,["options"])]))}}),T=K,ee=T;export{ee as default};
