import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Di as e,Zr as p,ei as l,i as t,r as i,ti as m,ui as d,vt as u,wi as v,xt as c,yt as f}from"./lew-ui-D4rxVhOO.js";import{da as g}from"./vendor-DE_9brhS.js";import{n as _,r as b,t as w}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as R}from"./DemoSliderRange1-BkLkzk_8.js";import{t as x}from"./DemoSliderRange2-8k-XI1E1.js";import{t as D}from"./DemoSliderRange3-BMZuePmk.js";import{t as S}from"./DemoSliderRange4-WuWza85l.js";import{t as y}from"./DemoSliderRange5-BQZY97JJ.js";import{t as h}from"./DemoSliderRange6-B52S5opw.js";var C={title:"Emits",columnsKey:"emits",orderNum:99,data:i(f)},L={title:"Model",columnsKey:"model",orderNum:10,data:t(u)},$={title:"Props",columnsKey:"props",orderNum:10,data:t(c)},a=s({emits:()=>C,model:()=>L,props:()=>$},1),N=`<script setup lang="ts">
const v = ref([25, 75])
<\/script>

<template>
  <lew-flex width="500px" direction="y" x="start">
    <lew-slider-range
      v-model="v"
      size="small"
      :options="[
        {
          label: '低',
          value: 0,
        },
        {
          label: '中',
          value: 50,
        },
        {
          label: '高',
          value: 100,
        },
      ]"
    />

    <lew-slider-range
      v-model="v"
      :options="[
        {
          label: '低',
          value: 0,
        },
        {
          label: '中',
          value: 50,
        },
        {
          label: '高',
          value: 100,
        },
      ]"
    />

    <lew-slider-range
      v-model="v"
      size="large"
      :options="[
        {
          label: '低',
          value: 0,
        },
        {
          label: '中',
          value: 50,
        },
        {
          label: '高',
          value: 100,
        },
      ]"
    />
  </lew-flex>
</template>
`,E=`<script setup lang="ts">
const v = ref([25, 75])
<\/script>

<template>
  <lew-slider-range
    v-model="v"
    width="500px"
    step="5"
    range
    :options="[
      {
        label: '低',
        value: 0,
      },
      {
        label: '中',
        value: 50,
      },
      {
        label: '高',
        value: 100,
      },
    ]"
  />
</template>
`,k=`<script setup lang="ts">
const v = ref([30, 60])
<\/script>

<template>
  <lew-slider-range
    v-model="v"
    width="500px"
    step="5"
    max="70"
    min="30"
    range
    :options="[
      {
        label: '低',
        value: 0,
      },
      {
        label: '中',
        value: 50,
      },
      {
        label: '高',
        value: 100,
      },
    ]"
  />
</template>
`,B=`<script setup lang="ts">
const v = ref([25, 50])
<\/script>

<template>
  <lew-slider-range
    v-model="v"
    width="500px"
    readonly
    range
    :options="[
      {
        label: '低',
        value: 0,
      },
      {
        label: '中',
        value: 50,
      },
      {
        label: '高',
        value: 100,
      },
    ]"
  />
</template>
`,K=`<script setup lang="ts">
const v = ref([30, 60])
<\/script>

<template>
  <lew-slider-range
    v-model="v"
    width="500px"
    disabled
    range
    :options="[
      {
        label: '低',
        value: 0,
      },
      {
        label: '中',
        value: 50,
      },
      {
        label: '高',
        value: 100,
      },
    ]"
  />
</template>
`,P=`<script setup lang="ts">
const v = ref([-10, 40])
<\/script>

<template>
  <lew-slider-range
    v-model="v"
    width="700px"
    max="100"
    min="-30"
    range
    :options="[
      {
        label: '极冷',
        value: -30,
      },
      {
        label: '冷 (0°C)',
        value: 0,
      },
      {
        label: '温暖 (20°C)',
        value: 20,
      },
      {
        label: '剧热 (50°C)',
        value: 50,
      },
      {
        label: '极热',
        value: 100,
      },
    ]"
    step="1"
  />
</template>
`;const z=[R,x,D,S,y,h],G=[N,E,k,B,K,P];var M={class:"demo-wrapper"},Z=m({__name:"DemoSliderRange",setup(A){const r=g().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),o=v(Object.keys(a).map(n=>a[n]));return(n,I)=>(d(),p("div",M,[l(b),l(_,{"demo-group":e(z),"code-group":e(G),"component-name":e(r),columns:1,gap:"20px"},null,8,["demo-group","code-group","component-name"]),l(w,{options:e(o)},null,8,["options"])]))}}),j=Z,Y=j;export{Y as default};
