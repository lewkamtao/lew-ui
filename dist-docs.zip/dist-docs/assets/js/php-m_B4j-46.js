import{vn as p}from"./vendor-DE_9brhS.js";export{p as default};
