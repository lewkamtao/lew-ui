import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Di as t,Zr as p,ct as m,ei as a,i as n,lt as i,r as d,st as c,ti as u,ui as x,wi as f}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as h,r as _,t as w}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as g}from"./DemoTextarea1-jnpXSH5n.js";import{t as T}from"./DemoTextarea2-CxSPL1m6.js";import{t as D}from"./DemoTextarea3-07Esw2vl.js";import{t as b}from"./DemoTextarea4-De5InVJ0.js";import{t as y}from"./DemoTextarea5-fQxQXT5L.js";import{t as $}from"./DemoTextarea6-CQrxyc7L.js";import{t as L}from"./DemoTextarea7-DSSfByAv.js";import{t as k}from"./DemoTextarea8-CKtuuEOt.js";var z={title:"Emits",columnsKey:"emits",orderNum:99,data:d(i)},N={title:"Model",columnsKey:"model",orderNum:1,data:n(c)},E={title:"Props",columnsKey:"props",orderNum:1,data:n(m)},r=s({emits:()=>z,model:()=>N,props:()=>E},1),B=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <lew-textarea v-model="value" width="300px" min-height="50px" />
</template>
`,C=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <lew-textarea
    v-model="value"
    width="300px"
    placeholder="Limit the number of characters"
    show-count
    :max-length="300"
    clearable
  />
</template>
`,K=`<script setup lang="ts">
const v = ref('Selecting text after gathering')
<\/script>

<template>
  <lew-textarea v-model="v" width="300px" select-by-focus />
</template>
`,M=`<script setup lang="ts">
const v = ref('This is a textarea')
<\/script>

<template>
  <lew-textarea v-model="v" width="300px" clearable />
</template>
`,P=`<script setup lang="ts">
const v = ref('This is a read-only state')
<\/script>

<template>
  <lew-textarea v-model="v" width="300px" placeholder="Read-only" readonly />
</template>
`,R=`<script setup lang="ts">
const v = ref('This is a disabled state')
<\/script>

<template>
  <lew-textarea v-model="v" width="300px" placeholder="Disabled" disabled />
</template>
`,G=`<script setup lang="ts">
const v = ref('')
function ok(v: string) {
  LewMessage.success(\`The input content is: \${v}\`)
}
<\/script>

<template>
  <lew-textarea v-model="v" width="300px" ok-by-enter clearable @ok="ok" />
</template>
`,Z=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <lew-flex style="width: 300px" gap="20px" x="start" direction="y">
    <lew-textarea v-model="value" resize="both" placeholder="both" min-height="80px" />
    <lew-textarea
      v-model="value"
      resize="vertical"
      placeholder="vertical"
      min-height="100px"
    />
    <lew-textarea
      v-model="value"
      resize="horizontal"
      placeholder="horizontal"
      min-height="120px"
    />
    <lew-textarea
      v-model="value"
      resize="both"
      placeholder="both + max-height + max-width"
      min-height="120px"
      max-height="200px"
      min-width="200px"
      max-width="400px"
    />
  </lew-flex>
</template>
`;const j=[g,T,D,b,y,$,L,k],A=[B,C,K,M,P,R,G,Z];var I={class:"demo-wrapper"},O=u({__name:"DemoTextarea",setup(V){const o=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),l=f(Object.keys(r).map(e=>r[e]));return(e,q)=>(x(),p("div",I,[a(_),a(h,{"demo-group":t(j),"code-group":t(A),"component-name":t(o),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),a(w,{options:t(l)},null,8,["options"])]))}}),S=O,oe=S;export{oe as default};
