import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Di as t,K as s,Zr as m,ei as o,i,ti as c,ui as l,wi as u}from"./lew-ui-D4rxVhOO.js";import{da as _}from"./vendor-DE_9brhS.js";import{n as d,r as g,t as f}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as w}from"./DemoImage1-BOe4kWS4.js";import{t as x}from"./DemoImage2-epgNUcmY.js";import{t as h}from"./DemoImage3-Krcc703C.js";var v={title:"Props",columnsKey:"props",orderNum:10,data:i(s)},a=r({props:()=>v},1),y=`<script setup lang="ts">
const src = ref('')

setTimeout(() => {
  src.value
    = 'https://app.tngeek.com/api_sso/open/file/b4c64ae_cat-8321993_1280.webp'
}, 2500)
<\/script>

<template>
  <lew-flex wrap x="start" y="end" gap="20px">
    <lew-image
      preview-group-key="cover1"
      object-position="top"
      width="150px"
      height="150px"
      :src="src"
    />
    <lew-image
      preview-group-key="cover"
      object-position="center"
      width="150px"
      height="150px"
      src="https://app.tngeek.com/api_sso/open/file/1f3e439_goat-9017896_1280.webp"
    />
  </lew-flex>
</template>
`,k=`<script setup lang="ts">
const key = ref(0)
<\/script>

<template>
  <lew-image
    :key="key"
    width="150px"
    height="150px"
    loading
    :src="\`https://cdn.pixabay.com/photo/2020/07/23/14/51/cat-paw-5431547_1280.jpg?key=\${key}\`"
  />
</template>
`,D=`<template>
  <lew-image width="150px" height="150px" src="https://cdn.pixabay.com" />
</template>
`;const I=[w,x,h],b=[y,k,D];var L={class:"demo-wrapper"},j=c({__name:"DemoImage",setup(B){const p=_().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),n=u(Object.keys(a).map(e=>a[e]));return(e,C)=>(l(),m("div",L,[o(g),o(d,{"demo-group":t(I),"code-group":t(b),"component-name":t(p),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),o(f,{options:t(n)},null,8,["options"])]))}}),$=j,E=$;export{E as default};
