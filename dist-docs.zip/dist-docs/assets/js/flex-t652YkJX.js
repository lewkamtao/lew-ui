import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Di as d,J as v,Zr as r,ei as e,i as a,ti as x,ui as t,wi as c}from"./lew-ui-D4rxVhOO.js";import{da as b}from"./vendor-DE_9brhS.js";import{n as p,r as f,t as m}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as w}from"./DemoFlex1-B4tCUBSR.js";import{t as u}from"./DemoFlex2-CIleYt0K.js";import{t as y}from"./DemoFlex3-COh9zWTd.js";var g={title:"Props",columnsKey:"props",orderNum:10,data:a(v)},i=s({props:()=>g},1),_=`<template>
  <div>
    <div class="demo">
      <lew-flex direction="x" x="start" y="start">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="center" y="start">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="end" y="start">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
    <div class="demo">
      <lew-flex direction="x" x="start" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="center" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="end" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
    <div class="demo">
      <lew-flex direction="x" x="start" y="end">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="center" y="end">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="end" y="end">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.demo {
  display: flex;
  justify-content: center;
  align-items: center;
}
.lew-flex {
  border: 1px var(--lew-bgcolor-2) solid;
  border-radius: var(--lew-border-radius-small);
  background-color: var(--lew-bgcolor-1);
  margin-bottom: 20px;
  width: 200px;
  height: 200px;
  padding: 5px;
  box-sizing: border-box;
  margin: 10px;
  .box {
    box-sizing: border-box;
    > div {
      display: inline-block;
      padding: 10px;
      font-size: 14px;
      border-radius: var(--lew-border-radius-small);
      background-color: var(--lew-color-primary);
    }
  }
}
</style>
`,k=`<template>
  <div>
    <div class="demo">
      <lew-flex direction="y" x="start" y="start">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="center" y="start">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="end" y="start">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
    <div class="demo">
      <lew-flex direction="y" x="start" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="center" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="end" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
    <div class="demo">
      <lew-flex direction="y" x="start" y="end">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="center" y="end">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="end" y="end">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.demo {
  display: flex;
  justify-content: center;
  align-items: center;
}
.lew-flex {
  border: 1px var(--lew-bgcolor-2) solid;
  border-radius: var(--lew-border-radius-small);
  background-color: var(--lew-bgcolor-1);
  margin-bottom: 20px;
  width: 200px;
  height: 200px;
  padding: 5px;
  box-sizing: border-box;
  margin: 10px;
  .box {
    box-sizing: border-box;
    > div {
      display: inline-block;
      padding: 10px;
      font-size: 14px;
      border-radius: var(--lew-border-radius-small);
      background-color: var(--lew-color-primary);
    }
  }
}
</style>
`,D=`<template>
  <div>
    <div class="demo">
      <lew-flex direction="x" x="start" y="center" mode="between">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="center" y="center" mode="around">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="x" x="center" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
    <div class="demo">
      <lew-flex direction="y" x="start" y="start" mode="between">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="center" y="start" mode="around">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
      <lew-flex direction="y" x="center" y="center">
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
        <div class="box">
          <div />
        </div>
      </lew-flex>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.demo {
  display: flex;
  justify-content: center;
  align-items: center;
}
.lew-flex {
  border: 1px var(--lew-bgcolor-2) solid;
  border-radius: var(--lew-border-radius-small);
  background-color: var(--lew-bgcolor-1);
  margin-bottom: 20px;
  width: 200px;
  height: 200px;
  padding: 5px;
  box-sizing: border-box;
  margin: 10px;
  .box {
    box-sizing: border-box;
    > div {
      display: inline-block;
      padding: 10px;
      font-size: 14px;
      border-radius: var(--lew-border-radius-small);
      background-color: var(--lew-color-primary);
    }
  }
}
</style>
`;const h=[w,u,y],z=[_,k,D];var F={class:"demo-wrapper"},L=x({__name:"DemoFlex",setup(B){const l=b().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),o=c(Object.keys(i).map(n=>i[n]));return(n,C)=>(t(),r("div",F,[e(f),e(p,{"demo-group":d(h),"code-group":d(z),"component-name":d(l),gap:"20px"},null,8,["demo-group","code-group","component-name"]),e(m,{options:d(o)},null,8,["options"])]))}}),j=L,I=j;export{I as default};
