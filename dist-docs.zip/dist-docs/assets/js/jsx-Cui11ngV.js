import{Ur as r}from"./vendor-DE_9brhS.js";export{r as default};
