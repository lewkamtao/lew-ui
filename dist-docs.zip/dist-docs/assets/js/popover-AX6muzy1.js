import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Di as e,Zr as s,ei as t,hn as p,i,mn as c,r as d,ti as m,ui as v,wi as u}from"./lew-ui-D4rxVhOO.js";import{da as f}from"./vendor-DE_9brhS.js";import{n as g,r as x,t as h}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as b}from"./DemoPopover1-9I-VJM-b.js";import{t as w}from"./DemoPopover2-BsdI-EGM.js";import{t as y}from"./DemoPopover3-DP3NlKbb.js";import{t as _}from"./DemoPopover4-FHu4gjy7.js";import{t as z}from"./DemoPopover5-CdVhPpgZ.js";var q={title:"Emits",columnsKey:"emits",orderNum:99,data:d(p)},P={title:"Props",columnsKey:"props",orderNum:10,data:i(c)},k={title:"Slots",columnsKey:"slots",data:[{name:"trigger",description:"触发的节点",params:"-"},{name:"popover-body",description:"触发展示的内容主体",params:"-"}]},o=r({emits:()=>q,props:()=>P,slots:()=>k},1),D=`<script setup lang="ts">
const data = ref({
  name: 'Steve Jobs',
  title: 'Co-founder of Apple Inc.',
  birth: 'February 24, 1955',
  death: 'October 5, 2011',
  achievements: [
    'Founded Apple Inc.',
    'Launched Macintosh computer',
    'Founded NeXT',
    'Acquired Pixar',
    'Returned to Apple and launched iPod, iPhone, iPad',
  ],
  quote: 'Stay hungry, stay foolish.',
})
<\/script>

<template>
  <lew-popover trigger="hover" placement="bottom-start">
    <template #trigger>
      <lew-avatar
        shape="circle"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/146d572968e09c8bdc4f45ef58ca110_cn9qli_.jpeg"
      />
    </template>
    <template #popover-body>
      <div class="popover-body">
        <div class="header">
          <h3 class="name">
            {{ data.name }}
          </h3>
          <span class="title">{{ data.title }}</span>
        </div>

        <div class="info">
          <div class="info-item">
            <span class="label">Birth</span>
            <span class="value">{{ data.birth }}</span>
          </div>
          <div class="info-item">
            <span class="label">Death</span>
            <span class="value">{{ data.death }}</span>
          </div>
        </div>

        <div class="achievements">
          <h4>Major Achievements</h4>
          <ul>
            <li v-for="(item, index) in data.achievements" :key="index">
              {{ item }}
            </li>
          </ul>
        </div>

        <div class="quote">
          <p>"{{ data.quote }}"</p>
        </div>
      </div>
    </template>
  </lew-popover>
</template>

<style lang="scss" scoped>
.popover-body {
  padding: 16px;
  box-sizing: border-box;
  width: 320px;

  .header {
    margin-bottom: 16px;

    .name {
      margin: 0 0 4px;
      font-size: 18px;
      font-weight: 600;
      color: var(--lew-text-color-1);
    }

    .title {
      font-size: 14px;
      color: var(--lew-text-color-2);
    }
  }

  .info {
    margin-bottom: 16px;
    padding: 12px;
    background: var(--lew-bgcolor-2);
    border-radius: 8px;

    .info-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;

      &:last-child {
        margin-bottom: 0;
      }

      .label {
        color: var(--lew-text-color-2);
      }

      .value {
        color: var(--lew-text-color-1);
        font-weight: 500;
      }
    }
  }

  .achievements {
    margin-bottom: 16px;

    h4 {
      margin: 0 0 8px;
      font-size: 14px;
      color: var(--lew-text-color-1);
    }

    ul {
      margin: 0;
      padding-left: 20px;

      li {
        margin-bottom: 4px;
        font-size: 13px;
        color: var(--lew-text-color-2);
        line-height: 1.5;

        &:last-child {
          margin-bottom: 0;
        }
      }
    }
  }

  .quote {
    padding-top: 16px;
    border-top: 1px solid var(--lew-border-color);

    p {
      margin: 0;
      font-size: 14px;
      color: var(--lew-text-color-2);
      font-style: italic;
      text-align: center;
    }
  }
}
</style>
`,j=`<script setup lang="ts">
const data = ref({
  name: 'Steve Jobs',
  title: 'Co-founder of Apple Inc.',
  quote: 'Stay hungry, stay foolish.',
})
<\/script>

<template>
  <lew-popover trigger="click" placement="bottom-start">
    <template #trigger>
      <lew-tag style="cursor: pointer">
        Steve Jobs
      </lew-tag>
    </template>
    <template #popover-body>
      <div class="popover-body">
        <lew-flex x="center" y="center">
          <lew-avatar
            size="120"
            shape="circle"
            src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/146d572968e09c8bdc4f45ef58ca110_cn9qli_.jpeg"
          />
        </lew-flex>

        <div class="info">
          <h3 class="name">
            {{ data.name }}
          </h3>
          <span class="title">{{ data.title }}</span>
        </div>

        <div class="quote">
          <p>"{{ data.quote }}"</p>
        </div>
      </div>
    </template>
  </lew-popover>
</template>

<style lang="scss" scoped>
.popover-body {
  padding: 16px;
  box-sizing: border-box;
  width: 280px;

  .info {
    margin: 16px 0;
    text-align: center;

    .name {
      margin: 0 0 4px;
      font-size: 18px;
      font-weight: 600;
      color: var(--lew-text-color-1);
    }

    .title {
      font-size: 14px;
      color: var(--lew-text-color-2);
    }
  }

  .quote {
    padding-top: 16px;
    border-top: 1px solid var(--lew-border-color);

    p {
      margin: 0;
      font-size: 14px;
      color: var(--lew-text-color-2);
      font-style: italic;
      text-align: center;
    }
  }
}
</style>
`,A=`<script setup lang="ts">
const data = ref({
  name: 'Steve Jobs',
  title: 'Co-founder of Apple Inc.',
  quote: 'Stay hungry, stay foolish.',
})
<\/script>

<template>
  <lew-popover trigger="click" placement="bottom-start" disabled>
    <template #trigger>
      <lew-button type="ghost">
        Disabled
      </lew-button>
    </template>
    <template #popover-body>
      <div class="popover-body">
        <lew-flex x="center" y="center">
          <lew-avatar
            size="120"
            shape="circle"
            src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/146d572968e09c8bdc4f45ef58ca110_cn9qli_.jpeg"
          />
        </lew-flex>

        <div class="info">
          <h3 class="name">
            {{ data.name }}
          </h3>
          <span class="title">{{ data.title }}</span>
        </div>

        <div class="quote">
          <p>"{{ data.quote }}"</p>
        </div>
      </div>
    </template>
  </lew-popover>
</template>

<style lang="scss" scoped>
.popover-body {
  padding: 16px;
  box-sizing: border-box;
  width: 280px;

  .info {
    margin: 16px 0;
    text-align: center;

    .name {
      margin: 0 0 4px;
      font-size: 18px;
      font-weight: 600;
      color: var(--lew-text-color-1);
    }

    .title {
      font-size: 14px;
      color: var(--lew-text-color-2);
    }
  }

  .quote {
    padding-top: 16px;
    border-top: 1px solid var(--lew-border-color);

    p {
      margin: 0;
      font-size: 14px;
      color: var(--lew-text-color-2);
      font-style: italic;
      text-align: center;
    }
  }
}
</style>
`,C=`<script setup lang="ts">
const data = ref({
  name: 'Steve Jobs',
  title: 'Co-founder of Apple Inc.',
  quote: 'Stay hungry, stay foolish.',
})

const popoverRef = ref<any>(null)
function close() {
  popoverRef.value?.hide()
}
<\/script>

<template>
  <lew-popover
    ref="popoverRef"
    trigger="click"
    placement="bottom-start"
    :hide-on-click="false"
  >
    <template #trigger>
      <lew-tag style="cursor: pointer">
        Steve Jobs
      </lew-tag>
    </template>
    <template #popover-body>
      <div class="popover-body">
        <lew-flex x="center" y="center">
          <lew-avatar
            size="120"
            shape="circle"
            src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/146d572968e09c8bdc4f45ef58ca110_cn9qli_.jpeg"
          />
        </lew-flex>

        <div class="info">
          <h3 class="name">
            {{ data.name }}
          </h3>
          <span class="title">{{ data.title }}</span>
        </div>

        <div class="quote">
          <p>"{{ data.quote }}"</p>
        </div>

        <lew-flex x="center" y="center">
          <lew-button size="small" type="ghost" @click="close">
            Close
          </lew-button>
          <lew-button size="small" type="ghost" @click="close">
            Follow
          </lew-button>
        </lew-flex>
      </div>
    </template>
  </lew-popover>
</template>

<style lang="scss" scoped>
.popover-body {
  padding: 16px;
  box-sizing: border-box;
  width: 280px;

  .info {
    margin: 16px 0;
    text-align: center;

    .name {
      margin: 0 0 4px;
      font-size: 18px;
      font-weight: 600;
      color: var(--lew-text-color-1);
    }

    .title {
      font-size: 14px;
      color: var(--lew-text-color-2);
    }
  }

  .quote {
    padding-top: 16px;
    border-top: 1px solid var(--lew-border-color);
    margin-bottom: 16px;

    p {
      margin: 0;
      font-size: 14px;
      color: var(--lew-text-color-2);
      font-style: italic;
      text-align: center;
    }
  }
}
</style>
`,L=`<script setup lang="ts">
const data = ref<any>({})

const loading = ref(false)

function show() {
  loading.value = true
  data.value = {}
  setTimeout(() => {
    loading.value = false
    data.value = {
      name: 'Steve Jobs',
      title: 'Co-founder of Apple Inc.',
      birth: 'February 24, 1955',
      death: 'October 5, 2011',
      achievements: [
        'Founded Apple Inc.',
        'Launched Macintosh computer',
        'Founded NeXT',
        'Acquired Pixar',
        'Returned to Apple and launched iPod, iPhone, iPad',
      ],
      quote: 'Stay hungry, stay foolish.',
    }
  }, 1000)
}
<\/script>

<template>
  <lew-popover trigger="click" placement="bottom-start" :loading="loading" @show="show">
    <template #trigger>
      <lew-avatar
        style="cursor: pointer"
        shape="circle"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/146d572968e09c8bdc4f45ef58ca110_cn9qli_.jpeg"
      />
    </template>
    <template #popover-body>
      <div class="popover-body">
        <div class="header">
          <h3 class="name">
            {{ data.name }}
          </h3>
          <span class="title">{{ data.title }}</span>
        </div>

        <div class="info">
          <div class="info-item">
            <span class="label">Birth</span>
            <span class="value">{{ data.birth }}</span>
          </div>
          <div class="info-item">
            <span class="label">Death</span>
            <span class="value">{{ data.death }}</span>
          </div>
        </div>

        <div class="achievements">
          <h4>Major Achievements</h4>
          <ul>
            <li v-for="(item, index) in data.achievements" :key="index">
              {{ item }}
            </li>
          </ul>
        </div>

        <div class="quote">
          <p>"{{ data.quote }}"</p>
        </div>
      </div>
    </template>
  </lew-popover>
</template>

<style lang="scss" scoped>
.popover-body {
  padding: 16px;
  box-sizing: border-box;
  width: 320px;

  .header {
    margin-bottom: 16px;

    .name {
      margin: 0 0 4px;
      font-size: 18px;
      font-weight: 600;
      color: var(--lew-text-color-1);
    }

    .title {
      font-size: 14px;
      color: var(--lew-text-color-2);
    }
  }

  .info {
    margin-bottom: 16px;
    padding: 12px;
    background: var(--lew-bgcolor-2);
    border-radius: 8px;

    .info-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;

      &:last-child {
        margin-bottom: 0;
      }

      .label {
        color: var(--lew-text-color-2);
      }

      .value {
        color: var(--lew-text-color-1);
        font-weight: 500;
      }
    }
  }

  .achievements {
    margin-bottom: 16px;

    h4 {
      margin: 0 0 8px;
      font-size: 14px;
      color: var(--lew-text-color-1);
    }

    ul {
      margin: 0;
      padding-left: 20px;

      li {
        margin-bottom: 4px;
        font-size: 13px;
        color: var(--lew-text-color-2);
        line-height: 1.5;

        &:last-child {
          margin-bottom: 0;
        }
      }
    }
  }

  .quote {
    padding-top: 16px;
    border-top: 1px solid var(--lew-border-color);

    p {
      margin: 0;
      font-size: 14px;
      color: var(--lew-text-color-2);
      font-style: italic;
      text-align: center;
    }
  }
}
</style>
`;const S=[b,w,y,_,z],I=[D,j,A,C,L];var F={class:"demo-wrapper"},J=m({__name:"DemoPopover",setup(N){const a=f().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),l=u(Object.keys(o).map(n=>o[n]));return(n,B)=>(v(),s("div",F,[t(x),t(g,{"demo-group":e(S),"code-group":e(I),"component-name":e(a),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(h,{options:e(l)},null,8,["options"])]))}}),R=J,H=R;export{H as default};
