import{tr as a}from"./vendor-DE_9brhS.js";export{a as default};
