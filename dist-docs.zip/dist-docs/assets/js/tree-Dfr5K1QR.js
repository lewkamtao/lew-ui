import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Di as n,Dn as c,En as i,Tn as p,Zr as m,ei as t,i as a,r as d,ti as u,ui as f,wi as h}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as y,r as g,t as _}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import"./http-I7MJl4KM.js";import{t as k}from"./DemoTree1-BKCnshcH.js";import{t as T}from"./DemoTree2-CSD2G6qY.js";import{t as w}from"./DemoTree3-DetW4Ztm.js";import{t as x}from"./DemoTree4-CpcPOueZ.js";import{t as N}from"./DemoTree5-_YhoOG3Y.js";import{t as $}from"./DemoTree6-Mx6f0Mp5.js";import{t as D}from"./DemoTree7-Ds7ZKxeJ.js";import{t as b}from"./DemoTree8-D0ka1V5k.js";var L={title:"Emits",columnsKey:"emits",orderNum:99,data:d(c)},M={title:"Model",columnsKey:"model",data:a(p)},K={title:"Props",columnsKey:"props",data:a(i)},E={title:"Slots",columnsKey:"slots",data:[{name:"handle",description:"操作按钮",params:"-"}]},o=s({emits:()=>L,model:()=>M,props:()=>K,slots:()=>E},1),P=`<script setup lang="ts">
function createTree(path = '0', level = 2) {
  const list = []
  for (let i = 0; i < 2; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const options = createTree()
const v = ref<string[]>([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    multiple
    checkable
    searchable
    :free="false"
    :data-source="options"
    @change="change"
  />
</template>
`,B=`<script setup lang="ts">
function createTree(path = '0', level = 4) {
  const list = []
  for (let i = 0; i < 3; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const options = createTree()
const v = ref([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    checkable
    :data-source="options"
    @change="change"
  />
</template>
`,C=`<script setup lang="ts">
function createTree(path = '0', level = 2) {
  const list = []
  for (let i = 0; i < 5; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const options = createTree()
const v = ref([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    multiple
    free
    :data-source="options"
    checkable
    @change="change"
  />
</template>
`,j=`<script setup lang="ts">
function createTree(path = '0', level = 2) {
  const list = []
  for (let i = 0; i < 5; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const tree = createTree()
const v = ref([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    multiple
    checkable
    :free="false"
    :data-source="tree"
    @change="change"
  />
</template>
`,G=`<script setup lang="ts">
import axios from 'docs/axios/http'

function initMethod() {
  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: '/common/region/province/0',
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}

function loadMethod(item?: any) {
  const levelMap: any = {
    0: 'province',
    1: 'city',
    2: 'area',
    3: 'street',
  }
  // item 无值时，初始化第一层数据
  const _typeKey = item ? item.level + 1 : 0

  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: \`/common/region/\${levelMap[_typeKey] || 'province'}/\${item ? item.key : 0}\`,
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}
function change(item: any) {
  console.log(item)
}
const v = ref([])
<\/script>

<template>
  <div class="tree">
    <lew-tree
      v-model="v"
      multiple
      checkable
      height="500px"
      key-field="value"
      :init-method="initMethod"
      :load-method="loadMethod"
      @change="change"
    />
  </div>
</template>

<style lang="scss" scoped>
.tree {
  width: 300px;
}
</style>
`,R=`<script setup lang="ts">
function createTree(path = '0', level = 2) {
  const list = []
  for (let i = 0; i < 2; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const options = createTree()
const v = ref([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    multiple
    expand-all
    :checkable="false"
    :data-source="options"
    @change="change"
  />
</template>
`,Z=`<script setup lang="ts">
function createTree(path = '0', level = 4) {
  const list = []
  for (let i = 0; i < 3; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const options = createTree()
const v = ref([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    checkable
    show-line
    multiple
    :data-source="options"
    @change="change"
  />
</template>
`,z=`<script setup lang="ts">
function createTree(path = '0', level = 4) {
  const list = []
  for (let i = 0; i < 3; i += 1) {
    const key = \`\${path}-\${i}\`
    const treeNode: any = {
      label: key,
      key,
    }
    if (level > 0) {
      treeNode.children = createTree(key, level - 1)
    }
    list.push(treeNode)
  }
  return list
}
const options = createTree()
const v = ref([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree
    v-model="v"
    style="width: 300px"
    checkable
    show-line
    multiple
    :data-source="options"
    @change="change"
  >
    <template #item="{ props }">
      {{ props.label }}
      <span v-if="props.checked" size="small" type="success">
        （ {{ props.checked ? '已选择' : '' }}）
      </span>
    </template>
  </lew-tree>
</template>

<style lang="scss" scoped>
.empty {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 100%;
  height: 220px;
  gap: 10px;
  text-align: center;
  color: #aaa;
}
</style>
`;const A=[k,T,w,x,N,$,D,b],I=[P,B,C,j,G,R,Z,z];var O={class:"demo-wrapper"},S=u({__name:"DemoTree",setup(q){const l=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),r=h(Object.keys(o).map(e=>o[e]));return(e,F)=>(f(),m("div",O,[t(g),t(y,{"demo-group":n(A),"code-group":n(I),"component-name":n(l),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(_,{options:n(r)},null,8,["options"])]))}}),V=S,se=V;export{se as default};
