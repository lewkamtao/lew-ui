import{r as l}from"./rolldown-runtime-DYC1jRjs.js";import{$ as d,Di as a,Zr as p,ei as o,i as s,ti as u,ui as g,wi as m}from"./lew-ui-D4rxVhOO.js";import{da as c}from"./vendor-DE_9brhS.js";import{n as w,r as i,t as _}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as f}from"./DemoBadge1--B311id_.js";import{t as b}from"./DemoBadge2-DzIiahWT.js";import{t as v}from"./DemoBadge3-BlW_MmXU.js";import{t as x}from"./DemoBadge4-Cuiv-kkJ.js";import{t as B}from"./DemoBadge5-Dda90WAt.js";var D={title:"Props",columnsKey:"props",data:s(d)},r=l({props:()=>D},1),h=`<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge value="6" round color="red">
      <lew-avatar
        shape="circle"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_1_ctd06i_.jpeg"
      />
    </lew-badge>

    <lew-badge value="New" type="light" color="green">
      <lew-avatar
        size="50"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_2_2s0nai_.jpeg"
      />
    </lew-badge>

    <lew-badge round color="red" value="142232" :max="99">
      <lew-avatar
        size="60"
        src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_3_kntap6_.jpeg"
      />
    </lew-badge>
  </lew-flex>
</template>
`,y=`<script setup lang="ts">
import { Activity, Home, Search } from 'lucide-vue-next'
<\/script>

<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge round color="blue">
      <Activity :size="18" />
    </lew-badge>
    <lew-badge round>
      <Home :size="27" />
    </lew-badge>
    <lew-badge round color="green">
      <Search :size="36" />
    </lew-badge>
  </lew-flex>
</template>
`,L=`<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge value="5" />
    <lew-badge value="15" type="light" color="blue" />
    <lew-badge value="65" color="green" />
    <lew-badge value="9" color="warning" />
    <lew-badge value="99+" color="red" />
    <lew-badge round />
    <lew-badge round type="light" color="blue" />
    <lew-badge round color="green" />
    <lew-badge round color="warning" />
    <lew-badge round />
  </lew-flex>
</template>
`,j=`<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge round color="success" text="Success" />
    <lew-badge round color="warning" text="Warning" />
    <lew-badge round color="error" text="Error" />
    <lew-badge round color="info" text="Info" />
    <lew-badge round color="primary" text="Primary" />
  </lew-flex>
</template>
`,k=`<script setup lang="ts">
import { Home } from 'lucide-vue-next'
<\/script>

<template>
  <lew-flex wrap x="start" gap="30">
    <lew-badge round color="red" processing>
      <Home />
    </lew-badge>
    <lew-badge round color="blue" text="Processing" processing />
  </lew-flex>
</template>
`;const C=[f,b,v,x,B],$=[h,y,L,j,k];var z={class:"demo-wrapper"},P=u({__name:"DemoBadge",setup(A){const n=c().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),t=m(Object.keys(r).map(e=>r[e]));return(e,N)=>(g(),p("div",z,[o(i),o(w,{"demo-group":a(C),"code-group":a($),"component-name":a(n),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),o(_,{options:a(t)},null,8,["options"])]))}}),H=P,W=H;export{W as default};
