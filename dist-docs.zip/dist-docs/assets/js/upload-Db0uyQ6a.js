import{r as n}from"./rolldown-runtime-DYC1jRjs.js";import{Di as e,Zr as i,ei as l,i as r,nt as s,r as m,ti as d,tt as f,ui as u,wi as c}from"./lew-ui-D4rxVhOO.js";import{da as w}from"./vendor-DE_9brhS.js";import{n as _,r as L,t as x}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import"./http-I7MJl4KM.js";import"./uploadHelper-EFZpM1EZ.js";import{t as U}from"./DemoUpload1-CmPL8t7g.js";import{t as v}from"./DemoUpload2-Ck-d6H2a.js";import{t as D}from"./DemoUpload3-BX5MBanv.js";import{t as I}from"./DemoUpload4-60ONlELg.js";import{t as F}from"./DemoUpload5-QKyg9O-k.js";import{t as g}from"./DemoUpload6-C_0agmUr.js";import{t as y}from"./DemoUpload7-CSXA1Huk.js";import{t as h}from"./LewCodeBox-CqTXiE9w.js";var H={title:"Emits",columnsKey:"emits",orderNum:99,data:m(s)},k={title:"Props",columnsKey:"props",orderNum:10,data:r(f)},o=n({emits:()=>H,props:()=>k},1),$=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'
import uploadHelper from '../uploadHelper'

const fileList = ref<LewUploadFileItem[]>([])
<\/script>

<template>
  <lew-flex width="500px">
    <lew-upload v-model="fileList" :upload-helper="uploadHelper" />
  </lew-flex>
</template>
`,E=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'
import uploadHelper from '../uploadHelper'

const fileList = ref<LewUploadFileItem[]>([])
<\/script>

<template>
  <lew-flex width="500px">
    <lew-upload
      v-model="fileList"
      :max-file-size="1024 * 1024 * 2"
      :limit="3"
      :upload-helper="uploadHelper"
    />
  </lew-flex>
</template>
`,N=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'
import uploadHelper from '../uploadHelper'

const fileList = ref<LewUploadFileItem[]>([])
<\/script>

<template>
  <lew-flex width="500px">
    <lew-upload
      v-model="fileList"
      :upload-helper="uploadHelper"
      accept="image/*"
    />
  </lew-flex>
</template>
`,M=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'
import uploadHelper from '../uploadHelper'

const fileList = ref<LewUploadFileItem[]>([])
<\/script>

<template>
  <lew-flex width="500px">
    <lew-upload
      v-model="fileList"
      :upload-helper="uploadHelper"
      accept="image/*"
      :max-file-size="1024 * 500"
      tips="证件照格式：只能上传jpg/png文件，且不超过500kb"
    />
  </lew-flex>
</template>
`,b=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'
import uploadHelper from '../uploadHelper'

const fileList = ref<LewUploadFileItem[]>([])
<\/script>

<template>
  <lew-flex x="start">
    <lew-upload v-model="fileList" view-mode="card" :upload-helper :limit="3" />
  </lew-flex>
</template>
`,z=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'

const fileList = ref<LewUploadFileItem[]>([])
<\/script>

<template>
  <lew-flex width="500px" x="start">
    <lew-upload v-model="fileList" :limit="3" />
  </lew-flex>
</template>
`,B=`<script setup lang="ts">
import type { LewUploadFileItem } from 'lew-ui'

const fileList = ref<LewUploadFileItem[]>([
  {
    key: '50357524',
    size: 71808,
    name: 'Didi Travel Expense Report.pdf',
    lastModifiedDate: '2024-09-05T12:48:41.363Z',
    lastModified: 1725540521363,
  },
  {
    key: 'f7d20623',
    size: 74499,
    name: 'Didi Electronic Invoice.pdf',
    lastModifiedDate: '2024-09-05T12:48:35.593Z',
    lastModified: 1725540515593,
  },
])
<\/script>

<template>
  <lew-flex width="500px" x="start">
    <lew-upload v-model="fileList" :limit="3" />
  </lew-flex>
</template>
`;const C=[U,v,D,I,F,g,y],P=[$,E,N,M,b,z,B];var R=`import type { LewUploadFileItem } from 'lew-ui'
import axios from 'docs/axios/http'

export default ({
  fileItem,
  setFileItem,
}: {
  fileItem: LewUploadFileItem
  setFileItem: (item: LewUploadFileItem) => void
}) => {
  const { key, file } = fileItem
  const formData = new FormData()
  formData.append('file', file as File)
  setFileItem({ key, status: 'uploading' })
  axios
    .post({
      url: '/open/upload',
      data: formData,
      baseURL: '/api_sso',
      onUploadProgress: (e: any) => {
        setFileItem({ key, percent: e.progress * 100 })
      },
    })
    .then((res: any) => {
      if (res.success) {
        const { fileName } = res.data
        setFileItem({
          key,
          status: 'success',
          url: \`https://app.tngeek.com/api_sso/open/file/\${fileName}\`,
          percent: 100,
        })
      }
      else {
        LewMessage.error(res.message)
        setFileItem({ key, status: 'fail' })
      }
    })
}
`,T={class:"demo-wrapper"},Z=d({__name:"DemoUpload",setup(G){const p=w().name.replace("R-Lew","").replace(/^[A-Z]/,t=>t.toLowerCase()),a=c(Object.keys(o).map(t=>o[t]));return(t,K)=>(u(),i("div",T,[l(L),l(_,{"demo-group":e(C),"code-group":e(P),"component-name":e(p),columns:1,gap:"20px"},null,8,["demo-group","code-group","component-name"]),l(h,{title:"uploadHelper.ts",code:e(R)},null,8,["code"]),l(x,{options:e(a)},null,8,["options"])]))}}),j=Z,ae=j;export{ae as default};
