import{r as l}from"./rolldown-runtime-DYC1jRjs.js";import{Di as e,L as i,Zr as r,ei as t,i as c,r as p,ti as d,ui as u,wi as m,z as w}from"./lew-ui-D4rxVhOO.js";import{da as g}from"./vendor-DE_9brhS.js";import{n as f,r as h,t as _}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as b}from"./DemoDropdown1-BXstxID-.js";import{t as v}from"./DemoDropdown2-BUP5lXVH.js";import{t as y}from"./DemoDropdown3-DVW3oYp5.js";var L={title:"Emits",columnsKey:"emits",orderNum:99,data:p(w)},k={title:"Props",columnsKey:"props",orderNum:1,data:c(i)},o=l({emits:()=>L,props:()=>k},1),x=`<script setup lang="ts">
import type { LewContextMenusOption } from 'lew-ui'

const options = ref<LewContextMenusOption[]>([
  {
    label: 'Edit Profile',
    onClick: () => {
      LewMessage.info('Edit Profile')
    },
  },
  {
    label: 'Account Settings',
    onClick: () => {
      LewMessage.info('Account Settings')
    },
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Notifications',
    onClick: () => {
      LewMessage.info('Notifications')
    },
  },
  {
    label: 'Sign Out',
    onClick: () => {
      LewMessage.info('Sign Out')
    },
  },
])
<\/script>

<template>
  <lew-flex gap="30" x="start">
    <lew-dropdown :options="options">
      <lew-button text="Hover" type="fill" />
    </lew-dropdown>
    <lew-dropdown :options="options" trigger="click">
      <lew-button text="Click" type="ghost" />
    </lew-dropdown>
  </lew-flex>
</template>
`,D=`<script setup lang="ts">
import {
  Bell,
  Lock,
  LogOut,
  MessageCircle,
  Monitor,
  Moon,
  Settings,
  Sun,
  User,
} from 'lucide-vue-next'

const options = ref<any[]>([
  {
    label: 'Profile',
    icon: h(User, { size: 14 }),
  },
  {
    label: 'Settings',
    icon: h(Settings, { size: 14 }),
    children: [
      {
        label: 'Change Password',
        icon: h(Lock, { size: 14 }),
      },
      {
        label: 'Privacy Settings',
        icon: h(Lock, { size: 14 }),
      },
      {
        label: 'Notification Settings',
        icon: h(Bell, { size: 14 }),
      },
    ],
  },
  {
    label: 'Messages',
    icon: h(MessageCircle, { size: 14 }),
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Theme',
    icon: h(Moon, { size: 14 }),
    children: [
      {
        label: 'Light Mode',
        checkable: true,
        checked: true,
        icon: h(Sun, { size: 14 }),
        onClick: () => {
          setTheme('Light Mode')
        },
      },
      {
        label: 'Dark Mode',
        checkable: true,
        checked: false,
        icon: h(Moon, { size: 14 }),
        onClick: () => {
          setTheme('Dark Mode')
        },
      },
      {
        label: 'System',
        checkable: true,
        checked: false,
        icon: h(Monitor, { size: 14 }),
        onClick: () => {
          setTheme('System')
        },
      },
    ],
  },
  {
    isDividerLine: true,
  },
  {
    label: 'Sign Out',
    icon: h(LogOut, { size: 14 }),
  },
])

function setTheme(label: string, _options: any[] = options.value) {
  // 找到 Theme 选项
  const themeItem = _options.find(item => item.label === 'Theme')
  if (themeItem?.children) {
    // 直接遍历并设置 checked 状态，参考 DemoContextMenu4.vue 的简洁写法
    themeItem.children.forEach((child: any) => {
      if (child.checkable) {
        child.checked = child.label === label
      }
    })
  }
}
<\/script>

<template>
  <lew-flex gap="30" x="start">
    <lew-dropdown :options="options" placement="bottom-start">
      <lew-avatar
        src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_4_7cwenb_.jpeg"
        status="online"
        shape="circle"
        status-placement="top-left"
      />
    </lew-dropdown>
  </lew-flex>
</template>
`,C=`<script setup lang="ts">
import type { LewContextMenusOption } from 'lew-ui'
import { LewBadge } from 'lew-ui'

const status = ref('success')

const productOptions = ref([
  {
    label: 'Mac',
    value: 'mac',
  },
  {
    label: 'iPad',
    value: 'ipad',
  },
  {
    label: 'iPhone',
    value: 'iphone',
  },
  {
    label: 'Watch',
    value: 'watch',
    disabled: true,
  },
  {
    label: 'AirPods',
    value: 'airpods',
  },
  {
    label: 'TV & Home',
    value: 'tv',
  },
])

const statusOptions = ref([
  {
    label: 'Success',
    value: 'success',
    onClick: (_: any, __: any, instance: any) => {
      setStatus(_, instance)
    },
    icon: h(LewBadge, {
      color: 'green',
      style: {
        margin: '0 5px',
      },
    }),
  },
  {
    label: 'Failed',
    value: 'failed',
    onClick: (_: any, __: any, instance: any) => {
      setStatus(_, instance)
    },
    icon: h(LewBadge, {
      color: 'red',
      style: {
        margin: '0 5px',
      },
    }),
  },
  {
    label: 'Pending',
    value: 'pending',
    onClick: (_: any, __: any, instance: any) => {
      setStatus(_, instance)
    },
    icon: h(LewBadge, {
      color: 'yellow',
      style: {
        margin: '0 5px',
      },
    }),
  },
  {
    label: 'Processing',
    value: 'processing',
    onClick: (_: any, __: any, instance: any) => {
      setStatus(_, instance)
    },
    icon: h(LewBadge, {
      color: 'blue',
      processing: true,
      style: {
        margin: '0 5px',
      },
    }),
  },
])

function setStatus(item: any, instance: any) {
  instance?.hide()
  status.value = item.value
}

const colorMap: Record<string, string> = {
  success: 'green',
  failed: 'red',
  pending: 'yellow',
  processing: 'blue',
}

function handleChange(e: LewContextMenusOption) {
  console.log(e)
}

function getStatusLabel(value: string) {
  return statusOptions.value.find(item => item.value === value)?.label
}
<\/script>

<template>
  <lew-flex gap="50" x="start">
    <lew-dropdown :options="statusOptions" trigger="click" @change="handleChange">
      <lew-tag style="cursor: pointer" oversize :color="colorMap[status]">
        {{ getStatusLabel(status) }}
      </lew-tag>
    </lew-dropdown>

    <lew-dropdown placement="bottom-start" :options="productOptions">
      <div>More Products</div>
    </lew-dropdown>
  </lew-flex>
</template>
`;const M=[b,v,y],S=[x,D,C];var O={class:"demo-wrapper"},P=d({__name:"DemoDropdown",setup(B){const a=g().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),s=m(Object.keys(o).map(n=>o[n]));return(n,T)=>(u(),r("div",O,[t(h),t(f,{"demo-group":e(M),"code-group":e(S),"component-name":e(a),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(_,{options:e(s)},null,8,["options"])]))}}),z=P,H=z;export{H as default};
