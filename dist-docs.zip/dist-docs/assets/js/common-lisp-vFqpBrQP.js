import{mi as o}from"./vendor-DE_9brhS.js";export{o as default};
