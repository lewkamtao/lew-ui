import{ni as t}from"./vendor-DE_9brhS.js";export{t as default};
