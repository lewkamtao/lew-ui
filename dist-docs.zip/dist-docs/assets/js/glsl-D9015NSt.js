import{di as l}from"./vendor-DE_9brhS.js";export{l as default};
