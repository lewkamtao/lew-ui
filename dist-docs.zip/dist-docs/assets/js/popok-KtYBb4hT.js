import{r as a}from"./rolldown-runtime-DYC1jRjs.js";import{Di as n,Zr as s,_n as p,ei as t,gn as i,i as c,r as m,ti as u,ui as f,wi as d}from"./lew-ui-D4rxVhOO.js";import{da as g}from"./vendor-DE_9brhS.js";import{n as w,r as k,t as x}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as y}from"./DemoPopok1-CufWVDM-.js";import{t as v}from"./DemoPopok2-DMcMscvH.js";import{t as _}from"./DemoPopok3-DGhinZXj.js";import{t as h}from"./DemoPopok4-DDnaIySd.js";import{t as C}from"./DemoPopok5-CodSRAUD.js";import{t as D}from"./DemoPopok6-73jQ5AGS.js";var b={title:"Emits",columnsKey:"emits",orderNum:99,data:m(p)},P={title:"Props",columnsKey:"props",orderNum:10,data:c(i)},o=a({emits:()=>b,props:()=>P},1),L=`<script setup lang="ts">
function onCancel() {
  LewMessage.info('Cancelled')
}
function onOk() {
  LewMessage.success('Confirmed')
}
<\/script>

<template>
  <lew-popok
    width="400px"
    title="Delete Project"
    content="This action cannot be undone. Are you sure you want to delete this project?"
    placement="bottom-start"
    :footer-buttons="[
      { props: { type: 'text', color: 'gray', size: 'small', text: 'Cancel', request: onCancel } },
      { props: { type: 'fill', color: 'red', size: 'small', text: 'Delete' } },
    ]"
    @ok="onOk"
  >
    <lew-button text="Delete Project" type="ghost" color="red" />
  </lew-popok>
</template>
`,z=`<script setup lang="ts">
function onCancel() {
  LewMessage.info('Cancelled')
}
function onOk() {
  LewMessage.success('Confirmed')
}
<\/script>

<template>
  <lew-popok
    width="400px"
    title="Delete Confirmation"
    type="error"
    content="This action cannot be undone. Please confirm!"
    placement="bottom-start"
    :footer-buttons="[
      { props: { type: 'text', color: 'gray', size: 'small', text: 'Cancel', request: onCancel } },
      { props: { type: 'fill', color: 'red', size: 'small', text: 'Delete' } },
    ]"
    trigger="hover"
    @ok="onOk"
  >
    <lew-button text="Hover to trigger" type="text" color="red" />
  </lew-popok>
</template>
`,M=`<script setup lang="ts">
function onCancel() {
  LewMessage.info('Cancelled')
}
function onOk() {
  LewMessage.success('Confirmed')
}
<\/script>

<template>
  <lew-popok
    width="400px"
    title="Delete Confirmation"
    type="error"
    content="This action cannot be undone. Please confirm!"
    :hide-icon="true"
    placement="bottom-start"
    :footer-buttons="[
      { props: { type: 'text', color: 'gray', size: 'small', text: 'Cancel', request: onCancel } },
      { props: { type: 'fill', color: 'red', size: 'small', text: 'Delete' } },
    ]"
    trigger="hover"
    @ok="onOk"
  >
    <lew-button text="Hover to trigger" type="text" color="red" />
  </lew-popok>
</template>
`,O=`<script setup lang="ts">
import { Trash } from 'lucide-vue-next'
import { h } from 'vue'

function onCancel() {
  LewMessage.info('Cancelled')
}
function onOk() {
  LewMessage.success('Confirmed')
}
<\/script>

<template>
  <lew-popok
    :icon="h(Trash, { size: 24, color: 'red' })"
    width="400px"
    title="Delete Confirmation"
    type="error"
    content="This action cannot be undone. Please confirm!"
    placement="bottom-start"
    :footer-buttons="[
      { props: { type: 'text', color: 'gray', size: 'small', text: 'Cancel', request: onCancel } },
      { props: { type: 'fill', color: 'red', size: 'small', text: 'Delete' } },
    ]"
    trigger="hover"
    @ok="onOk"
  >
    <lew-button text="Hover to trigger" type="text" color="red" />
  </lew-popok>
</template>
`,T=`<script setup lang="ts">
import { LewButton } from 'lew-ui'
import { h } from 'vue'

function onCancel() {
  LewMessage.info('Cancelled')
}
function onOk() {
  LewMessage.success('Confirmed')
}

const content = h(
  'div',
  {
    style: {
      color: '#1d1d1f',
      padding: '12px 0',
      fontSize: '15px',
      lineHeight: '1.6',
    },
  },
  [
    h(
      'ul',
      { style: { margin: '0 0 8px 0', paddingLeft: '20px', color: '#6e6e73' } },
      [
        h('li', null, 'All data will be permanently removed.'),
        h('li', null, 'This action affects all related information.'),
        h('li', null, ['Please make sure you have a backup.']),
      ],
    ),
    h(
      'div',
      { style: { color: '#d93026', fontWeight: 500, marginTop: '8px' } },
      'This action is irreversible.',
    ),
  ],
)
<\/script>

<template>
  <lew-popok
    width="400px"
    title="Delete Confirmation"
    type="error"
    :content="content"
    placement="bottom-start"
    :footer-buttons="[
      { props: { type: 'text', color: 'gray', size: 'small', text: 'Cancel', request: onCancel } },
      { props: { type: 'fill', color: 'red', size: 'small', text: 'Delete' } },
    ]"
    trigger="hover"
    @ok="onOk"
  >
    <LewButton text="Hover to trigger" type="text" color="red" />
  </lew-popok>
</template>
`,q=`<script setup lang="ts">
async function onLater() {}

async function onSave() {
  await new Promise(r => setTimeout(r, 300))
  LewMessage.success({ content: 'Saved' })
}
<\/script>

<template>
  <lew-flex x="start">
    <lew-popok
      type="warning"
      title="Save changes?"
      content="footerButtons controls multiple actions with different LewButton props (e.g. request)."
      trigger="click"
      placement="top"
      :footer-buttons="[
        {
          props: { text: 'Later', type: 'text', color: 'gray', request: onLater },
        },
        {
          props: { text: 'Save', type: 'fill', color: 'primary', request: onSave },
        },
      ]"
    >
      <lew-button type="light">
        Edit with custom footer
      </lew-button>
    </lew-popok>
  </lew-flex>
</template>
`;const B=[y,v,_,h,C,D],S=[L,z,M,O,T,q];var $={class:"demo-wrapper"},E=u({__name:"DemoPopok",setup(j){const r=g().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),l=d(Object.keys(o).map(e=>o[e]));return(e,N)=>(f(),s("div",$,[t(k),t(w,{"demo-group":n(B),"code-group":n(S),"component-name":n(r),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(x,{options:n(l)},null,8,["options"])]))}}),H=E,U=H;export{U as default};
