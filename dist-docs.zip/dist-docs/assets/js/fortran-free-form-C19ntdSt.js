import{Mr as f}from"./vendor-DE_9brhS.js";export{f as default};
