import{r as o}from"./rolldown-runtime-DYC1jRjs.js";import{Bn as s,Di as e,Kt as i,Zr as u,ei as a,i as p,r as d,ti as m,ui as c,wi as b}from"./lew-ui-D4rxVhOO.js";import{da as f}from"./vendor-DE_9brhS.js";import{n as h,r as v,t as g}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import"./http-I7MJl4KM.js";import"./uploadHelper-EFZpM1EZ.js";import{t as y}from"./DemoForm1-Cjh4gZxl.js";import{t as w}from"./DemoForm2-D0sBidQ4.js";import{t as x}from"./DemoForm3-DLWypK18.js";import{t as _}from"./DemoForm4-CsrRFmPJ.js";import{t as k}from"./DemoForm5-D0qvLwxM.js";import{t as P}from"./DemoForm6-CVV-KtXn.js";var q={title:"Emits",columnsKey:"emits",orderNum:99,data:d(i)},M={title:"Methods",columnsKey:"methods",orderNum:999,data:[{name:"getForm",description:"获取表单值",type:"() => {}"},{name:"setForm",description:"设置表单值",type:"() => {}"}]},Y={title:"Props",columnsKey:"props",orderNum:10,data:p(s)},l=o({emits:()=>q,methods:()=>M,props:()=>Y},1),S=`<script setup lang="ts">
import uploadHelper from 'docs/docs/upload/uploadHelper'
import * as Yup from 'yup'

const form = ref({} as any)
const formRef = ref()

function submit() {
  LewMessage.request({ loadingMessage: 'Processing...' }, () => {
    return new Promise<any>((resolve, reject) => {
      formRef.value
        .validate()
        .then((vail: boolean) => {
          if (vail) {
            form.value = formRef.value.getForm()
            resolve({
              content: 'Account created successfully!',
              duration: 1000,
              type: 'success',
            })
          }
          else {
            resolve({
              content: 'Please complete all required fields',
              duration: 1000,
              type: 'warning',
            })
          }
        })
        .catch((err: any) => {
          reject(err)
        })
    })
  })
}

const options = ref([
  {
    label: 'Account Type',
    as: 'tabs',
    field: 'accountType',
    props: {
      itemWidth: 'auto',
      width: '100%',
      options: [
        {
          label: 'Personal',
          value: 'personal',
        },
        {
          label: 'Business',
          value: 'business',
        },
        {
          label: 'Enterprise',
          value: 'enterprise',
        },
      ],
    },
  },
  {
    field: 'profilePhoto',
    label: 'Profile Photo',
    as: 'upload',
    rule: Yup.array()
      .of(
        Yup.object({
          status: Yup.string().oneOf(['success'], 'Please wait for upload to complete'),
        }),
      )
      .max(1, 'Maximum 1 photo allowed')
      .required('Profile photo is required'),
    props: {
      uploadHelperId: 'uploadHelper',
      multiple: false,
      viewMode: 'card',
      limit: 1,
      accept: 'image/jpeg,image/png',
      tips: 'Upload a clear photo (JPG/PNG, max 2MB)',
    },
  },
  {
    field: 'firstName',
    label: 'First Name',
    as: 'input',
    rule: Yup.string()
      .min(2, 'Minimum 2 characters')
      .max(30, 'Maximum 30 characters')
      .required('First name is required'),
    props: {
      showCount: true,
      maxLength: 30,
      placeholder: 'Enter your first name',
    },
  },
  {
    field: 'lastName',
    label: 'Last Name',
    as: 'input',
    rule: Yup.string()
      .min(2, 'Minimum 2 characters')
      .max(30, 'Maximum 30 characters')
      .required('Last name is required'),
    props: {
      showCount: true,
      maxLength: 30,
      placeholder: 'Enter your last name',
    },
  },
  {
    field: 'email',
    label: 'Email Address',
    as: 'input',
    rule: Yup.string().email('Please enter a valid email').required('Email is required'),
    props: {
      placeholder: 'Enter your email address',
      clearable: true,
    },
  },
  {
    field: 'phone',
    label: 'Phone Number',
    as: 'input',
    rule: Yup.string()
      .matches(/^\\+?[\\d\\s\\-()]+$/, 'Please enter a valid phone number')
      .required('Phone number is required'),
    props: {
      placeholder: '+1 (555) 123-4567',
      clearable: true,
    },
  },
  {
    field: 'dateOfBirth',
    label: 'Date of Birth',
    as: 'date-picker',
    rule: Yup.string().required('Date of birth is required'),
    props: {
      clearable: true,
      placeholder: 'Select your date of birth',
    },
  },
  {
    field: 'country',
    label: 'Country',
    as: 'select',
    rule: Yup.string().required('Country is required'),
    props: {
      clearable: true,
      placeholder: 'Select your country',
      options: [
        { label: 'United States', value: 'US' },
        { label: 'Canada', value: 'CA' },
        { label: 'United Kingdom', value: 'UK' },
        { label: 'Germany', value: 'DE' },
        { label: 'France', value: 'FR' },
        { label: 'Japan', value: 'JP' },
        { label: 'Australia', value: 'AU' },
        { label: 'China', value: 'CN' },
        { label: 'India', value: 'IN' },
        { label: 'Brazil', value: 'BR' },
      ],
    },
  },
  {
    field: 'city',
    label: 'City',
    as: 'input',
    rule: Yup.string().required('City is required'),
    props: {
      placeholder: 'Enter your city',
      clearable: true,
    },
  },
  {
    field: 'zipCode',
    label: 'ZIP/Postal Code',
    as: 'input',
    rule: Yup.string().required('ZIP/Postal code is required'),
    props: {
      placeholder: 'Enter ZIP/postal code',
      clearable: true,
    },
  },
  {
    field: 'username',
    label: 'Username',
    as: 'input',
    rule: Yup.string()
      .min(4, 'Minimum 4 characters')
      .max(20, 'Maximum 20 characters')
      .matches(/^\\w+$/, 'Only letters, numbers, and underscores allowed')
      .required('Username is required'),
    props: {
      showCount: true,
      maxLength: 20,
      placeholder: 'Choose a unique username',
    },
  },
  {
    field: 'password',
    label: 'Password',
    as: 'input',
    rule: Yup.string().required('Password is required'),
    props: {
      type: 'password',
      placeholder: 'Create a strong password',
      showCount: true,
      maxLength: 50,
    },
  },
  {
    field: 'confirmPassword',
    label: 'Confirm Password',
    as: 'input',
    rule: Yup.string()
      .oneOf([Yup.ref('password')], 'Passwords must match')
      .required('Please confirm your password'),

    props: {
      type: 'password',
      placeholder: 'Confirm your password',
    },
  },
  {
    field: 'interests',
    label: 'Interests & Hobbies',
    as: 'select',
    rule: Yup.array()
      .min(1, 'Select at least one interest')
      .max(5, 'Maximum 5 interests allowed')
      .required('Please select your interests'),
    props: {
      clearable: true,
      multiple: true,
      placeholder: 'Select your interests',
      options: [
        { label: 'Technology', value: 'tech' },
        { label: 'Sports', value: 'sports' },
        { label: 'Music', value: 'music' },
        { label: 'Travel', value: 'travel' },
        { label: 'Cooking', value: 'cooking' },
        { label: 'Reading', value: 'reading' },
        { label: 'Gaming', value: 'gaming' },
        { label: 'Photography', value: 'photography' },
        { label: 'Art', value: 'art' },
        { label: 'Fitness', value: 'fitness' },
      ],
    },
  },
  {
    field: 'gender',
    label: 'Gender',
    as: 'radio-group',
    rule: Yup.string().required('Please select your gender'),
    props: {
      options: [
        { label: 'Male', value: 'male' },
        { label: 'Female', value: 'female' },
        { label: 'Non-binary', value: 'non-binary' },
        { label: 'Prefer not to say', value: 'prefer-not-to-say' },
      ],
    },
  },
  {
    field: 'newsletter',
    label: 'Newsletter Subscription',
    as: 'checkbox',
    rule: Yup.boolean(),
    props: {
      label: 'Subscribe to our newsletter for updates and offers',
    },
  },
  {
    field: 'marketing',
    label: 'Marketing Communications',
    as: 'checkbox',
    rule: Yup.boolean(),
    props: {
      label: 'Receive marketing communications from our partners',
    },
  },
  {
    field: 'terms',
    label: '',
    as: 'checkbox',
    rule: Yup.boolean()
      .oneOf([true], 'You must agree to the terms')
      .required('You must agree to the terms'),
    props: {
      label: 'I agree to the Terms of Service and Privacy Policy',
    },
  },
  {
    as: 'button',
    props: {
      text: 'Create Account',
      request: submit,
    },
  },
])

function setForm() {
  // Set form
  formRef.value.setForm({
    accountType: 'personal',
  })
}

function resetForm() {
  // Reset form
  formRef.value.setForm({ accountType: 'personal' })
}

function change() {
  // Get form
  form.value = formRef.value.getForm()
}

onMounted(() => {
  setForm()
})
<\/script>

<template>
  <lew-flex x="start" y="start" gap="50px">
    <lew-form
      ref="formRef"
      :form-methods="{
        uploadHelper,
      }"
      class="form-box"
      :options="options"
      width="550px"
      @mounted="setForm"
      @change="change"
    />
    <lew-flex direction="y" x="start">
      <lew-flex x="start">
        <lew-button type="light" round @click="submit">
          Submit
        </lew-button>
        <lew-button type="light" round @click="setForm">
          Set Form
        </lew-button>
        <lew-button type="light" round @click="resetForm">
          Reset
        </lew-button>
      </lew-flex>
      <pre>{{ form }}</pre>
    </lew-flex>
  </lew-flex>
</template>

<style scoped lang="scss">
.form-box {
  width: 450px;
  flex-shrink: 0;
}

pre {
  width: 350px;
  background-color: var(--lew-bgcolor-2);
  padding: 30px;
  flex-shrink: 0;
}

@media (max-width: 767px) {
  .form-box {
    width: 100%;
  }
}
</style>
`,F=`<script setup lang="ts">
import * as Yup from 'yup'

const form = ref({} as any)
const formRef = ref()

function submit() {
  formRef.value.validate().then((res: any) => {
    console.log(res)
    LewMessage.success('Form submitted successfully!')
  })
}

onMounted(() => {
  // Set form
  formRef.value.setForm({})
})

const options = ref([
  {
    field: 'title',
    label: 'Title',
    as: 'input',
    rule: Yup.string()
      .min(3, 'Minimum 3 characters')
      .max(100, 'Maximum 100 characters')
      .required('Title is required'),
    props: {
      clearable: true,
      placeholder: 'Enter title',
    },
  },
  {
    field: 'description',
    label: 'Description',
    as: 'textarea',
    rule: Yup.string()
      .min(10, 'Minimum 10 characters')
      .max(500, 'Maximum 500 characters')
      .required('Description is required'),
    props: {
      clearable: true,
      placeholder: 'Enter description',
      rows: 4,
    },
  },
  {
    field: 'priority',
    label: 'Priority',
    as: 'radio-group',
    rule: Yup.string().required('Please select priority'),
    props: {
      options: [
        { label: 'Low', value: 'low' },
        { label: 'Medium', value: 'medium' },
        { label: 'High', value: 'high' },
      ],
    },
  },
  {
    field: 'tags',
    label: 'Tags',
    as: 'select',
    rule: Yup.array().min(1, 'Select at least one tag').required('Please select tags'),
    props: {
      clearable: true,
      multiple: true,
      placeholder: 'Select tags',
      options: [
        { label: 'Important', value: 'important' },
        { label: 'Urgent', value: 'urgent' },
        { label: 'Review', value: 'review' },
        { label: 'Follow-up', value: 'follow-up' },
        { label: 'Completed', value: 'completed' },
      ],
    },
  },
  {
    field: 'dueDate',
    label: 'Due Date',
    as: 'date-picker',
    rule: Yup.string().required('Due date is required'),
    props: {
      clearable: true,
      placeholder: 'Select due date',
    },
  },
  {
    field: 'notifications',
    label: 'Notifications',
    as: 'checkbox-group',
    rule: Yup.array()
      .min(1, 'Select at least one notification')
      .required('Please select notifications'),
    props: {
      options: [
        { label: 'Email', value: 'email' },
        { label: 'SMS', value: 'sms' },
        { label: 'Push', value: 'push' },
        { label: 'In-app', value: 'in-app' },
      ],
    },
  },
  {
    as: 'button',
    props: {
      text: 'Submit',
      request: submit,
    },
  },
])
<\/script>

<template>
  <lew-flex width="500px" x="start" y="start" gap="50px">
    <lew-form
      ref="formRef"
      direction="y"
      class="form-box"
      :options="options"
      @change="
        (e: any) => {
          form = e
        }
      "
    />
    <pre>{{ form }}</pre>
  </lew-flex>
</template>

<style scoped lang="scss">
.form-box {
  width: 400px;
}

pre {
  width: 350px;
  background-color: var(--lew-bgcolor-2);
  padding: 30px;
  flex-shrink: 0;
}

@media (max-width: 767px) {
  .form-box {
    width: 100%;
  }
}
</style>
`,C=`<script setup lang="ts">
import * as Yup from 'yup'

const form = ref({} as any)
const formRef = ref()

function submit() {
  formRef.value.validate().then((res: any) => {
    console.log(res)
    LewMessage.success('Form submitted successfully!')
  })
}

onMounted(() => {
  // Set form
  formRef.value.setForm({})
})

const options = ref([
  {
    field: 'username',
    label: 'Username',
    as: 'input',
    rule: Yup.string()
      .min(3, 'Minimum 3 characters')
      .max(20, 'Maximum 20 characters')
      .required('Username is required'),
    props: {
      clearable: true,
      placeholder: 'Enter username',
    },
  },
  {
    field: 'password',
    label: 'Password',
    as: 'input',
    rule: Yup.string().min(6, 'Minimum 6 characters').required('Password is required'),
    props: {
      type: 'password',
      placeholder: 'Enter password',
    },
  },
  {
    field: 'confirmPassword',
    label: 'Confirm',
    as: 'input',
    rule: Yup.string()
      .oneOf([Yup.ref('password')], 'Passwords must match')
      .required('Please confirm your password'),
    props: {
      type: 'password',
      placeholder: 'Confirm password',
    },
  },
  {
    field: 'email',
    label: 'Email',
    as: 'input',
    rule: Yup.string().email('Please enter a valid email').required('Email is required'),
    props: {
      clearable: true,
      placeholder: 'Enter email address',
    },
  },
  {
    field: 'phone',
    label: 'Phone',
    as: 'input',
    rule: Yup.string()
      .matches(/^\\+?[\\d\\s\\-()]+$/, 'Please enter a valid phone number')
      .required('Phone number is required'),
    props: {
      clearable: true,
      placeholder: '+1 (555) 123-4567',
    },
  },
  {
    field: 'role',
    label: 'Role',
    as: 'select',
    rule: Yup.string().required('Please select a role'),
    props: {
      clearable: true,
      placeholder: 'Select user role',
      options: [
        { label: 'Admin', value: 'admin' },
        { label: 'User', value: 'user' },
        { label: 'Moderator', value: 'moderator' },
        { label: 'Guest', value: 'guest' },
      ],
    },
  },
  {
    field: 'status',
    label: 'Status',
    as: 'radio-group',
    rule: Yup.string().required('Please select account status'),
    props: {
      options: [
        { label: 'Active', value: 'active' },
        { label: 'Inactive', value: 'inactive' },
        { label: 'Suspended', value: 'suspended' },
      ],
    },
  },
  {
    field: 'permissions',
    label: 'Permissions',
    as: 'select',
    rule: Yup.array()
      .min(1, 'Select at least one permission')
      .required('Please select permissions'),
    props: {
      clearable: true,
      multiple: true,
      placeholder: 'Select permissions',
      options: [
        { label: 'Read', value: 'read' },
        { label: 'Write', value: 'write' },
        { label: 'Delete', value: 'delete' },
        { label: 'Admin', value: 'admin' },
        { label: 'User Management', value: 'user_management' },
      ],
    },
  },
  {
    field: 'notifications',
    label: 'Notifications',
    as: 'checkbox-group',
    rule: Yup.array()
      .min(1, 'Select at least one notification')
      .required('Please select notifications'),
    props: {
      options: [
        { label: 'Email', value: 'email' },
        { label: 'SMS', value: 'sms' },
        { label: 'Push', value: 'push' },
        { label: 'In-app', value: 'in_app' },
      ],
    },
  },
  {
    field: 'terms',
    label: '',
    as: 'checkbox',
    rule: Yup.boolean()
      .oneOf([true], 'You must agree to the terms')
      .required('You must agree to the terms'),
    props: {
      label: 'I agree to the Terms of Service and Privacy Policy',
    },
  },
  {
    as: 'button',
    props: {
      text: 'Create User',
      request: submit,
    },
  },
])
<\/script>

<template>
  <lew-flex width="500px" x="start" y="start" gap="50px">
    <lew-form
      ref="formRef"
      class="form-box"
      :options="options"
      @change="
        (e: any) => {
          form = e
        }
      "
    />
    <pre>{{ form }}</pre>
  </lew-flex>
</template>

<style scoped lang="scss">
.form-box {
  width: 450px;
}

pre {
  width: 350px;
  background-color: var(--lew-bgcolor-2);
  padding: 30px;
  flex-shrink: 0;
}

@media (max-width: 767px) {
  .form-box {
    width: 100%;
  }
}
</style>
`,R=`<script setup lang="ts">
import { schools } from 'docs/lib/data'
import * as Yup from 'yup'

const schoolsOptions = schools.map((e, i) => {
  return { label: e, value: i + 1 }
})

const form = ref({} as any)
const formRef = ref()

onMounted(() => {
  // 设置表单
  formRef.value.setForm({
    size: 'medium',
    input: '文本框',
    textarea: '多行文本',
    select: '1',
    select_multiple: [1, 2],
    radio_group: '2',
    checkbox_group: ['2'],
    tabs: '2',
    user: {
      address: 30,
      addd: true,
    },
    info: {
      asd: {
        dsd: {
          input_tag: ['测试', '小芳'],
        },
      },
    },
  })
})
const options = ref([
  {
    field: 'input',
    label: '文本框',
    as: 'input',
    rule: Yup.string().required('不能为空'),
    gridArea: 'auto / 1 / auto / 2',
    props: {
      showCount: true,
      maxLength: 30,
    },
  },

  {
    field: 'select',
    label: '单选选择器',
    as: 'select',
    rule: Yup.string().required('此项必填'),
    gridArea: 'auto / 2 / auto / 3',
    props: {
      clearable: true,
      options: [
        {
          label: '广东',
          value: '1',
        },
        {
          label: '深圳',
          value: '2',
        },
        {
          label: '杭州',
          value: '3',
        },
        {
          label: '上海',
          value: '4',
        },
        {
          label: '北京',
          value: '5',
        },
      ],
    },
  },
  {
    field: 'textarea',
    label: '多行文本框',
    as: 'textarea',
    rule: Yup.string().required('不能为空'),
    gridArea: 'auto / 1 / auto / 3',
    props: {
      clearable: true,
      showCount: true,
      maxLength: 300,
    },
  },
  {
    field: 'radio_group',
    label: '单选框',
    as: 'radio-group',
    gridArea: 'auto / 1 / auto / 2',
    rule: Yup.string().required('此项必填'),
    props: {
      options: [
        {
          label: '男',
          value: '1',
        },
        {
          label: '女',
          value: '2',
        },
        {
          label: '不公开',
          value: '3',
        },
      ],
    },
  },
  {
    field: 'select_multiple',
    label: '多选选择器',
    as: 'select',
    gridArea: 'auto / 2 / auto / 3',
    rule: Yup.array().min(2, '至少选择2个').required('此项必填'),
    props: {
      multiple: true,
      change: (e: any) => {
        console.log(e)
      },
      clearable: true,
      options: schoolsOptions,
    },
  },

  {
    field: 'checkbox_group',
    label: '多选框',
    as: 'checkbox-group',
    gridArea: 'auto / 1 / auto / 2',
    rule: Yup.array().min(1, '至少选择一个').required('此项必填'),
    props: {
      round: true,
      block: true,
      options: [
        {
          label: '唱歌',
          value: '1',
        },
        {
          label: '跳舞',
          value: '2',
        },
        {
          label: 'Rap',
          value: '3',
        },
        {
          label: '上海',
          value: '4',
        },
      ],
    },
  },
  {
    field: 'user.address',
    label: '地址',
    as: 'cascader',
    gridArea: 'auto / 1 / auto / 2',
    rule: Yup.string().required('地址必填'),
    props: {
      label: '是否同意',
      free: true,
      options: [
        {
          value: 1,
          label: 'Asia',
          children: [
            {
              value: 2,
              label: 'China',
              children: [
                { value: 3, label: 'Beijing' },
                { value: 4, label: 'Shanghai' },
                { value: 5, label: 'Hangzhou' },
              ],
            },
            {
              value: 6,
              label: 'Japan',
              children: [
                { value: 7, label: 'Tokyo' },
                { value: 8, label: 'Osaka' },
                { value: 9, label: 'Kyoto' },
              ],
            },
            {
              value: 10,
              label: 'Korea',
              children: [
                { value: 11, label: 'Seoul' },
                { value: 12, label: 'Busan' },
                { value: 13, label: 'Taegu' },
              ],
            },
          ],
        },
        {
          value: 14,
          label: 'Europe',
          children: [
            {
              value: 15,
              label: 'France',
              children: [
                { value: 16, label: 'Paris' },
                { value: 17, label: 'Marseille' },
                { value: 18, label: 'Lyon' },
              ],
            },
            {
              value: 19,
              label: 'UK',
              children: [
                { value: 20, label: 'London' },
                { value: 21, label: 'Birmingham' },
                { value: 22, label: 'Manchester' },
              ],
            },
          ],
        },
        {
          value: 23,
          label: 'North America',
          children: [
            {
              value: 24,
              label: 'US',
              children: [
                { value: 25, label: 'New York' },
                { value: 26, label: 'Los Angeles' },
                { value: 27, label: 'Washington' },
              ],
            },
            {
              value: 28,
              label: 'Canada',
              children: [
                { value: 29, label: 'Toronto' },
                { value: 30, label: 'Montreal' },
                { value: 31, label: 'Ottawa' },
              ],
            },
          ],
        },
      ],
    },
  },

  {
    field: 'info.asd.dsd.input_tag',
    label: '标签输入框',
    as: 'input-tag',
    gridArea: 'auto / 2 / auto / 3',
    rule: Yup.array().min(1, '至少选择一个').required('不能为空'),
  },
  {
    field: 'user.addd',
    label: '',
    as: 'checkbox',
    gridArea: 'auto / 1 / auto / 2',
    rule: Yup.boolean().oneOf([true], '请同意').required('请同意'),
    props: {
      label: '是否同意',
    },
  },
  {
    as: 'button',
    gridArea: 'auto / 1 / auto / 2',
    props: {
      text: '提交',
      click: () => submit(),
    },
  },
])

async function submit() {
  const vail = await formRef.value.validate()
  if (vail) {
    LewMessage.success('已提交')
  }
  else {
    LewMessage.warning('请完善表单')
  }
}
<\/script>

<template>
  <lew-flex x="start" y="start" gap="50px">
    <lew-form
      ref="formRef"
      :size="form.size"
      :options="options"
      direction="y"
      :columns="3"
      @change="
        (e: any) => {
          form = e
        }
      "
    />
  </lew-flex>
</template>
`,D=`<script setup lang="ts">
import options from './form_20240714_155154_quvi8vkan.json'

const bindOptions = options
<\/script>

<template>
  <lew-flex x="start" y="start" gap="50px">
    <lew-form v-bind="bindOptions" />
  </lew-flex>
</template>
`,A=`<script setup lang="ts">
import * as Yup from 'yup'

const options = ref([
  {
    field: 'category',
    label: 'Product Category',
    as: 'select',
    rule: Yup.string().required('Please select a category'),
    props: {
      clearable: true,
      initMethodId: 'categoryMethod',
    },
  },
  {
    field: 'tags',
    label: 'Product Tags',
    as: 'select',
    rule: Yup.array()
      .min(2, 'Please select at least 2 tags')
      .required('Please select tags'),
    props: {
      multiple: true,
      clearable: true,
      initMethodId: 'tagsMethod',
    },
  },
  {
    field: 'department',
    label: 'Department Structure',
    as: 'tree-select',
    rule: Yup.string().required('Please select a department'),
    props: {
      clearable: true,
      initMethodId: 'departmentMethod',
    },
  },
  {
    field: 'location',
    label: 'Warehouse Location',
    as: 'cascader',
    rule: Yup.string().required('Please select warehouse location'),
    props: {
      clearable: true,
      initMethodId: 'locationMethod',
      free: true,
    },
  },
])

const formMethods = {
  categoryMethod: () =>
    new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          { label: 'Electronics', value: 'electronics' },
          { label: 'Clothing', value: 'clothing' },
          { label: 'Home & Garden', value: 'home_garden' },
          { label: 'Sports & Outdoors', value: 'sports' },
          { label: 'Books & Media', value: 'books' },
          { label: 'Automotive', value: 'automotive' },
          { label: 'Health & Beauty', value: 'health_beauty' },
          { label: 'Toys & Games', value: 'toys_games' },
        ])
      }, 3000)
    }),

  tagsMethod: () =>
    new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          { label: 'New Arrival', value: 'new_arrival' },
          { label: 'Best Seller', value: 'best_seller' },
          { label: 'Limited Edition', value: 'limited_edition' },
          { label: 'On Sale', value: 'on_sale' },
          { label: 'Free Shipping', value: 'free_shipping' },
          { label: 'Premium Quality', value: 'premium_quality' },
          { label: 'Eco Friendly', value: 'eco_friendly' },
          { label: 'Customer Favorite', value: 'customer_favorite' },
        ])
      }, 3000)
    }),

  departmentMethod: () =>
    new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          {
            key: 'sales',
            label: 'Sales Department',
            children: [
              {
                key: 'sales_online',
                label: 'Online Sales',
                children: [
                  {
                    key: 'sales_online_retail',
                    label: 'Retail Sales',
                  },
                  {
                    key: 'sales_online_wholesale',
                    label: 'Wholesale Sales',
                  },
                ],
              },
              {
                key: 'sales_offline',
                label: 'Offline Sales',
                children: [
                  {
                    key: 'sales_offline_store',
                    label: 'Store Sales',
                  },
                  {
                    key: 'sales_offline_partner',
                    label: 'Partner Sales',
                  },
                ],
              },
            ],
          },
          {
            key: 'marketing',
            label: 'Marketing Department',
            children: [
              {
                key: 'marketing_digital',
                label: 'Digital Marketing',
                children: [
                  {
                    key: 'marketing_digital_social',
                    label: 'Social Media',
                  },
                  {
                    key: 'marketing_digital_seo',
                    label: 'SEO & SEM',
                  },
                ],
              },
              {
                key: 'marketing_traditional',
                label: 'Traditional Marketing',
                children: [
                  {
                    key: 'marketing_traditional_print',
                    label: 'Print Media',
                  },
                  {
                    key: 'marketing_traditional_tv',
                    label: 'TV & Radio',
                  },
                ],
              },
            ],
          },
          {
            key: 'operations',
            label: 'Operations Department',
            children: [
              {
                key: 'operations_logistics',
                label: 'Logistics',
                children: [
                  {
                    key: 'operations_logistics_warehouse',
                    label: 'Warehouse Management',
                  },
                  {
                    key: 'operations_logistics_shipping',
                    label: 'Shipping & Delivery',
                  },
                ],
              },
              {
                key: 'operations_customer',
                label: 'Customer Service',
                children: [
                  {
                    key: 'operations_customer_support',
                    label: 'Support Team',
                  },
                  {
                    key: 'operations_customer_returns',
                    label: 'Returns & Refunds',
                  },
                ],
              },
            ],
          },
        ])
      }, 3000)
    }),

  locationMethod: () =>
    new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          {
            label: 'North America',
            value: 'north_america',
            children: [
              {
                label: 'United States',
                value: 'us',
                children: [
                  { label: 'New York', value: 'ny' },
                  { label: 'Los Angeles', value: 'la' },
                  { label: 'Chicago', value: 'chicago' },
                  { label: 'Houston', value: 'houston' },
                ],
              },
              {
                label: 'Canada',
                value: 'canada',
                children: [
                  { label: 'Toronto', value: 'toronto' },
                  { label: 'Vancouver', value: 'vancouver' },
                  { label: 'Montreal', value: 'montreal' },
                ],
              },
            ],
          },
          {
            label: 'Europe',
            value: 'europe',
            children: [
              {
                label: 'United Kingdom',
                value: 'uk',
                children: [
                  { label: 'London', value: 'london' },
                  {
                    label: 'Manchester',
                    value: 'manchester',
                  },
                  {
                    label: 'Birmingham',
                    value: 'birmingham',
                  },
                ],
              },
              {
                label: 'Germany',
                value: 'germany',
                children: [
                  { label: 'Berlin', value: 'berlin' },
                  { label: 'Munich', value: 'munich' },
                  { label: 'Hamburg', value: 'hamburg' },
                ],
              },
            ],
          },
          {
            label: 'Asia Pacific',
            value: 'asia_pacific',
            children: [
              {
                label: 'China',
                value: 'china',
                children: [
                  { label: 'Shanghai', value: 'shanghai' },
                  { label: 'Beijing', value: 'beijing' },
                  { label: 'Shenzhen', value: 'shenzhen' },
                ],
              },
              {
                label: 'Japan',
                value: 'japan',
                children: [
                  { label: 'Tokyo', value: 'tokyo' },
                  { label: 'Osaka', value: 'osaka' },
                  { label: 'Yokohama', value: 'yokohama' },
                ],
              },
            ],
          },
        ])
      }, 3000)
    }),
}

const updateKey = ref(0)

function loadAgain() {
  updateKey.value++
}
<\/script>

<template>
  <lew-form
    :key="updateKey"
    :form-methods="formMethods"
    direction="y"
    :options="options"
    width="320px"
  />
  <lew-button style="margin-top: 20px" @click="loadAgain">
    Load again
  </lew-button>
</template>
`;const E=[y,w,x,_,k,P],L=[S,F,C,R,D,A];var T={class:"demo-wrapper"},N=m({__name:"DemoForm",setup(B){const r=f().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),t=b(Object.keys(l).map(n=>l[n]));return(n,I)=>(c(),u("div",T,[a(v),a(h,{"demo-group":e(E),"code-group":e(L),"component-name":e(r),columns:1,gap:"20px"},null,8,["demo-group","code-group","component-name"]),a(g,{options:e(t)},null,8,["options"])]))}}),O=N,nn=O;export{nn as default};
