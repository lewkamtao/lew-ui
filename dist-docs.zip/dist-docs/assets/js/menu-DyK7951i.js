import{r as l}from"./rolldown-runtime-DYC1jRjs.js";import{Di as n,F as i,I as u,P as m,Zr as p,ei as o,i as a,r as c,ti as d,ui as h,wi as g}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as f,r as _,t as b}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as y}from"./DemoMenu1-_fSBVDuN.js";var M={title:"Emits",columnsKey:"emits",orderNum:99,data:c(u)},P={title:"Model",columnsKey:"model",orderNum:10,data:a(m)},x={title:"Props",columnsKey:"props",orderNum:10,data:a(i)},t=l({emits:()=>M,model:()=>P,props:()=>x},1),C=`<script setup lang="ts">
import {
  BarChart,
  Book,
  CheckSquare,
  Flame,
  Palette,
  PieChart,
  Smile,
  Users,
} from 'lucide-vue-next'

const options = ref([
  {
    label: 'Data Analysis',
    value: 'Data Analysis',
    children: [
      {
        label: 'Dashboard',
        value: 'Dashboard',
        icon: () => h(PieChart, { size: 14 }),
      },
      {
        label: 'Performance',
        value: 'Performance Monitoring',
        icon: () => h(BarChart, { size: 14 }),
      },
    ],
  },
  {
    label: 'Content Management',
    value: 'Content Management',
    children: [
      {
        label: 'User Guide',
        value: 'User Guide',
        icon: () => h(Book, { size: 14 }),
        tagProps: {
          text: 'Beta',
          color: 'green',
          type: 'ghost',
          round: true,
        },
      },
      {
        label: 'Hotspot Mgmt',
        value: 'Hotspot Management',
        icon: () => h(Flame, { size: 14 }),
        tagProps: {
          text: 'Beta',
          color: 'green',
          type: 'ghost',
          round: true,
        },
      },
      {
        label: 'Checklist',
        value: 'Checklist',
        icon: () => h(CheckSquare, { size: 14 }),
      },
      {
        label: 'Satisfaction Survey',
        value: 'Satisfaction Survey',
        icon: () => h(Smile, { size: 14 }),
        tagProps: {
          text: 'HOT',
          color: 'red',
          type: 'ghost',
          round: true,
        },
      },
    ],
  },
  {
    label: 'Settings',
    value: 'Personalized Settings',
    children: [
      {
        label: 'Group Mgmt',
        value: 'Group Management',
        icon: () => h(Users, { size: 14 }),
      },
      {
        label: 'Theme Settings',
        value: 'Theme Settings',
        icon: () => h(Palette, { size: 14 }),
      },
    ],
  },
])

const modelValue = ref('User Guide')

function change(item: any) {
  console.log(item)
}
<\/script>

<template>
  <div class="menu lew-scrollbar">
    <lew-menu v-model="modelValue" :options="options" @change="change" />
  </div>
</template>

<style lang="scss" scoped>
.menu {
  height: 600px;
  width: 250px;
  overflow-y: auto;
  border: 1px var(--lew-bgcolor-2) solid;
}
</style>
`;const w=[y],D=[C];var S={class:"demo-wrapper"},k=d({__name:"DemoMenu",setup(B){const r=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),s=g(Object.keys(t).map(e=>t[e]));return(e,G)=>(h(),p("div",S,[o(_),o(f,{"demo-group":n(w),"code-group":n(D),"component-name":n(r),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),o(b,{options:n(s)},null,8,["options"])]))}}),z=k,F=z;export{F as default};
