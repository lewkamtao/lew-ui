import{bn as t}from"./vendor-DE_9brhS.js";export{t as default};
