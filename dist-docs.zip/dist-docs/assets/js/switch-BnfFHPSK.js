import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Di as n,Zr as c,_t as m,ei as t,gt as u,ht as i,i as a,r as p,ti as d,ui as f,wi as w}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as h,r as g,t as _}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as x}from"./DemoSwitch1-j3nh_B7i.js";import{t as D}from"./DemoSwitch2-DoZiqDK-.js";import{t as S}from"./DemoSwitch3-CHOOsxlC.js";import{t as y}from"./DemoSwitch4-tSWbKRW1.js";import{t as k}from"./DemoSwitch5-BI0vAFLO.js";var L={title:"Emits",columnsKey:"emits",orderNum:99,data:p(m)},b={title:"Model",columnsKey:"model",orderNum:1,data:a(i)},z={title:"Props",columnsKey:"props",orderNum:10,data:a(u)},o=r({emits:()=>L,model:()=>b,props:()=>z},1),N=`<script setup lang="ts">
const value = ref(false)
function change(e: boolean) {
  console.log(e)
}
<\/script>

<template>
  <lew-flex x="start" y="end">
    <lew-switch v-model="value" size="small" @change="change" />
    <lew-switch v-model="value" size="medium" @change="change" />
    <lew-switch v-model="value" size="large" @change="change" />
  </lew-flex>
</template>
`,$=`<script setup lang="ts">
const value = ref(false)

function change(e: unknown) {
  console.log(e)
  console.log(value.value)
}
<\/script>

<template>
  <lew-switch v-model="value" :round="false" @change="change" />
</template>
`,E=`<script setup lang="ts">
const value = ref(false)
function mockFn(v: boolean) {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(v)
      resolve(true)
      LewMessage.success('发送成功')
    }, 1000)
  })
}
function change(e: unknown) {
  console.log(e)
  console.log(value.value)
}
<\/script>

<template>
  <lew-flex direction="y" x="start" y="end">
    <lew-switch
      v-model="value"
      size="small"
      :request="mockFn"
      @change="change"
    />
    <lew-switch
      v-model="value"
      size="medium"
      :request="mockFn"
      @change="change"
    />
    <lew-switch
      v-model="value"
      size="large"
      :request="mockFn"
      @change="change"
    />
  </lew-flex>
</template>
`,F=`<script setup lang="ts">
const value1 = ref(true)
const value2 = ref(false)
<\/script>

<template>
  <lew-flex>
    <lew-switch v-model="value1" readonly />
    <lew-switch v-model="value2" readonly />
  </lew-flex>
</template>
`,P=`<script setup lang="ts">
const value1 = ref(true)
const value2 = ref(false)
<\/script>

<template>
  <lew-flex>
    <lew-switch v-model="value1" disabled />
    <lew-switch v-model="value2" disabled />
  </lew-flex>
</template>
`;const q=[x,D,S,y,k],B=[N,$,E,F,P];var C={class:"demo-wrapper"},K=d({__name:"DemoSwitch",setup(G){const l=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),s=w(Object.keys(o).map(e=>o[e]));return(e,R)=>(f(),c("div",C,[t(g),t(h,{"demo-group":n(q),"code-group":n(B),"component-name":n(l),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(_,{options:n(s)},null,8,["options"])]))}}),M=K,U=M;export{U as default};
