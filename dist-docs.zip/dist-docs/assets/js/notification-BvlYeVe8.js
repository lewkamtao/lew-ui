import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Di as t,Zr as c,ei as e,ti as l,ui as s,wi as p}from"./lew-ui-D4rxVhOO.js";import{da as u}from"./vendor-DE_9brhS.js";import{n as f,r as m,t as d}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as w}from"./DemoNotification1-BeeV7V5g.js";import{t as g}from"./DemoNotification2-4O__Atf1.js";import{t as y}from"./DemoNotification3-Npwt4B_K.js";import{t as h}from"./DemoNotification4-BPF04v9V.js";import{t as _}from"./DemoNotification5-BteShPrs.js";var x={title:"Props",columnsKey:"props",data:[{name:"title",description:"标题",type:"string",default:""},{name:"content",description:"内容",type:"string",default:""},{name:"width",description:"通知框宽度",type:"number",default:"320"},{name:"delay",description:"延迟时间",type:"number",default:"3000"},{name:"showProgress",description:"是否显示进度条",type:"boolean",default:"false"}]},o=r({props:()=>x},1),N=`<script lang="ts" setup>
function openError() {
  LewNotification.error({
    title: 'Payment Failed',
    content:
      'Your payment could not be processed. Please try again or contact customer support.',
  })
}

function openSuccess() {
  LewNotification.success({
    title: 'Order Confirmed',
    content: 'Your order has been successfully placed and is being processed.',
  })
}

function openNormal() {
  LewNotification.normal({
    title: 'Scheduled Maintenance',
    content:
      'Our platform will be undergoing maintenance tonight from 2-4 AM EST.',
  })
}

function openInfo() {
  LewNotification.info({
    title: 'New Feature Available',
    content: 'Check out our new AI-powered search feature. Try it now!',
  })
}

function openWarning() {
  LewNotification.warning({
    title: 'Low Battery',
    content:
      'Your device battery is running low. Please connect to a power source.',
  })
}
<\/script>

<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-button text="Error" type="ghost" color="red" @click="openError" />
    <lew-button
      text="Success"
      type="ghost"
      color="green"
      @click="openSuccess"
    />
    <lew-button text="Normal" type="ghost" color="normal" @click="openNormal" />
    <lew-button text="Info" type="ghost" color="blue" @click="openInfo" />
    <lew-button
      text="Warning"
      type="ghost"
      color="warning"
      @click="openWarning"
    />
  </lew-flex>
</template>
`,b=`<script lang="ts" setup>
function openWithDelay() {
  LewNotification.info({
    title: 'Notice',
    content: 'This notification will close in 5 seconds',
    duration: 5000,
    showProgress: true,
  })
}
function openWithoutDelay() {
  LewNotification.warning({
    title: 'Notice',
    content: 'This notification will not close automatically',
    duration: 0,
  })
}
<\/script>

<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-button text="Auto" type="ghost" color="blue" @click="openWithDelay" />
    <lew-button
      text="Manual"
      type="ghost"
      color="orange"
      @click="openWithoutDelay"
    />
  </lew-flex>
</template>
`,D=`<script lang="ts" setup>
function openWithDelay() {
  LewNotification.info({
    title: 'HSBC Account Update',
    content:
      'Your HSBC account has been successfully updated. Please check your email for more details.',
    width: 500,
  })
}
<\/script>

<template>
  <lew-button
    text="Account Update"
    type="fill"
    color="blue"
    @click="openWithDelay"
  />
</template>
`,v=`<script lang="ts" setup>
function open() {
  LewNotification.info({
    title: 'New IKEA Collection Available',
    content:
      'Our new summer collection is now in stores. Visit us to discover the latest home inspiration.',
    duration: 3500,
    width: 400,
    showProgress: true,
  })
}
<\/script>

<template>
  <lew-button text="Open" type="light" color="blue" @click="open" />
</template>
`,k=`<script lang="ts" setup>
import { getUniqueId } from 'lew-ui/utils'

const notificationMap: Record<string, any> = reactive({})
function open() {
  const id = getUniqueId()
  notificationMap[id] = LewNotification.info({
    title: \`Notification \${id}\`,
    width: 400,
    content:
      'A new system update is ready to install. Please update within 1 minute.',
    duration: 0,
  })
}
function close(id: string) {
  notificationMap[id].close()
  delete notificationMap[id]
}
<\/script>

<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-button text="Open" color="blue" @click="open" />
    <lew-flex>
      <lew-button
        v-for="(item, index) in Object.keys(notificationMap)"
        :key="index"
        :text="\`Close \${item}\`"
        type="ghost"
        @click="close(item)"
      />
    </lew-flex>
  </lew-flex>
</template>
`;const L=[w,g,y,h,_],A=[N,b,D,v,k];var C={class:"demo-wrapper"},P=l({__name:"DemoNotification",setup(I){const i=u().name.replace("R-Lew","").replace(/^[A-Z]/,n=>n.toLowerCase()),a=p(Object.keys(o).map(n=>o[n]));return(n,M)=>(s(),c("div",C,[e(m),e(f,{"demo-group":t(L),"code-group":t(A),"component-name":t(i),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),e(d,{options:t(a)},null,8,["options"])]))}}),W=P,q=W;export{q as default};
