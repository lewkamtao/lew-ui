import{r as i}from"./rolldown-runtime-DYC1jRjs.js";import{Di as n,Zr as s,at as c,ei as t,i as a,it as d,r as m,rt as p,ti as u,ui as f,wi as y}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as g,r as h,t as b}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import"./http-I7MJl4KM.js";import{t as x}from"./DemoTreeSelect1-KEM_7_d8.js";import{t as _}from"./DemoTreeSelect10-BvTDBRoO.js";import{t as w}from"./DemoTreeSelect11-B80CBNlN.js";import{t as T}from"./DemoTreeSelect12-DlRSF7y-.js";import{t as k}from"./DemoTreeSelect13-W1UFDkHR.js";import{t as D}from"./DemoTreeSelect14-BcZmXyCE.js";import{t as S}from"./DemoTreeSelect2-BFYXd1uM.js";import{t as M}from"./DemoTreeSelect3-DZAqyRj0.js";import{t as $}from"./DemoTreeSelect4-Dwp8C_LJ.js";import{t as P}from"./DemoTreeSelect5-DIjkd7QX.js";import{t as K}from"./DemoTreeSelect6--ff4gv6C.js";import{t as L}from"./DemoTreeSelect7-Dak8PI_B.js";import{t as B}from"./DemoTreeSelect8-BWsCM8ea.js";import{t as z}from"./DemoTreeSelect9-oW_711vV.js";var E={title:"Emits",columnsKey:"emits",orderNum:99,data:m(c)},C={title:"Model",columnsKey:"model",data:a(p)},O={title:"Props",columnsKey:"props",data:a(d)},j={title:"Slots",columnsKey:"slots",data:[{name:"handle",description:"操作按钮",params:"-"}]},l=i({emits:()=>E,model:()=>C,props:()=>O,slots:()=>j},1),A=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    key-field="value"
    width="300px"
    size="medium"
    searchable
    label-field="label"
    :data-source="cityTree"
    @change="change"
  />
</template>
`,N=`<script setup lang="ts">
import axios from 'docs/axios/http'

function initMethod() {
  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: '/common/region/province/0',
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}

function loadMethod(item?: any) {
  const levelMap: any = {
    0: 'province',
    1: 'city',
    2: 'area',
    3: 'street',
  }
  // item 无值时，初始化第一层数据
  const _typeKey = item ? item.level + 1 : 0

  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: \`/common/region/\${levelMap[_typeKey] || 'province'}/\${item ? item.value : 0}\`,
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}
function change(item: any) {
  console.log(item)
}
const v = ref<string>('')
<\/script>

<template>
  <lew-flex direction="y" gap="20px" style="width: 300px">
    <lew-tree-select
      v-model="v"
      key-field="value"
      label-field="label"
      :load-method="loadMethod"
      :init-method="initMethod"
      @change="change"
    />
  </lew-flex>
</template>
`,R=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')

function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-flex direction="y" gap="20px" style="width: 300px">
    <lew-tree-select
      v-model="v"
      key-field="value"
      label-field="label"
      :data-source="cityTree"
      @change="change"
    >
      <template #item="{ props }">
        {{ props.label }}
        <span>（{{ props.value }}）</span>
      </template>
    </lew-tree-select>
  </lew-flex>
</template>
`,V=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')

function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-flex direction="y" gap="20px" style="width: 300px">
    <lew-tree-select
      v-model="v"
      key-field="value"
      label-field="label"
      :data-source="cityTree"
      @change="change"
    />
  </lew-flex>
</template>
`,G=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')

function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-flex direction="y" gap="20px" style="width: 300px">
    <lew-tree-select
      v-model="v"
      key-field="value"
      label-field="label"
      :data-source="cityTree"
      expand-all
      @change="change"
    />
  </lew-flex>
</template>
`,I=`<script setup lang="ts">
import axios from 'docs/axios/http'

function initMethod() {
  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: '/common/region/province/0',
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}

function loadMethod(item?: any) {
  const levelMap: any = {
    0: 'province',
    1: 'city',
    2: 'area',
    3: 'street',
  }
  // item 无值时，初始化第一层数据
  const _typeKey = item ? item.level + 1 : 0

  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: \`/common/region/\${levelMap[_typeKey] || 'province'}/\${item ? item.value : 0}\`,
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}
function change(item: any) {
  console.log(item)
}
const v = ref<string>('')
<\/script>

<template>
  <lew-flex direction="y" gap="20px" style="width: 300px">
    <lew-tree-select
      v-model="v"
      key-field="value"
      label-field="label"
      searchable
      :load-method="loadMethod"
      :init-method="initMethod"
      @change="change"
    />
  </lew-flex>
</template>
`,U=`<script setup lang="ts">
import axios from 'docs/axios/http'
import { Box } from 'lucide-vue-next'

function initMethod() {
  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: '/common/region/province/0',
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}

function loadMethod(item?: any) {
  const levelMap: any = {
    0: 'province',
    1: 'city',
    2: 'area',
    3: 'street',
  }
  // item 无值时，初始化第一层数据
  const _typeKey = item ? item.level + 1 : 0

  return new Promise<any[]>((resolve) => {
    // item 不存在的时候 是第一层加载
    axios
      .get({
        url: \`/common/region/\${levelMap[_typeKey] || 'province'}/\${
          item ? item.value : 0
        }\`,
      })
      .then((res: any) => {
        const { data, success } = res
        if (success) {
          const options = data.map((e: any) => {
            return {
              label: e.name,
              value: e.code,
              isLeaf: e.is_leaf,
            }
          })
          resolve(options)
        }
      })
  })
}
function change(item: any) {
  console.log(item)
}
const v = ref<string>('')
<\/script>

<template>
  <lew-flex direction="y" gap="20px" style="width: 300px">
    <lew-tree-select
      v-model="v"
      width="300px"
      key-field="value"
      label-field="label"
      searchable
      :load-method="loadMethod"
      :init-method="initMethod"
      @change="change"
    >
      <template #empty>
        <div class="empty">
          <Box :size="30" />
          暂无内容
        </div>
      </template>
    </lew-tree-select>
  </lew-flex>
</template>

<style lang="scss" scoped>
.empty {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 100%;
  height: 220px;
  gap: 10px;
  text-align: center;
  color: #aaa;
}
</style>
`,Z=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    width="300px"
    key-field="value"
    label-field="label"
    clearable
    :data-source="cityTree"
  />
</template>
`,F=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    width="300px"
    key-field="value"
    label-field="label"
    readonly
    :data-source="cityTree"
  />
</template>
`,J=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<string>('')
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    width="300px"
    key-field="value"
    label-field="label"
    disabled
    :data-source="cityTree"
  />
</template>
`,W=`<script setup lang="ts">
const value = ref()

function initMethod() {
  return new Promise((resolve) => {
    setTimeout(() => {
      const res = [
        {
          key: 'engineering',
          label: 'Engineering',
          children: [
            {
              key: 'frontend',
              label: 'Frontend Team',
              children: [
                { key: 'react-dev', label: 'React Developer' },
                { key: 'vue-dev', label: 'Vue Developer' },
                { key: 'ui-designer', label: 'UI Designer' },
              ],
            },
            {
              key: 'backend',
              label: 'Backend Team',
              children: [
                { key: 'java-dev', label: 'Java Developer' },
                {
                  key: 'python-dev',
                  label: 'Python Developer',
                },
                { key: 'devops', label: 'DevOps Engineer' },
              ],
            },
            {
              key: 'mobile',
              label: 'Mobile Team',
              children: [
                { key: 'ios-dev', label: 'iOS Developer' },
                {
                  key: 'android-dev',
                  label: 'Android Developer',
                },
              ],
            },
          ],
        },
        {
          key: 'product',
          label: 'Product',
          children: [
            {
              key: 'pm',
              label: 'Product Management',
              children: [
                {
                  key: 'senior-pm',
                  label: 'Senior Product Manager',
                },
                {
                  key: 'associate-pm',
                  label: 'Associate Product Manager',
                },
              ],
            },
            {
              key: 'design',
              label: 'Design',
              children: [
                { key: 'ux-designer', label: 'UX Designer' },
                {
                  key: 'visual-designer',
                  label: 'Visual Designer',
                },
              ],
            },
          ],
        },
        {
          key: 'marketing',
          label: 'Marketing',
          children: [
            {
              key: 'digital',
              label: 'Digital Marketing',
              children: [
                {
                  key: 'seo-specialist',
                  label: 'SEO Specialist',
                },
                {
                  key: 'content-writer',
                  label: 'Content Writer',
                },
                {
                  key: 'social-media',
                  label: 'Social Media Manager',
                },
              ],
            },
            {
              key: 'brand',
              label: 'Brand Marketing',
              children: [
                {
                  key: 'brand-manager',
                  label: 'Brand Manager',
                },
                {
                  key: 'creative-director',
                  label: 'Creative Director',
                },
              ],
            },
          ],
        },
      ]
      resolve(res)
    }, 1000)
  })
}

const updateKey = ref(0)

function load() {
  updateKey.value++
}
<\/script>

<template>
  <lew-tree-select
    :key="updateKey"
    v-model="value"
    :init-method="initMethod"
    placeholder="Please select department"
    width="300px"
    searchable
    clearable
    show-line
  />
  <lew-button type="ghost" style="margin-top: 20px" @click="load">
    load again {{ updateKey }}
  </lew-button>
</template>

<style scoped>
.demo-tree-select {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.demo-result {
  font-size: 14px;
  color: #666;
}

.demo-description {
  font-size: 12px;
  color: #999;
  background-color: #f5f5f5;
  padding: 12px;
  border-radius: 4px;
}

.demo-description ul {
  margin: 8px 0 0 0;
  padding-left: 20px;
}

.demo-description li {
  margin: 4px 0;
}
</style>
`,X=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<any>([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    multiple
    key-field="value"
    width="300px"
    size="medium"
    searchable
    label-field="label"
    :data-source="cityTree"
    @change="change"
  />
</template>
`,q=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<any>([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    multiple
    key-field="value"
    width="300px"
    size="medium"
    searchable
    free
    label-field="label"
    :data-source="cityTree"
    @change="change"
  />
</template>
`,H=`<script setup lang="ts">
import { cityTree } from 'docs/lib/data'

const v = ref<any>([])
function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-tree-select
    v-model="v"
    multiple
    key-field="value"
    width="300px"
    size="medium"
    searchable
    :only-leaf-selectable="false"
    label-field="label"
    :data-source="cityTree"
    @change="change"
  />
</template>
`;const Q=[x,S,M,$,P,K,L,B,z,_,w,T,k,D],Y=[A,N,R,V,G,I,U,Z,F,J,W,X,q,H];var ee={class:"demo-wrapper"},ne=u({__name:"DemoTreeSelect",setup(le){const o=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),r=y(Object.keys(l).map(e=>l[e]));return(e,ae)=>(f(),s("div",ee,[t(h),t(g,{"demo-group":n(Q),"code-group":n(Y),"component-name":n(o),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(b,{options:n(r)},null,8,["options"])]))}}),te=ne,De=te;export{De as default};
