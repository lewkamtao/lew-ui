import{r}from"./rolldown-runtime-DYC1jRjs.js";import{Di as t,Zr as s,ei as n,i as p,ti as i,ui as m,wi as u,wn as c}from"./lew-ui-D4rxVhOO.js";import{da as w}from"./vendor-DE_9brhS.js";import{n as f,r as d,t as y}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as g}from"./DemoAlert1-pWl8hZpr.js";import{t as b}from"./DemoAlert2-BKE0ppGU.js";import{t as v}from"./DemoAlert3-BzTSKvi-.js";var _={title:"Props",columnsKey:"props",data:p(c)},l=r({props:()=>_},1),x=`<template>
  <lew-flex direction="y">
    <lew-alert
      type="error"
      title="Payment Failed"
      content="Your Apple Pay payment failed. Please check your card information."
    />

    <lew-alert
      type="success"
      title="Subscription Successful"
      content="You have successfully subscribed to Apple Music."
    />

    <lew-alert
      type="warning"
      title="Storage Almost Full"
      content="Your iCloud storage is almost full. Please upgrade your storage plan."
    />

    <lew-alert
      type="info"
      title="New Service Available"
      content="Apple Fitness+ is now available. Get professional fitness guidance at home."
    />
  </lew-flex>
</template>
`,h=`<template>
  <lew-flex direction="y">
    <lew-alert type="error">
      <template #title>
        Sign In Failed
      </template>
      <template #content>
        Your sign-in attempt failed. Please check your username and password.
      </template>
    </lew-alert>

    <lew-alert type="success">
      <template #title>
        Registration Complete
      </template>
      <template #content>
        You have successfully registered for Google services.
      </template>
    </lew-alert>

    <lew-alert type="warning">
      <template #title>
        System Maintenance
      </template>
      <template #content>
        The system will be under maintenance tonight. Please complete your work
        in advance.
      </template>
    </lew-alert>

    <lew-alert type="info">
      <template #title>
        New Feature Available
      </template>
      <template #content>
        Google Photos is now available with enhanced photo management features.
      </template>
    </lew-alert>

    <lew-alert type="normal">
      <template #title>
        System Update Required
      </template>
      <template #content>
        Your system needs to be updated. Please update as soon as possible to
        ensure security.
      </template>
    </lew-alert>
  </lew-flex>
</template>
`,A=`<script setup lang="ts">
const visibleWarning = ref(true)
const visibleInfo = ref(true)
<\/script>

<template>
  <lew-flex style="width: 500px" direction="y">
    <lew-alert type="error">
      <template #title>
        Sign In Failed
      </template>
      <template #content>
        Your sign-in attempt failed. Please check your username and
        password.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button round type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button round type="light" color="red" size="small">
            Try Again
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>

    <lew-alert type="success">
      <template #title>
        Registration Complete
      </template>
      <template #content>
        You have successfully registered for Google services.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button round color="success" size="small">
            Continue
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>

    <lew-alert
      v-if="visibleWarning"
      type="warning"
      closeable
      @close="visibleWarning = false"
    >
      <template #title>
        System Maintenance
      </template>
      <template #content>
        The system will be under maintenance tonight. Please complete your work
        in advance.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button color="warning" size="small">
            Learn More
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>

    <lew-alert
      v-if="visibleInfo"
      type="info"
      closeable
      @close="visibleInfo = false"
    >
      <template #title>
        New Feature Available
      </template>
      <template #content>
        Google Photos is now available with enhanced photo management
        features.
      </template>
      <template #footer>
        <lew-flex x="end">
          <lew-button type="text" color="gray" size="small">
            Don't Show Again
          </lew-button>
          <lew-button type="light" size="small">
            Explore
          </lew-button>
        </lew-flex>
      </template>
    </lew-alert>
  </lew-flex>
</template>
`;const D=[g,b,v],P=[x,h,A];var S={class:"demo-wrapper"},k=i({__name:"DemoAlert",setup(Y){const a=w().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),o=u(Object.keys(l).map(e=>l[e]));return(e,C)=>(m(),s("div",S,[n(d),n(f,{"demo-group":t(D),"code-group":t(P),"component-name":t(a),columns:1,gap:"20px"},null,8,["demo-group","code-group","component-name"]),n(y,{options:t(o)},null,8,["options"])]))}}),z=k,B=z;export{B as default};
