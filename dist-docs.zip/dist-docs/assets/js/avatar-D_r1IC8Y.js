import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Di as a,Zr as p,ei as t,et as o,i as m,ti as c,ui as d,wi as _}from"./lew-ui-D4rxVhOO.js";import{da as i}from"./vendor-DE_9brhS.js";import{n as w,r as u,t as v}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as f}from"./DemoAvatar1-CbWSsjDL.js";import{t as h}from"./DemoAvatar2-IVYfezG2.js";import{t as g}from"./DemoAvatar3-BK4DH5rC.js";import{t as x}from"./DemoAvatar4-Rg29U-Nr.js";var j={title:"Props",columnsKey:"props",data:m(o)},r=s({props:()=>j},1),k=`<script setup lang="ts">
const src = ref('')

setTimeout(() => {
  src.value
    = 'https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_1_ctd06i_.jpeg'
}, 2500)
<\/script>

<template>
  <lew-flex wrap x="start" y="end" gap="20px">
    <lew-avatar shape="circle" :src="src" :loading="!src" />
    <lew-avatar
      shape="circle"
      src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_2_2s0nai_.jpeg"
      alt="avatar"
    />
    <lew-avatar
      shape="circle"
      src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_3_kntap6_.jpeg"
      alt="avatar"
    />
  </lew-flex>
</template>
`,L=`<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-avatar
      src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_4_7cwenb_.jpeg"
      status="online"
      shape="circle"
      status-placement="top-left"
    />
    <lew-avatar
      src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_5_8h51sk_.jpeg"
      status="busy"
      shape="circle"
      status-placement="top-right"
    />
    <lew-avatar
      src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_6_7ytti9_.jpeg"
      status="away"
      status-placement="bottom-left"
    />
    <lew-avatar
      src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_7_djk4ui_.jpeg"
      status="offline"
      status-placement="bottom-right"
    />
  </lew-flex>
</template>
`,C=`<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-avatar size="40" shape="circle" />
    <lew-avatar alt="赵云" size="40" shape="circle" />
    <lew-avatar alt="Tim Cook" size="40" shape="circle" />
  </lew-flex>
</template>
`,D=`<template>
  <lew-flex wrap x="start" gap="20px">
    <lew-avatar
      size="40px"
      src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_1_ctd06i_.jpeg"
      shape="square"
    />
    <lew-avatar
      size="40px"
      src=" https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/apple_leader_3_kntap6_.jpeg"
      shape="circle"
    />
    <lew-avatar
      size="40px"
      src="https://cdn.jsdelivr.net/gh/lewkamtao/LewCloud@master/lew/146d572968e09c8bdc4f45ef58ca110_cn9qli_.jpeg"
      shape="sharp"
    />
  </lew-flex>
</template>
`;const A=[f,h,g,x],y=[k,L,C,D];var b={class:"demo-wrapper"},z=c({__name:"DemoAvatar",setup(B){const l=i().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),n=_(Object.keys(r).map(e=>r[e]));return(e,P)=>(d(),p("div",b,[t(u),t(w,{"demo-group":a(A),"code-group":a(y),"component-name":a(l),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(v,{options:a(n)},null,8,["options"])]))}}),$=z,O=$;export{O as default};
