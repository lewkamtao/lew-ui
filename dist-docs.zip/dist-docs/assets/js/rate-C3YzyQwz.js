import{r as m}from"./rolldown-runtime-DYC1jRjs.js";import{Di as t,Dt as p,Ot as l,Zr as u,ei as a,i as r,kt as d,r as i,ti as c,ui as _,wi as f}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as D,r as R,t as w}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as g}from"./DemoRate1-ISiGzjmn.js";import{t as y}from"./DemoRate2-CmzEMcAI.js";import{t as x}from"./DemoRate3-UT9NRBUt.js";import{t as L}from"./DemoRate4-kQNkHGLU.js";var N={title:"Emits",columnsKey:"emits",orderNum:99,data:i(d)},k={title:"Model",columnsKey:"model",orderNum:1,data:r(p)},E={title:"Props",columnsKey:"props",orderNum:10,data:r(l)},o=m({emits:()=>N,model:()=>k,props:()=>E},1),$=`<script setup lang="ts">
const value = ref(2)
<\/script>

<template>
  <lew-rate v-model="value" />
</template>
`,b=`<script setup lang="ts">
const value = ref(4)
<\/script>

<template>
  <lew-rate v-model="value" readonly />
</template>
`,B=`<script setup lang="ts">
const value = ref(3)
<\/script>

<template>
  <lew-rate v-model="value" disabled />
</template>
`,C=`<script setup lang="ts">
const value = ref(3)
const tips = ['极差', '较差', '一般', '较好', '极好']
<\/script>

<template>
  <lew-rate v-model="value" :tips="tips" />
</template>
`;const K=[g,y,x,L],P=[$,b,B,C];var h={class:"demo-wrapper"},G=c({__name:"DemoRate",setup(O){const s=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),n=f(Object.keys(o).map(e=>o[e]));return(e,Z)=>(_(),u("div",h,[a(R),a(D,{"demo-group":t(K),"code-group":t(P),"component-name":t(s),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),a(w,{options:t(n)},null,8,["options"])]))}}),M=G,J=M;export{J as default};
