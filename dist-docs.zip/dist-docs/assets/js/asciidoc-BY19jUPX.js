import{Vi as i}from"./vendor-DE_9brhS.js";export{i as default};
