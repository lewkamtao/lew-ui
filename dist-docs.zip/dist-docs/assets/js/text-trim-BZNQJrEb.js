import{r as i}from"./rolldown-runtime-DYC1jRjs.js";import{Di as t,H as a,Zr as l,ei as n,i as m,ti as p,ui as d,wi as c}from"./lew-ui-D4rxVhOO.js";import{da as u}from"./vendor-DE_9brhS.js";import{n as f,r as x,t as v}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as _}from"./DemoTextTrim1-DIevX6Xk.js";import{t as h}from"./DemoTextTrim2-WOFawWOD.js";import{t as w}from"./DemoTextTrim3-BBs8Fs5s.js";import{t as g}from"./DemoTextTrim4-DLGZ9-rH.js";var T={title:"Props",columnsKey:"props",data:m(a)},o=i({props:()=>T},1),y=`<template>
  <lew-text-trim
    style="width: 350px"
    placement="bottom"
    text="Spring is a burden of life and death; Summer is the flourishing of passion; Autumn is the resolution of cause and effect; Winter is self-cultivation. The cycle of seasons represents the circle of life. Desire awakens the urge to possess, which can lead to peril—what you love, others may love too."
  />
</template>
`,D=`<template>
  <lew-text-trim
    style="width: 350px"
    allow-h-t-m-l
    :line-clamp="2"
    placement="right"
    text="Spring is a burden of life and death; Summer is the flourishing of passion; Autumn is the resolution of cause and effect; Winter is self-cultivation. The cycle of seasons represents the circle of life. Desire awakens the urge to possess, which can lead to peril—what you love, others may love too."
  />
</template>
`,b=`<template>
  <div style="width: 300px" class="demo-text-trim-3">
    <div class="demo-section">
      <div class="section-title">
        File Names
      </div>
      <lew-text-trim
        text="very_long_file_name_with_multiple_extensions.tar.gz"
        :reserve-end="8"
      />
      <lew-text-trim
        text="project_backup_2024_03_15_final_version.zip"
        :reserve-end="8"
      />
    </div>

    <div class="demo-section">
      <div class="section-title">
        Code Files
      </div>
      <lew-text-trim
        text="src/components/very/deep/nested/component/implementation.ts"
        :reserve-end="15"
      />
      <lew-text-trim
        text="lib/utils/helpers/string/formatting/implementation.js"
        :reserve-end="15"
      />
    </div>

    <div class="demo-section">
      <div class="section-title">
        Document Paths
      </div>
      <lew-text-trim
        text="documents/projects/2024/quarter1/reports/financial_summary.pdf"
        :reserve-end="12"
      />
      <lew-text-trim
        text="user/downloads/important/documents/contracts/agreement.docx"
        :reserve-end="12"
      />
    </div>

    <div class="demo-section">
      <div class="section-title">
        URLs
      </div>
      <lew-text-trim
        text="https://example.com/very/long/path/to/specific/resource"
        :reserve-end="10"
      />
      <lew-text-trim
        text="https://subdomain.example.com/path/to/another/resource"
        :reserve-end="10"
      />
    </div>

    <div class="demo-section">
      <div class="section-title">
        Email Addresses
      </div>
      <lew-text-trim
        text="very.long.email.address.for.specific.department@company.com"
        :reserve-end="15"
      />
      <lew-text-trim
        text="user.name.with.multiple.parts@subdomain.domain.com"
        :reserve-end="15"
      />
    </div>
  </div>
</template>

<style lang="scss" scoped>
.demo-text-trim-3 {
  display: flex;
  flex-direction: column;
  gap: 24px;

  .demo-section {
    display: flex;
    flex-direction: column;
    gap: 8px;

    .section-title {
      font-size: 14px;
      font-weight: bold;
      margin-bottom: 4px;
      color: var(--lew-color-primary-dark);
    }
  }
}
</style>
`,k=`<template>
  <lew-flex width="250px">
    <lew-text-trim text-align="right" text="2024年人工智能" />
  </lew-flex>
</template>
`;const L=[_,h,w,g],j=[y,D,b,k];var A={class:"demo-wrapper"},C=p({__name:"DemoTextTrim",setup(S){const s=u().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),r=c(Object.keys(o).map(e=>o[e]));return(e,$)=>(d(),l("div",A,[n(x),n(f,{"demo-group":t(L),"code-group":t(j),"component-name":t(s),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),n(v,{options:t(r)},null,8,["options"])]))}}),P=C,q=P;export{q as default};
