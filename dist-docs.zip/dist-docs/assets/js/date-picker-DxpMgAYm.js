import{r as m}from"./rolldown-runtime-DYC1jRjs.js";import{$t as p,Di as a,Yt as c,Zr as s,Zt as u,ei as t,i as l,r as d,ti as i,ui as f,wi as v}from"./lew-ui-D4rxVhOO.js";import{da as Y}from"./vendor-DE_9brhS.js";import{n as D,r as _,t as k}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as w}from"./DemoDatePicker1-8m6obopS.js";import{t as h}from"./DemoDatePicker2-DtSbZkk5.js";import{t as M}from"./DemoDatePicker3-BFbw0w0t.js";import{t as P}from"./DemoDatePicker4-CCz3-_2y.js";import{t as H}from"./DemoDatePicker5-zCtVNGd1.js";import{t as b}from"./DemoDatePicker6-BY03_kMT.js";var g={title:"Emits",columnsKey:"emits",orderNum:99,data:d(p)},V={title:"Model",columnsKey:"model",orderNum:1,data:l(c)},x={title:"Props",columnsKey:"props",orderNum:2,data:l(u)},n=m({emits:()=>g,model:()=>V,props:()=>x},1),y=`<script setup lang="ts">
const value = ref('')

function change(e: any) {
  console.log(e)
}
<\/script>

<template>
  <lew-date-picker
    v-model="value"
    width="300px"
    value-format="YYYY-MM-DD"
    @change="change"
  />
</template>
`,$=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <lew-date-picker v-model="value" width="300px" clearable />
</template>
`,L=`<script setup lang="ts">
const yearValue = ref('')
const monthValue = ref('')
const dateValue = ref('')
const quarterValue = ref('')
const datetimeValue = ref('')
const timeValue = ref('')
const timeHourMinuteValue = ref('')
const datetimeHourMinuteValue = ref('')
<\/script>

<template>
  <lew-flex width="300px" direction="y" gap="10px">
    <lew-date-picker
      v-model="yearValue"
      width="300px"
      value-format="YYYY"
      placeholder="YYYY"
      clearable
    />
    <lew-date-picker
      v-model="monthValue"
      value-format="YYYY-MM"
      placeholder="YYYY-MM"
      clearable
    />
    <lew-date-picker
      v-model="dateValue"
      value-format="YYYY-MM-DD"
      placeholder="YYYY-MM-DD"
      clearable
    />
    <lew-date-picker
      v-model="quarterValue"
      value-format="YYYY-[Q]Q"
      placeholder="YYYY-[Q]Q"
      clearable
    />
    <lew-date-picker
      v-model="datetimeValue"
      value-format="MM/DD/YYYY HH:mm:ss"
      placeholder="MM/DD/YYYY HH:mm:ss"
      clearable
    />

    <lew-date-picker
      v-model="timeValue"
      value-format="HH:mm:ss"
      placeholder="HH:mm:ss"
      clearable
    />

    <lew-date-picker
      v-model="timeHourMinuteValue"
      value-format="HH:mm"
      placeholder="HH:mm"
      clearable
    />

    <lew-date-picker
      v-model="datetimeHourMinuteValue"
      value-format="YYYY-MM-DD HH:mm"
      placeholder="YYYY-MM-DD HH:mm"
      clearable
    />
  </lew-flex>
</template>
`,N=`<script setup lang="ts">
const value = ref('')

const presets = [
  {
    label: '春节',
    value: '2022-02-01',
  },
  {
    label: '端午节',
    value: '2022-05-05',
  },
  {
    label: '儿童节',
    value: '2024-06-01',
  },
  {
    label: '国庆节',
    value: '2024-10-01',
  },
]
<\/script>

<template>
  <lew-date-picker v-model="value" width="300px" :presets="presets" />
</template>
`,E=`<script setup lang="ts">
const value = ref('2025-02-23')
<\/script>

<template>
  <lew-date-picker
    v-model="value"
    placeholder="只读"
    readonly
    width="300px"
    clearable
  />
</template>
`,Q=`<script setup lang="ts">
const value = ref('2025-02-25')
<\/script>

<template>
  <lew-date-picker
    v-model="value"
    placeholder="禁用"
    disabled
    width="300px"
    clearable
  />
</template>
`;const B=[w,h,M,P,H,b],C=[y,$,L,N,E,Q];var K={class:"demo-wrapper"},Z=i({__name:"DemoDatePicker",setup(G){const r=Y().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),o=v(Object.keys(n).map(e=>n[e]));return(e,R)=>(f(),s("div",K,[t(_),t(D,{"demo-group":a(B),"code-group":a(C),"component-name":a(r),columns:2,gap:"20px"},null,8,["demo-group","code-group","component-name"]),t(k,{options:a(o)},null,8,["options"])]))}}),q=Z,X=q;export{X as default};
