import{r as s}from"./rolldown-runtime-DYC1jRjs.js";import{Di as n,Mn as i,Nn as l,Pn as m,Zr as u,ei as a,i as o,r as g,ti as c,ui as d,wi as f}from"./lew-ui-D4rxVhOO.js";import{da as v}from"./vendor-DE_9brhS.js";import{n as _,r as w,t as h}from"./LewDocsTables-CyF_awws.js";import"./LewCodeHighlighter-DCfSNOLt.js";import{t as y}from"./DemoPagination1-DIekLHQp.js";import{t as x}from"./DemoPagination2-B-Rc5Qyy.js";import{t as z}from"./DemoPagination3-DFYCqOgv.js";var P={title:"Emits",columnsKey:"emits",orderNum:99,data:g(m)},D={title:"Model",columnsKey:"model",orderNum:1,data:o(i)},N={title:"Props",columnsKey:"props",orderNum:10,data:o(l)},t=s({emits:()=>P,model:()=>D,props:()=>N},1),b=`<script setup lang="ts">
const pageNum = ref(2)
const pageSize = ref(20)
function change(e: any) {
  console.log(e)
}
const total = ref(100)
<\/script>

<template>
  <lew-flex direction="y" x="start" gap="24px">
    <lew-pagination
      v-model:current-page="pageNum"
      :page-size="pageSize"
      size="small"
      show-summary
      :total="total"
      @change="change"
    />
    <lew-pagination
      v-model:current-page="pageNum"
      :page-size="pageSize"
      show-summary
      :total="total"
      round
      @change="change"
    />
    <lew-pagination
      v-model:current-page="pageNum"
      :page-size="pageSize"
      size="large"
      show-summary
      :total="total"
      round
      @change="change"
    />
  </lew-flex>
</template>
`,L=`<script setup lang="ts">
const page = ref(1)
<\/script>

<template>
  <lew-flex direction="y" x="start" gap="24px">
    <lew-pagination
      v-model:current-page="page"
      show-summary
      :total="1000"
      :visible-pages-count="5"
    />
    <lew-pagination
      v-model:current-page="page"
      show-summary
      :total="10000"
      :visible-pages-count="7"
    />
    <lew-pagination
      v-model:current-page="page"
      show-summary
      :total="100000"
      :visible-pages-count="9"
    />
    <lew-pagination
      v-model:current-page="page"
      show-summary
      :total="15000000"
      :visible-pages-count="11"
    />
  </lew-flex>
</template>
`,S=`<script lang="ts" setup>
const pageNum = ref(2)
const pageSize = ref(20)
function change(e: any) {
  console.log(e)
}
const total = ref(24)

// 模拟请求
setTimeout(() => {
  total.value = 10000
}, 3000)
<\/script>

<template>
  <div>
    <lew-pagination
      v-model:current-page="pageNum"
      :page-size="pageSize"
      show-summary
      :page-size-options="[
        {
          label: '10 / 页',
          value: 10,
        },
        {
          label: '20 / 页',
          value: 20,
        },
        {
          label: '30 / 页',
          value: 30,
        },
      ]"
      :total="total"
      @change="change"
    />
  </div>
</template>
`;const E=[y,x,z],k=[b,L,S];var B={class:"demo-wrapper"},C=c({__name:"DemoPagination",setup(M){const p=v().name.replace("R-Lew","").replace(/^[A-Z]/,e=>e.toLowerCase()),r=f(Object.keys(t).map(e=>t[e]));return(e,$)=>(d(),u("div",B,[a(w),a(_,{"demo-group":n(E),"code-group":n(k),"component-name":n(p),columns:1,gap:"20px"},null,8,["demo-group","code-group","component-name"]),a(h,{options:n(r)},null,8,["options"])]))}}),K=C,V=K;export{V as default};
